import React, { useState, useEffect } from 'react';
import { POSProvider, usePOS } from './context/POSContext';
import { HeaderNav, ActiveModule } from './components/layout/HeaderNav';
import { LoginView } from './components/auth/LoginView';
import { LockScreenModal } from './components/auth/LockScreenModal';
import { KasirView } from './components/kasir/KasirView';
import { ProdukView } from './components/produk/ProdukView';
import { StokView } from './components/stok/StokView';
import { PembelianView } from './components/pembelian/PembelianView';
import { PenjualanView } from './components/penjualan/PenjualanView';
import { PiutangView } from './components/piutang/PiutangView';
import { SettingPembayaranView } from './components/setting/SettingPembayaranView';
import { LaporanView } from './components/laporan/LaporanView';
import { KaryawanView } from './components/karyawan/KaryawanView';
import { HardwareView } from './components/hardware/HardwareView';
import { CloudView } from './components/cloud/CloudView';
import { LanSyncView } from './components/lan/LanSyncView';
import { LisensiView } from './components/lisensi/LisensiView';
import { AccessDeniedView } from './components/common/AccessDeniedView';
import { canAccessModule } from './utils/permissions';
import { Bell, X } from 'lucide-react';

function POSMainApp() {
  const {
    isAuthenticated,
    logout,
    currentUser,
    lanRecentEventNotification,
    dismissLanNotification,
  } = usePOS();

  const [activeModule, setActiveModule] = useState<ActiveModule>(() => {
    try {
      const saved = localStorage.getItem('pos_active_module');
      return (saved as ActiveModule) || 'KASIR';
    } catch {
      return 'KASIR';
    }
  });

  const [temporarilyUnlockedModules, setTemporarilyUnlockedModules] = useState<ActiveModule[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem('pos_active_module', activeModule);
    } catch (e) {
      console.warn('Failed to save active module to localStorage', e);
    }
  }, [activeModule]);

  const [isLocked, setIsLocked] = useState(false);

  // Global Keyboard Shortcuts (F1 - F9)
  useEffect(() => {
    if (!isAuthenticated || isLocked) return;

    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Do not capture if typing in input unless it's an F-key
      if (e.key === 'F1') {
        // Handled in KasirView or switches to Kasir
      } else if (e.key === 'F2') {
        e.preventDefault();
        setActiveModule('KASIR');
      } else if (e.key === 'F3') {
        e.preventDefault();
        setActiveModule('PENJUALAN');
      } else if (e.key === 'F6') {
        e.preventDefault();
        const access = canAccessModule(currentUser, 'STOK');
        if (access.allowed || temporarilyUnlockedModules.includes('STOK')) {
          setActiveModule('STOK');
        } else {
          setActiveModule('STOK'); // Will trigger AccessDeniedView
        }
      } else if (e.key === 'F7') {
        e.preventDefault();
        setActiveModule('PEMBELIAN');
      } else if (e.key === 'F8') {
        // If in Kasir, select member; else can switch
      } else if (e.key === 'F9') {
        e.preventDefault();
        setActiveModule('LAPORAN');
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [isAuthenticated, isLocked, currentUser, temporarilyUnlockedModules]);

  // When opening the application, user must login first!
  if (!isAuthenticated) {
    return <LoginView />;
  }

  // Permission validation for active module
  const moduleAccess = canAccessModule(currentUser, activeModule);
  const isModuleBlocked =
    !moduleAccess.allowed && !temporarilyUnlockedModules.includes(activeModule);

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-slate-100 text-slate-900 antialiased font-sans">
      {/* Header with Alfa-style Red Gradient and Yellow Border */}
      <HeaderNav
        activeModule={activeModule}
        onSelectModule={setActiveModule}
        onLockScreen={() => setIsLocked(true)}
        onLogout={() => {
          setIsLocked(false);
          logout();
        }}
      />

      {/* Main Active Module Container */}
      <main className="flex-1 flex overflow-hidden relative">
        {isModuleBlocked ? (
          <AccessDeniedView
            moduleName={activeModule}
            reason={moduleAccess.reason}
            onBackToKasir={() => setActiveModule('KASIR')}
            onGrantTemporaryAccess={() =>
              setTemporarilyUnlockedModules(prev => [...prev, activeModule])
            }
          />
        ) : (
          <>
            {activeModule === 'KASIR' && <KasirView />}
            {activeModule === 'PRODUK' && <ProdukView />}
            {activeModule === 'STOK' && <StokView />}
            {activeModule === 'PEMBELIAN' && <PembelianView />}
            {activeModule === 'PENJUALAN' && <PenjualanView />}
            {activeModule === 'PIUTANG' && <PiutangView />}
            {activeModule === 'SETTING_PEMBAYARAN' && <SettingPembayaranView />}
            {activeModule === 'LAPORAN' && <LaporanView />}
            {activeModule === 'KARYAWAN' && <KaryawanView />}
            {activeModule === 'HARDWARE' && <HardwareView />}
            {activeModule === 'CLOUD' && <CloudView />}
            {activeModule === 'LAN_SYNC' && <LanSyncView />}
            {activeModule === 'LISENSI' && <LisensiView />}
          </>
        )}
      </main>

      {/* Floating LAN Real-time Activity Banner */}
      {lanRecentEventNotification && (
        <div className="fixed bottom-4 right-4 z-50 max-w-md bg-slate-900/95 text-white border border-sky-400/50 shadow-2xl rounded-2xl p-3.5 backdrop-blur-md flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4">
          <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 border border-sky-400/30">
            <Bell className="w-4 h-4 animate-bounce" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-sky-300 uppercase tracking-wider">Jaringan LAN Realtime</p>
            <p className="text-xs text-slate-200 truncate mt-0.5">{lanRecentEventNotification}</p>
          </div>
          <button
            type="button"
            onClick={dismissLanNotification}
            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer shrink-0"
            title="Tutup Notifikasi"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Lock Screen Modal: strictly requires password/PIN of active cashier */}
      {isLocked && (
        <LockScreenModal onUnlock={() => setIsLocked(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <POSProvider>
      <POSMainApp />
    </POSProvider>
  );
}
