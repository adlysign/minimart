import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  Plus,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  User,
  Phone,
  ArrowDownRight,
  Printer,
  Share2,
  FileSpreadsheet,
  X,
  CreditCard,
  Banknote,
  DollarSign,
  Receipt,
  FileText,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { PiutangRecord } from '../../types/pos';
import { formatDateTime, formatRupiah, exportToCSV } from '../../utils/formatters';

export const PiutangView: React.FC = () => {
  const {
    piutangList,
    customers,
    addPiutangPayment,
    createDirectPiutang,
    storeProfile,
    currentUser,
  } = usePOS();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'BELUM_LUNAS' | 'JATUH_TEMPO' | 'LUNAS'>('ALL');
  const [selectedPiutang, setSelectedPiutang] = useState<PiutangRecord | null>(null);

  // Modal: Bayar Cicilan Piutang
  const [payModalPiutang, setPayModalPiutang] = useState<PiutangRecord | null>(null);
  const [payAmount, setPayAmount] = useState<string>('');
  const [payMethod, setPayMethod] = useState<'TUNAI' | 'TRANSFER'>('TUNAI');
  const [payNotes, setPayNotes] = useState('');
  const [payFeedback, setPayFeedback] = useState<string | null>(null);

  // Modal: Tambah Kasbon Manual
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCustType, setNewCustType] = useState<'MEMBER' | 'CUSTOM'>('MEMBER');
  const [newSelectedMemberId, setNewSelectedMemberId] = useState('');
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newTotalAmount, setNewTotalAmount] = useState<number>(0);
  const [newDownPayment, setNewDownPayment] = useState<number>(0);
  const [newDueDate, setNewDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().slice(0, 10);
  });
  const [newNotes, setNewNotes] = useState('');

  // Receipt / Detail Print View
  const [printPiutang, setPrintPiutang] = useState<PiutangRecord | null>(null);

  const todayStr = new Date().toISOString().slice(0, 10);

  // Statistics calculation
  const stats = useMemo(() => {
    let totalOutstanding = 0;
    let totalPaid = 0;
    let unpaidCount = 0;
    let overdueCount = 0;

    piutangList.forEach(p => {
      totalPaid += p.paidAmount;
      if (p.status === 'BELUM_LUNAS') {
        totalOutstanding += p.remainingAmount;
        unpaidCount += 1;
        if (p.dueDate && p.dueDate < todayStr) {
          overdueCount += 1;
        }
      }
    });

    return { totalOutstanding, totalPaid, unpaidCount, overdueCount };
  }, [piutangList, todayStr]);

  // Filtered List
  const filteredList = useMemo(() => {
    return piutangList.filter(p => {
      const q = search.toLowerCase();
      const matchSearch =
        p.invoiceNumber.toLowerCase().includes(q) ||
        p.customerName.toLowerCase().includes(q) ||
        (p.customerPhone && p.customerPhone.includes(q)) ||
        (p.notes && p.notes.toLowerCase().includes(q));

      if (!matchSearch) return false;

      if (statusFilter === 'BELUM_LUNAS') {
        return p.status === 'BELUM_LUNAS';
      }
      if (statusFilter === 'LUNAS') {
        return p.status === 'LUNAS';
      }
      if (statusFilter === 'JATUH_TEMPO') {
        return p.status === 'BELUM_LUNAS' && p.dueDate && p.dueDate <= todayStr;
      }
      return true;
    });
  }, [piutangList, search, statusFilter, todayStr]);

  // Handle Cicilan Payment Submit
  const handlePaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalPiutang) return;

    const amountNum = parseFloat(payAmount) || 0;
    if (amountNum <= 0) {
      alert('Masukkan nominal pembayaran yang valid!');
      return;
    }

    const res = addPiutangPayment(payModalPiutang.id, amountNum, payMethod, payNotes);
    if (res.success) {
      setPayFeedback(res.message);
      setTimeout(() => {
        setPayFeedback(null);
        setPayModalPiutang(null);
        setPayAmount('');
        setPayNotes('');
      }, 1500);
    } else {
      alert(res.message);
    }
  };

  // Handle Create Direct Kasbon Submit
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTotalAmount <= 0) {
      alert('Total kasbon harus lebih dari Rp 0!');
      return;
    }

    let custName = newCustName.trim();
    let custPhone = newCustPhone.trim();
    let custId: string | undefined = undefined;

    if (newCustType === 'MEMBER') {
      const member = customers.find(c => c.id === newSelectedMemberId);
      if (!member) {
        alert('Pilih member pelanggan terlebih dahulu!');
        return;
      }
      custName = member.name;
      custPhone = member.phone;
      custId = member.id;
    } else {
      if (!custName) {
        alert('Masukkan nama pelanggan kasbon!');
        return;
      }
    }

    createDirectPiutang({
      customerId: custId,
      customerName: custName,
      customerPhone: custPhone || undefined,
      totalAmount: newTotalAmount,
      downPayment: newDownPayment,
      dueDate: newDueDate,
      notes: newNotes,
    });

    setShowAddModal(false);
    setNewCustName('');
    setNewCustPhone('');
    setNewTotalAmount(0);
    setNewDownPayment(0);
    setNewNotes('');
  };

  // Export CSV
  const handleExportCSV = () => {
    const data = filteredList.map(p => ({
      No_Faktur: p.invoiceNumber,
      Nama_Pelanggan: p.customerName,
      Telepon: p.customerPhone || '-',
      Total_Piutang: p.totalAmount,
      Sudah_Bayar: p.paidAmount,
      Sisa_Piutang: p.remainingAmount,
      Jatuh_Tempo: p.dueDate,
      Status: p.status,
      Tanggal_Dibuat: formatDateTime(p.createdAt),
      Keterangan: p.notes || '-',
    }));
    exportToCSV(`laporan_piutang_${new Date().toISOString().slice(0, 10)}.csv`, data);
  };

  // Send WhatsApp Reminder
  const handleSendWAReminder = (p: PiutangRecord) => {
    const phoneClean = (p.customerPhone || '').replace(/[^0-9]/g, '');
    let targetPhone = phoneClean;
    if (targetPhone.startsWith('0')) {
      targetPhone = '62' + targetPhone.slice(1);
    }

    const message = encodeURIComponent(
      `Halo Bapak/Ibu ${p.customerName},\n\nKami dari *${storeProfile.name}* ingin menginformasikan pengingat catatan kasbon/piutang:\n` +
      `• No. Faktur/Bon: *${p.invoiceNumber}*\n` +
      `• Total Belanja: *${formatRupiah(p.totalAmount)}*\n` +
      `• Telah Dibayar: *${formatRupiah(p.paidAmount)}*\n` +
      `• *Sisa Tagihan: ${formatRupiah(p.remainingAmount)}*\n` +
      `• Jatuh Tempo: *${p.dueDate}*\n\n` +
      `Pembayaran dapat dilakukan langsung di kasir toko atau transfer bank. Terima kasih banyak atas kepercayaan Anda berbelanja di tempat kami! 🙏`
    );

    if (targetPhone) {
      window.open(`https://wa.me/${targetPhone}?text=${message}`, '_blank');
    } else {
      navigator.clipboard.writeText(decodeURIComponent(message));
      alert('Nomor HP tidak terdaftar. Teks pesan pengingat telah disalin ke clipboard!');
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-100 overflow-hidden">
      {/* Header Bar */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              Buku Piutang & Kasbon Pelanggan
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 font-bold border border-amber-300">
                {stats.unpaidCount} Aktif
              </span>
            </h1>
            <p className="text-xs text-slate-500">
              Kelola kasbon kasir, cicilan pembayaran, pencatatan jatuh tempo, dan riwayat pelunasan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Ekspor CSV</span>
          </button>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 shadow-sm transition cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Kasbon Manual</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Metric Cards */}
      <div className="px-6 pt-5 pb-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 shrink-0">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Piutang Aktif
            </span>
            <span className="text-2xl font-black font-mono text-red-600">
              {formatRupiah(stats.totalOutstanding)}
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5 font-medium">
              Dari {stats.unpaidCount} faktur belum lunas
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Piutang Jatuh Tempo
            </span>
            <span className={`text-2xl font-black font-mono ${stats.overdueCount > 0 ? 'text-amber-600' : 'text-slate-700'}`}>
              {stats.overdueCount} Faktur
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5 font-medium">
              Perlu segera ditagih
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Piutang Terbayar
            </span>
            <span className="text-2xl font-black font-mono text-emerald-600">
              {formatRupiah(stats.totalPaid)}
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5 font-medium">
              Uang kas masuk dari cicilan/DP
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Riwayat Faktur
            </span>
            <span className="text-2xl font-black font-mono text-slate-800">
              {piutangList.length} Transaksi
            </span>
            <span className="text-[11px] text-slate-500 block mt-0.5 font-medium">
              Termasuk yang sudah lunas
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center">
            <Receipt className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari faktur, nama pelanggan, atau no telepon..."
            className="w-full pl-9 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs self-start md:self-auto">
          <button
            type="button"
            onClick={() => setStatusFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              statusFilter === 'ALL'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Semua ({piutangList.length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('BELUM_LUNAS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              statusFilter === 'BELUM_LUNAS'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Belum Lunas ({stats.unpaidCount})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('JATUH_TEMPO')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              statusFilter === 'JATUH_TEMPO'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Jatuh Tempo ({stats.overdueCount})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('LUNAS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              statusFilter === 'LUNAS'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Lunas ({piutangList.length - stats.unpaidCount})
          </button>
        </div>
      </div>

      {/* Main Table / Content List */}
      <div className="flex-1 px-6 pb-6 overflow-hidden">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs h-full flex flex-col overflow-hidden">
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="py-3 px-4">No. Faktur / Bon</th>
                  <th className="py-3 px-4">Pelanggan</th>
                  <th className="py-3 px-4">Jatuh Tempo</th>
                  <th className="py-3 px-4 text-right">Total Tagihan</th>
                  <th className="py-3 px-4 text-right">Sudah Dibayar</th>
                  <th className="py-3 px-4 text-right">Sisa Piutang</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredList.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-16 text-center text-slate-400">
                      <div className="max-w-sm mx-auto space-y-2">
                        <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
                        <p className="font-bold text-slate-600 text-sm">Tidak Ada Data Piutang</p>
                        <p className="text-xs text-slate-400">
                          {search ? 'Tidak ditemukan data yang cocok dengan pencarian.' : 'Belum ada transaksi kasbon yang tercatat.'}
                        </p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredList.map(p => {
                    const isOverdue = p.status === 'BELUM_LUNAS' && p.dueDate && p.dueDate < todayStr;
                    const isDueToday = p.status === 'BELUM_LUNAS' && p.dueDate === todayStr;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/80 transition group">
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                          <div className="flex flex-col">
                            <span>{p.invoiceNumber}</span>
                            <span className="text-[10px] text-slate-400 font-sans font-normal">
                              {formatDateTime(p.createdAt)}
                            </span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="flex flex-col">
                            <span className="font-bold text-slate-900">{p.customerName}</span>
                            {p.customerPhone && (
                              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                                <Phone className="w-3 h-3 text-slate-400" />
                                <span>{p.customerPhone}</span>
                              </span>
                            )}
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="flex flex-col">
                            <span className="font-semibold text-slate-700">
                              {p.dueDate ? new Date(p.dueDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                            </span>
                            {isOverdue && (
                              <span className="text-[10px] text-red-600 font-bold flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                <span>Lewat Jatuh Tempo</span>
                              </span>
                            )}
                            {isDueToday && (
                              <span className="text-[10px] text-amber-600 font-bold flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>Jatuh Tempo Hari Ini</span>
                              </span>
                            )}
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                          {formatRupiah(p.totalAmount)}
                        </td>

                        <td className="py-3.5 px-4 text-right font-mono text-emerald-600 font-bold">
                          {formatRupiah(p.paidAmount)}
                          {p.payments.length > 0 && (
                            <span className="text-[10px] text-slate-400 block font-sans font-normal">
                              {p.payments.length}x bayar
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-right font-mono font-black text-red-600 text-sm">
                          {formatRupiah(p.remainingAmount)}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          {p.status === 'LUNAS' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>LUNAS</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-100 text-red-800 border border-red-300">
                              <Clock className="w-3 h-3" />
                              <span>BELUM LUNAS</span>
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {p.status === 'BELUM_LUNAS' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setPayModalPiutang(p);
                                  setPayAmount(p.remainingAmount.toString());
                                  setPayNotes('');
                                }}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-black shadow-2xs transition cursor-pointer flex items-center gap-1"
                                title="Catat Pembayaran Cicilan / Pelunasan"
                              >
                                <Banknote className="w-3.5 h-3.5" />
                                <span>Bayar</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => setSelectedPiutang(p)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                              title="Lihat Riwayat Cicilan & Rincian"
                            >
                              <FileText className="w-4 h-4" />
                            </button>

                            <button
                              type="button"
                              onClick={() => setPrintPiutang(p)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                              title="Cetak Tanda Terima Kasbon"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            {p.status === 'BELUM_LUNAS' && (
                              <button
                                type="button"
                                onClick={() => handleSendWAReminder(p)}
                                className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold transition cursor-pointer"
                                title="Kirim Pengingat Tagihan via WhatsApp"
                              >
                                <Share2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ========================================================
          MODAL: BAYAR CICILAN / PELUNASAN PIUTANG
         ======================================================== */}
      {payModalPiutang && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-black text-base">Pembayaran Kasbon / Piutang</h3>
                <p className="text-xs text-slate-400">Faktur: {payModalPiutang.invoiceNumber}</p>
              </div>
              <button
                type="button"
                onClick={() => setPayModalPiutang(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePaySubmit} className="p-6 space-y-4">
              {/* Customer & Debt Summary */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-medium">Pelanggan:</span>
                  <span className="font-bold text-slate-900">{payModalPiutang.customerName}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-medium">Total Hutang Awal:</span>
                  <span className="font-mono font-bold text-slate-700">{formatRupiah(payModalPiutang.totalAmount)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-medium">Sudah Dibayar:</span>
                  <span className="font-mono font-bold text-emerald-600">{formatRupiah(payModalPiutang.paidAmount)}</span>
                </div>
                <div className="flex justify-between items-center text-sm pt-2 border-t border-slate-200">
                  <span className="text-slate-700 font-bold">Sisa Piutang:</span>
                  <span className="font-mono font-black text-red-600 text-base">
                    {formatRupiah(payModalPiutang.remainingAmount)}
                  </span>
                </div>
              </div>

              {/* Payment Amount Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Nominal Pembayaran (Rp) <span className="text-red-600">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                    Rp
                  </span>
                  <input
                    type="number"
                    min={100}
                    max={payModalPiutang.remainingAmount}
                    required
                    autoFocus
                    value={payAmount}
                    onChange={e => setPayAmount(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border-2 border-emerald-500 rounded-xl text-lg font-mono font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                    placeholder="0"
                  />
                </div>

                {/* Quick Fill Buttons */}
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setPayAmount(payModalPiutang.remainingAmount.toString())}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 text-xs font-bold rounded-lg transition"
                  >
                    Lunasi Semua ({formatRupiah(payModalPiutang.remainingAmount)})
                  </button>
                  {payModalPiutang.remainingAmount >= 20000 && (
                    <button
                      type="button"
                      onClick={() => setPayAmount(Math.round(payModalPiutang.remainingAmount / 2).toString())}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition"
                    >
                      50% ({formatRupiah(Math.round(payModalPiutang.remainingAmount / 2))})
                    </button>
                  )}
                </div>
              </div>

              {/* Payment Method */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Metode Pembayaran</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPayMethod('TUNAI')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      payMethod === 'TUNAI'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Banknote className="w-4 h-4" />
                    <span>Uang Tunai (Kas)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayMethod('TRANSFER')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      payMethod === 'TRANSFER'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Transfer Bank</span>
                  </button>
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">Catatan / Keterangan (Opsional)</label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={e => setPayNotes(e.target.value)}
                  placeholder="Misal: Cicilan ke-2 titip lewat tetangga..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {payFeedback && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{payFeedback}</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayModalPiutang(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                >
                  Simpan Pembayaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: TAMBAH KASBON / PIUTANG MANUAL
         ======================================================== */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 bg-amber-500 text-slate-950 flex items-center justify-between">
              <div>
                <h3 className="font-black text-base">Tambah Catatan Kasbon / Piutang Manual</h3>
                <p className="text-xs text-amber-950 font-medium">
                  Catat hutang belanja pelanggan langsung ke pembukuan
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-950 hover:bg-amber-400 p-1.5 rounded-xl transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
              {/* Customer Type Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Pilih Tipe Pelanggan</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewCustType('MEMBER')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      newCustType === 'MEMBER'
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    Member Terdaftar ({customers.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewCustType('CUSTOM')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      newCustType === 'CUSTOM'
                        ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    Input Pelanggan Bebas
                  </button>
                </div>
              </div>

              {newCustType === 'MEMBER' ? (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    Pilih Member <span className="text-red-600">*</span>
                  </label>
                  <select
                    required
                    value={newSelectedMemberId}
                    onChange={e => setNewSelectedMemberId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="">-- Pilih Member Toko --</option>
                    {customers.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} - {c.phone} (Hutang Aktif: {formatRupiah(c.totalDebt || 0)})
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">
                      Nama Pelanggan <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={newCustName}
                      onChange={e => setNewCustName(e.target.value)}
                      placeholder="Nama pembeli kasbon..."
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">Nomor WhatsApp / HP</label>
                    <input
                      type="tel"
                      value={newCustPhone}
                      onChange={e => setNewCustPhone(e.target.value)}
                      placeholder="0812xxxx..."
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>
              )}

              {/* Financial Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    Total Kasbon (Rp) <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    min={1000}
                    step={1000}
                    required
                    value={newTotalAmount || ''}
                    onChange={e => setNewTotalAmount(parseFloat(e.target.value) || 0)}
                    placeholder="100000"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Uang Muka (DP Awal) (Rp)</label>
                  <input
                    type="number"
                    min={0}
                    step={1000}
                    value={newDownPayment || ''}
                    onChange={e => setNewDownPayment(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Sisa & Jatuh Tempo */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Sisa Hutang Bersih</label>
                  <div className="w-full px-3 py-2 bg-red-50 border border-red-200 rounded-xl text-xs font-mono font-black text-red-600">
                    {formatRupiah(Math.max(0, newTotalAmount - newDownPayment))}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    Tanggal Jatuh Tempo <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={newDueDate}
                    onChange={e => setNewDueDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Keterangan / Barang Belanja */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">Keterangan / Rincian Barang</label>
                <textarea
                  rows={2}
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  placeholder="Misal: Beras 1 sak, Minyak 2L, Telur 1kg..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                >
                  Simpan Catatan Kasbon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: DETAIL & RIWAYAT PEMBAYARAN CICILAN
         ======================================================== */}
      {selectedPiutang && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-800 text-amber-400">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base">Rincian Faktur Piutang</h3>
                  <p className="text-xs text-slate-400">{selectedPiutang.invoiceNumber}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPiutang(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              {/* Header Info */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Nama Pelanggan:</span>
                  <span className="font-bold text-slate-900">{selectedPiutang.customerName}</span>
                </div>
                {selectedPiutang.customerPhone && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">No. WhatsApp/HP:</span>
                    <span className="font-bold text-slate-800">{selectedPiutang.customerPhone}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">Tanggal Dibuat:</span>
                  <span className="font-medium text-slate-700">{formatDateTime(selectedPiutang.createdAt)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Jatuh Tempo:</span>
                  <span className="font-bold text-red-600">{selectedPiutang.dueDate}</span>
                </div>
                {selectedPiutang.notes && (
                  <div className="pt-2 border-t border-slate-200">
                    <span className="text-slate-500 block mb-0.5">Catatan / Keterangan:</span>
                    <p className="text-slate-800 bg-white p-2 rounded-lg border border-slate-200">
                      {selectedPiutang.notes}
                    </p>
                  </div>
                )}
              </div>

              {/* Financial Balance */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-slate-100 p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-bold uppercase block">Total Hutang</span>
                  <span className="text-sm font-mono font-black text-slate-900">
                    {formatRupiah(selectedPiutang.totalAmount)}
                  </span>
                </div>
                <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                  <span className="text-[10px] text-emerald-700 font-bold uppercase block">Telah Dibayar</span>
                  <span className="text-sm font-mono font-black text-emerald-600">
                    {formatRupiah(selectedPiutang.paidAmount)}
                  </span>
                </div>
                <div className="bg-red-50 p-3 rounded-xl border border-red-200">
                  <span className="text-[10px] text-red-700 font-bold uppercase block">Sisa Hutang</span>
                  <span className="text-sm font-mono font-black text-red-600">
                    {formatRupiah(selectedPiutang.remainingAmount)}
                  </span>
                </div>
              </div>

              {/* Installments History */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider">
                    Riwayat Pembayaran & Cicilan ({selectedPiutang.payments.length})
                  </h4>
                </div>

                {selectedPiutang.payments.length === 0 ? (
                  <div className="p-4 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 text-xs text-slate-400">
                    Belum ada pembayaran atau uang muka yang dicatat.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {selectedPiutang.payments.map(pay => (
                      <div
                        key={pay.id}
                        className="bg-white border border-slate-200 rounded-xl p-3 flex items-center justify-between text-xs shadow-2xs"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-black text-emerald-600 text-sm">
                              +{formatRupiah(pay.amount)}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 font-bold text-slate-700">
                              {pay.paymentMethod}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            {formatDateTime(pay.paidAt)} • Kasir: {pay.cashierName}
                          </span>
                          {pay.notes && (
                            <span className="text-[11px] text-slate-600 italic block mt-0.5">
                              Catatan: {pay.notes}
                            </span>
                          )}
                        </div>
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex gap-2">
              <button
                type="button"
                onClick={() => setSelectedPiutang(null)}
                className="flex-1 py-2.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl transition"
              >
                Tutup
              </button>
              {selectedPiutang.status === 'BELUM_LUNAS' && (
                <button
                  type="button"
                  onClick={() => {
                    setPayModalPiutang(selectedPiutang);
                    setPayAmount(selectedPiutang.remainingAmount.toString());
                    setSelectedPiutang(null);
                  }}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition"
                >
                  Bayar Sekarang
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: CETAK STRUK / BUKTI KASBON PIUTANG
         ======================================================== */}
      {printPiutang && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
            <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between">
              <span className="text-xs font-bold">Cetak Tanda Terima Kasbon</span>
              <button
                type="button"
                onClick={() => setPrintPiutang(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Thermal Struk Preview */}
            <div className="p-6 bg-slate-50 flex justify-center">
              <div
                id="thermal-piutang-receipt"
                className="w-full max-w-[280px] bg-white p-4 border border-slate-300 shadow-md font-mono text-[11px] leading-tight text-slate-900 space-y-2"
              >
                <div className="text-center pb-2 border-b border-dashed border-slate-400">
                  <div className="font-bold text-sm uppercase">{storeProfile.name}</div>
                  <div className="text-[10px] text-slate-600">{storeProfile.address}</div>
                  <div className="text-[10px] text-slate-600">Telp: {storeProfile.phone}</div>
                </div>

                <div className="text-center font-bold text-xs py-1 border-b border-dashed border-slate-400">
                  BUKTI KASBON / PIUTANG
                </div>

                <div className="space-y-0.5 text-[10px]">
                  <div className="flex justify-between">
                    <span>No. Faktur:</span>
                    <span className="font-bold">{printPiutang.invoiceNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tanggal:</span>
                    <span>{printPiutang.createdAt.slice(0, 10)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pelanggan:</span>
                    <span className="font-bold">{printPiutang.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Jatuh Tempo:</span>
                    <span className="font-bold text-red-600">{printPiutang.dueDate}</span>
                  </div>
                </div>

                <div className="border-t border-b border-dashed border-slate-400 py-1.5 space-y-1">
                  <div className="flex justify-between">
                    <span>Total Tagihan:</span>
                    <span className="font-bold">{formatRupiah(printPiutang.totalAmount)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700">
                    <span>Telah Dibayar:</span>
                    <span>{formatRupiah(printPiutang.paidAmount)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-red-700 text-xs pt-1 border-t border-slate-200">
                    <span>SISA PIUTANG:</span>
                    <span>{formatRupiah(printPiutang.remainingAmount)}</span>
                  </div>
                </div>

                {printPiutang.notes && (
                  <div className="text-[9px] text-slate-600 italic">
                    Ket: {printPiutang.notes}
                  </div>
                )}

                <div className="pt-2 text-center text-[9px] text-slate-500 space-y-1">
                  <p>Harap simpan struk ini sebagai bukti kasbon resmi yang sah.</p>
                  <p className="font-bold">Terima Kasih</p>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-white flex gap-2">
              <button
                type="button"
                onClick={() => setPrintPiutang(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Nota</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
