import React, { useState, useEffect } from 'react';
import { UserPlus, UserCheck, Phone, MapPin, Percent, DollarSign, FileText, X, CheckCircle2 } from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { CustomerMember } from '../../types/pos';
import { formatRupiah } from '../../utils/formatters';

interface PelangganModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (customer: CustomerMember) => void;
  editCustomer?: CustomerMember | null;
}

export const PelangganModal: React.FC<PelangganModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  editCustomer,
}) => {
  const { customers, addCustomer, updateCustomer } = usePOS();

  // Generate next member code like MBR-004
  const generateNextMemberCode = () => {
    const existingCodes = customers.map(c => c.memberCode).filter(Boolean);
    let maxNum = 0;
    existingCodes.forEach(code => {
      const match = code.match(/MBR-(\d+)/i);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxNum) maxNum = num;
      }
    });
    return `MBR-${String(maxNum + 1).padStart(3, '0')}`;
  };

  const [formData, setFormData] = useState({
    memberCode: '',
    name: '',
    phone: '',
    discountRate: 0,
    creditLimit: 500000,
    address: '',
    notes: '',
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (isOpen) {
      if (editCustomer) {
        setFormData({
          memberCode: editCustomer.memberCode || '',
          name: editCustomer.name || '',
          phone: editCustomer.phone || '',
          discountRate: editCustomer.discountRate || 0,
          creditLimit: editCustomer.creditLimit ?? 500000,
          address: editCustomer.address || '',
          notes: editCustomer.notes || '',
        });
      } else {
        setFormData({
          memberCode: generateNextMemberCode(),
          name: '',
          phone: '',
          discountRate: 2, // default 2% diskon member
          creditLimit: 500000, // default limit kasbon Rp 500.000
          address: '',
          notes: '',
        });
      }
      setErrors({});
    }
  }, [isOpen, editCustomer]);

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Nama pelanggan wajib diisi';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Nomor HP / WhatsApp wajib diisi';
    }
    if (!formData.memberCode.trim()) {
      newErrors.memberCode = 'Kode member wajib diisi';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (editCustomer) {
      const updated: CustomerMember = {
        ...editCustomer,
        memberCode: formData.memberCode.trim().toUpperCase(),
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        discountRate: Number(formData.discountRate) || 0,
        creditLimit: Number(formData.creditLimit) || 0,
        address: formData.address.trim(),
        notes: formData.notes.trim(),
      };
      updateCustomer(updated);
      if (onSuccess) onSuccess(updated);
    } else {
      const newCustomerData: Omit<CustomerMember, 'id' | 'points' | 'totalSpent'> = {
        memberCode: formData.memberCode.trim().toUpperCase(),
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        discountRate: Number(formData.discountRate) || 0,
        creditLimit: Number(formData.creditLimit) || 0,
        address: formData.address.trim(),
        notes: formData.notes.trim(),
        totalDebt: 0,
      };
      addCustomer(newCustomerData);

      // find newly added or construct
      const createdCustomer: CustomerMember = {
        ...newCustomerData,
        id: 'cust-' + Date.now(),
        points: 0,
        totalSpent: 0,
      };
      if (onSuccess) onSuccess(createdCustomer);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 animate-in fade-in">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Modal */}
        <div className="p-4 bg-gradient-to-r from-red-700 via-red-800 to-amber-700 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              {editCustomer ? <UserCheck className="w-5 h-5 text-yellow-300" /> : <UserPlus className="w-5 h-5 text-yellow-300" />}
            </div>
            <div>
              <h3 className="font-black text-sm tracking-wide">
                {editCustomer ? 'Edit Data Pelanggan / Member' : 'Tambah Data Pelanggan Baru'}
              </h3>
              <p className="text-[11px] text-yellow-200/80">
                Pencatatan member minimarket, diskon otomatis, dan limit kasbon
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-black/20 hover:bg-black/40 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Isi */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* Baris 1: Kode Member & Diskon */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="font-bold text-slate-700 block mb-1">
                Kode Member <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.memberCode}
                  onChange={e => setFormData({ ...formData, memberCode: e.target.value })}
                  placeholder="Contoh: MBR-001"
                  className={`w-full bg-slate-50 border rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:bg-white ${
                    errors.memberCode ? 'border-red-500' : 'border-slate-300 focus:border-red-600'
                  }`}
                />
              </div>
              {errors.memberCode && <p className="text-[10px] text-red-500 mt-0.5">{errors.memberCode}</p>}
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Diskon Member (%)
              </label>
              <div className="relative flex items-center">
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  value={formData.discountRate}
                  onChange={e => setFormData({ ...formData, discountRate: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-red-600 pr-7"
                />
                <Percent className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Baris 2: Nama Lengkap */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Nama Lengkap Pelanggan <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              placeholder="Contoh: Ibu Hj. Nur Hasanah"
              className={`w-full bg-slate-50 border rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:bg-white ${
                errors.name ? 'border-red-500' : 'border-slate-300 focus:border-red-600'
              }`}
            />
            {errors.name && <p className="text-[10px] text-red-500 mt-0.5">{errors.name}</p>}
          </div>

          {/* Baris 3: No HP / WhatsApp & Limit Kasbon */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                No. HP / WhatsApp <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <input
                  type="text"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="0812xxxx / 62812xxxx"
                  className={`w-full bg-slate-50 border rounded-xl pl-8 pr-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:bg-white ${
                    errors.phone ? 'border-red-500' : 'border-slate-300 focus:border-red-600'
                  }`}
                />
                <Phone className="w-3.5 h-3.5 text-emerald-600 absolute left-2.5 pointer-events-none" />
              </div>
              {errors.phone && <p className="text-[10px] text-red-500 mt-0.5">{errors.phone}</p>}
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Limit Kasbon / Kredit (Rp)
              </label>
              <div className="relative flex items-center">
                <input
                  type="number"
                  min="0"
                  step="50000"
                  value={formData.creditLimit}
                  onChange={e => setFormData({ ...formData, creditLimit: parseInt(e.target.value, 10) || 0 })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-8 pr-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-red-600"
                />
                <DollarSign className="w-3.5 h-3.5 text-amber-600 absolute left-2.5 pointer-events-none" />
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Maks: {formatRupiah(formData.creditLimit)}
              </span>
            </div>
          </div>

          {/* Baris 4: Alamat */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Alamat Rumah / Domisili
            </label>
            <div className="relative">
              <input
                type="text"
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                placeholder="Contoh: Jl. Merpati Blok B No. 12 RT 04/02"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-8 pr-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-red-600"
              />
              <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
            </div>
          </div>

          {/* Baris 5: Catatan */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Catatan Khusus (Opsional)
            </label>
            <div className="relative">
              <input
                type="text"
                value={formData.notes}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Contoh: Pegawai kantor seberang, pembayaran tanggal 25"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-8 pr-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-red-600"
              />
              <FileText className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
            </div>
          </div>

          {/* Tombol Simpan & Batal */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 font-bold hover:bg-slate-100 transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-black shadow-md flex items-center gap-1.5 transition cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{editCustomer ? 'Simpan Perubahan' : 'Daftarkan Pelanggan'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
