import React, { useState, useEffect, useRef } from 'react';
import { Lock, Eye, EyeOff, LogOut, AlertCircle, CheckCircle, ShieldCheck } from 'lucide-react';
import { usePOS } from '../../context/POSContext';

interface LockScreenModalProps {
  onUnlock: () => void;
}

export const LockScreenModal: React.FC<LockScreenModalProps> = ({ onUnlock }) => {
  const { currentUser, users, logout } = usePOS();
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Focus pin input on mount
    inputRef.current?.focus();
  }, []);

  const handleKeypadPress = (val: string) => {
    setPinError('');
    if (val === 'CLEAR') {
      setPinInput('');
    } else if (val === 'BACKSPACE') {
      setPinInput(prev => prev.slice(0, -1));
    } else {
      if (pinInput.length < 8) {
        setPinInput(prev => prev + val);
      }
    }
  };

  const handleUnlockSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const cleanPin = (pinInput || '').trim();
    if (!cleanPin) {
      setPinError(`Masukkan PIN untuk ${currentUser?.name || 'Kasir'}`);
      inputRef.current?.focus();
      return;
    }

    // Always reference freshest user data from users list
    const freshUser = users.find(u => u.id === currentUser?.id) || currentUser;
    const isOwner = users.some(u => u.role === 'OWNER' && (u.pin || '').trim() === cleanPin);

    if (cleanPin === (freshUser?.pin || '').trim() || isOwner) {
      setPinError('');
      setPinInput('');
      onUnlock();
    } else {
      setPinError(`PIN salah! Masukkan PIN yang sesuai untuk ${freshUser.name} atau PIN Owner`);
      setPinInput('');
      inputRef.current?.focus();
    }
  };

  const handleSwitchUser = () => {
    // Log out to return to the main login screen
    logout();
    onUnlock();
  };

  return (
    <div
      id="pos-lock-screen-modal"
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-200"
    >
      <div className="bg-white text-slate-900 w-full max-w-sm sm:max-w-md rounded-3xl p-5 sm:p-6 shadow-2xl border-2 border-yellow-400 text-center space-y-4">
        {/* Lock Icon Banner */}
        <div className="relative mx-auto w-14 h-14 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center text-2xl font-black shadow-inner border border-red-200">
          <Lock className="w-7 h-7 text-red-600" />
          <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-yellow-400 border-2 border-white flex items-center justify-center text-[9px] font-bold text-slate-900">
            !
          </span>
        </div>

        {/* Title & Active Cashier Badge */}
        <div>
          <h3 className="font-black text-xl text-slate-900 tracking-tight">KASIR TERKUNCI</h3>
          <p className="text-xs text-slate-500 mt-1">
            Layar dikunci untuk keamanan transaksi. Masukkan PIN kasir aktif untuk melanjutkan.
          </p>

          {/* Active Cashier Identity Card */}
          <div className="mt-3 bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center justify-between text-left">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-red-600 text-white font-black text-base flex items-center justify-center shadow-xs">
                {currentUser.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm text-slate-900 leading-tight">
                    {currentUser.name}
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-red-100 text-red-700">
                    {currentUser.role}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-mono">
                  Username: @{currentUser.username} • ID: {currentUser.id}
                </div>
              </div>
            </div>

            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
          </div>
        </div>

        {/* Form Input PIN */}
        <form onSubmit={handleUnlockSubmit} className="space-y-3">
          <div className="relative">
            <input
              ref={inputRef}
              type={showPassword ? 'text' : 'password'}
              maxLength={8}
              autoFocus
              value={pinInput}
              onChange={e => {
                setPinError('');
                setPinInput(e.target.value);
              }}
              placeholder="Ketik PIN Kasir..."
              className="w-full text-center tracking-[0.4em] text-2xl font-black py-3 px-10 bg-slate-100 border-2 border-slate-300 rounded-2xl focus:border-red-600 focus:bg-white focus:outline-none transition"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              tabIndex={-1}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              title={showPassword ? 'Sembunyikan PIN' : 'Tampilkan PIN'}
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          {/* Error Message */}
          {pinError ? (
            <div className="flex items-center justify-center gap-1.5 text-xs text-red-600 font-bold bg-red-50 py-1.5 px-3 rounded-xl border border-red-200 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{pinError}</span>
            </div>
          ) : (
            <p className="text-[11px] text-slate-400">
              Kunci hanya dapat dibuka menggunakan PIN dari kasir aktif di atas.
            </p>
          )}

          {/* On-screen Touch Keypad */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
              <button
                key={num}
                type="button"
                onClick={() => handleKeypadPress(num)}
                className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 font-mono font-black text-lg rounded-xl transition cursor-pointer"
              >
                {num}
              </button>
            ))}
            <button
              type="button"
              onClick={() => handleKeypadPress('CLEAR')}
              className="py-2.5 bg-amber-100 hover:bg-amber-200 active:bg-amber-300 text-amber-800 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              CLEAR
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('0')}
              className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 font-mono font-black text-lg rounded-xl transition cursor-pointer"
            >
              0
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('BACKSPACE')}
              className="py-2.5 bg-rose-100 hover:bg-rose-200 active:bg-rose-300 text-rose-800 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              ⌫ HAPUS
            </button>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-red-600 hover:bg-red-700 active:scale-98 text-white rounded-2xl font-black text-sm shadow-md transition cursor-pointer flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>Buka Kunci Layar</span>
            </button>

            <button
              type="button"
              onClick={handleSwitchUser}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5 text-slate-500" />
              <span>Ganti Kasir / Keluar ke Layar Login</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
