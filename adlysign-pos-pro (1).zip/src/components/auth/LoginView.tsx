import React, { useState, useEffect, useRef } from 'react';
import {
  Lock,
  UserCheck,
  Shield,
  KeyRound,
  Eye,
  EyeOff,
  Store,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Users,
  LogIn,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { User, UserRole } from '../../types/pos';

export const LoginView: React.FC = () => {
  const { users, currentUser, storeProfile, license, login } = usePOS();

  // Active registered users only
  const activeUsers = users.filter(u => u.isActive !== false);

  // Selected user for login
  const [selectedUser, setSelectedUser] = useState<User>(() => {
    // Default to the first cashier, or first user
    return activeUsers.find(u => u.role === 'KASIR') || activeUsers[0];
  });

  const [loginMode, setLoginMode] = useState<'PICKER' | 'MANUAL'>('PICKER');
  const [manualUsername, setManualUsername] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const pinInputRef = useRef<HTMLInputElement>(null);

  // Live Digital Clock
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  const dateStr = `${days[currentTime.getDay()]}, ${currentTime.getDate()} ${months[currentTime.getMonth()]} ${currentTime.getFullYear()}`;
  const timeStr = currentTime.toTimeString().split(' ')[0];

  useEffect(() => {
    // Focus pin input whenever selected user changes
    setPinInput('');
    setErrorMessage('');
    setTimeout(() => {
      pinInputRef.current?.focus();
    }, 100);
  }, [selectedUser, loginMode]);

  const handleSelectUser = (user: User) => {
    setSelectedUser(user);
    setManualUsername(user.username);
    setPinInput('');
    setErrorMessage('');
    pinInputRef.current?.focus();
  };

  const handleKeypadPress = (val: string) => {
    setErrorMessage('');
    if (val === 'CLEAR') {
      setPinInput('');
    } else if (val === 'BACKSPACE') {
      setPinInput(prev => prev.slice(0, -1));
    } else {
      if (pinInput.length < 8) {
        setPinInput(prev => prev + val);
      }
    }
  };

  const handleSubmitLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage('');

    let targetUser = selectedUser;
    if (loginMode === 'MANUAL') {
      const cleanManual = (manualUsername || '').trim();
      const found = users.find(
        u => (u.username || '').toLowerCase() === cleanManual.toLowerCase() || u.id === cleanManual
      );
      if (!found) {
        setErrorMessage('Username kasir tidak ditemukan.');
        return;
      }
      targetUser = found;
    }

    if (!targetUser) {
      setErrorMessage('Pilih akun kasir terlebih dahulu.');
      return;
    }

    const cleanPin = (pinInput || '').trim();
    if (!cleanPin) {
      setErrorMessage(`Masukkan PIN untuk ${targetUser.name || 'kasir'}`);
      pinInputRef.current?.focus();
      return;
    }

    setIsLoggingIn(true);
    const result = login(targetUser.id, cleanPin);

    if (!result.success) {
      setIsLoggingIn(false);
      setErrorMessage(result.message || 'PIN atau Password salah!');
      setPinInput('');
      pinInputRef.current?.focus();
    }
    // On success, isAuthenticated becomes true and POSMainApp shows the main view automatically
  };

  const getRoleBadgeStyle = (role: UserRole) => {
    switch (role) {
      case 'OWNER':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'ADMIN':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'SUPERVISOR':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'KASIR':
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <div className="min-h-screen w-screen bg-slate-950 flex flex-col justify-between overflow-y-auto selection:bg-red-600 selection:text-white font-sans">
      {/* Top Store Branding Bar */}
      <header className="alfa-header py-3 px-4 sm:px-8 shadow-lg shrink-0 select-none">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white text-slate-950 flex items-center justify-center text-xl font-black shadow-md border-2 border-yellow-300 shrink-0">
              🥨
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-black text-sm sm:text-base lg:text-lg tracking-wider text-white uppercase drop-shadow-xs truncate">
                  {storeProfile.name || 'MINIMARKET BERKAH JAYA'}
                </h1>
                <span className="px-1.5 py-0.5 rounded bg-yellow-400 text-slate-950 text-[10px] font-black uppercase tracking-wider shrink-0">
                  POS RETAIL
                </span>
              </div>
              <p className="text-[11px] text-yellow-100/90 truncate">
                {storeProfile.address || 'Sistem Kasir & Manajemen Minimarket Terpadu'}
              </p>
            </div>
          </div>

          {/* Right: Live Terminal Clock & Status */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden sm:flex flex-col items-end justify-center bg-black/40 px-3 py-1 rounded-xl border border-white/15 shadow-inner leading-tight text-right">
              <span className="text-[10px] font-semibold text-amber-300">
                {dateStr}
              </span>
              <span className="text-sm font-black font-mono text-white tracking-widest">
                {timeStr}
              </span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/70 border border-emerald-400/40 rounded-xl text-emerald-300 text-[11px] font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono">TERMINAL SIAP</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Login Card Area */}
      <main className="flex-1 flex items-center justify-center p-3 sm:p-6 my-auto">
        <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border-2 border-yellow-400 overflow-hidden flex flex-col md:flex-row">
          {/* Left Column: Cashier Account Selector */}
          <div className="md:w-1/2 p-5 sm:p-6 bg-slate-50 border-b md:border-b-0 md:border-r border-slate-200 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-black text-lg text-slate-900 flex items-center gap-2">
                    <Users className="w-5 h-5 text-red-600" />
                    <span>PILIH KASIR / PETUGAS</span>
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Pilih akun pengguna yang bertugas di kasir saat ini
                  </p>
                </div>
              </div>

              {/* Mode Toggle: Quick Picker vs Manual Input */}
              <div className="flex bg-slate-200/80 p-1 rounded-xl text-xs font-bold gap-1">
                <button
                  type="button"
                  onClick={() => setLoginMode('PICKER')}
                  className={`flex-1 py-1.5 rounded-lg transition cursor-pointer text-center ${
                    loginMode === 'PICKER'
                      ? 'bg-white text-slate-900 shadow-xs font-black'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Pilih Kasir Cepat
                </button>
                <button
                  type="button"
                  onClick={() => setLoginMode('MANUAL')}
                  className={`flex-1 py-1.5 rounded-lg transition cursor-pointer text-center ${
                    loginMode === 'MANUAL'
                      ? 'bg-white text-slate-900 shadow-xs font-black'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Ketik Username / ID
                </button>
              </div>

              {/* Content Mode 1: Quick Cashier Grid */}
              {loginMode === 'PICKER' ? (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {activeUsers.map(user => {
                    const isSelected = selectedUser.id === user.id;
                    return (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => handleSelectUser(user)}
                        className={`w-full p-3 rounded-2xl border-2 text-left transition flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-red-50/80 border-red-600 shadow-sm ring-1 ring-red-600'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm text-white shrink-0 ${
                              user.role === 'OWNER'
                                ? 'bg-purple-600'
                                : user.role === 'ADMIN'
                                ? 'bg-blue-600'
                                : user.role === 'SUPERVISOR'
                                ? 'bg-amber-600'
                                : 'bg-red-600'
                            }`}
                          >
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-extrabold text-sm text-slate-900 leading-tight">
                              {user.name}
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                              @{user.username}
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider border ${getRoleBadgeStyle(
                              user.role
                            )}`}
                          >
                            {user.role}
                          </span>
                          {isSelected && (
                            <span className="flex items-center gap-0.5 text-[11px] font-bold text-red-600">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Dipilih</span>
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                /* Content Mode 2: Manual Username Input */
                <div className="space-y-3 py-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Username atau Kode Petugas:
                    </label>
                    <input
                      type="text"
                      value={manualUsername}
                      onChange={e => {
                        const val = e.target.value;
                        setManualUsername(val);
                        setErrorMessage('');
                        const cleanVal = (val || '').trim().toLowerCase();
                        if (cleanVal) {
                          const found = users.find(
                            u => (u.username || '').toLowerCase() === cleanVal
                          );
                          if (found) setSelectedUser(found);
                        }
                      }}
                      placeholder="Contoh: kasir1, kasir2, spv, admin..."
                      className="w-full px-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:border-red-600 focus:outline-none"
                    />
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Masukkan username akun kasir yang telah terdaftar di database karyawan toko.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: PIN Input & Numeric Keypad */}
          <div className="md:w-1/2 p-5 sm:p-6 flex flex-col justify-between">
            <div>
              {/* Selected User Header Card */}
              <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-md mb-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-red-600 text-white flex items-center justify-center font-black text-xl shadow-inner">
                    {selectedUser.name.charAt(0)}
                  </div>
                  <div>
                    <span className="text-[10px] text-yellow-300 uppercase font-black tracking-widest block">
                      PETUGAS KASIR
                    </span>
                    <h3 className="font-black text-base text-white leading-tight">
                      {selectedUser.name}
                    </h3>
                    <div className="text-[11px] text-slate-300 font-mono mt-0.5">
                      Wewenang: <span className="text-yellow-400 font-bold">{selectedUser.role}</span>
                    </div>
                  </div>
                </div>

                <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-yellow-400">
                  <KeyRound className="w-5 h-5" />
                </div>
              </div>

              {/* Form Input PIN */}
              <form onSubmit={handleSubmitLogin} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Masukkan PIN / Password Kasir:
                  </label>
                  <div className="relative">
                    <input
                      ref={pinInputRef}
                      type={showPassword ? 'text' : 'password'}
                      maxLength={8}
                      autoFocus
                      value={pinInput}
                      onChange={e => {
                        setErrorMessage('');
                        setPinInput(e.target.value);
                      }}
                      placeholder="Ketik 4-Digit PIN..."
                      className="w-full text-center tracking-[0.4em] text-2xl font-black py-3 px-10 bg-slate-100 border-2 border-slate-300 rounded-2xl focus:border-red-600 focus:bg-white focus:outline-none transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      tabIndex={-1}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
                      title={showPassword ? 'Sembunyikan PIN' : 'Tampilkan PIN'}
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Error Banner */}
                {errorMessage && (
                  <div className="flex items-center gap-1.5 text-xs text-red-600 font-bold bg-red-50 p-2 rounded-xl border border-red-200 animate-shake">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Touchscreen Numeric Keypad */}
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleKeypadPress(num)}
                      className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 font-mono font-black text-lg rounded-xl transition cursor-pointer"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('CLEAR')}
                    className="py-2.5 bg-amber-100 hover:bg-amber-200 active:bg-amber-300 text-amber-900 font-bold text-xs rounded-xl transition cursor-pointer"
                  >
                    CLEAR
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('0')}
                    className="py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 font-mono font-black text-lg rounded-xl transition cursor-pointer"
                  >
                    0
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('BACKSPACE')}
                    className="py-2.5 bg-rose-100 hover:bg-rose-200 active:bg-rose-300 text-rose-900 font-bold text-xs rounded-xl transition cursor-pointer"
                  >
                    ⌫ HAPUS
                  </button>
                </div>

                {/* Submit Login Button */}
                <button
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-3.5 bg-red-600 hover:bg-red-700 active:scale-98 text-white rounded-2xl font-black text-sm shadow-md transition cursor-pointer flex items-center justify-center gap-2 mt-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{isLoggingIn ? 'Memverifikasi...' : 'Buka & Masuk ke Kasir'}</span>
                </button>
              </form>
            </div>

            <div className="mt-4 text-center">
              <span className="text-[11px] text-slate-400">
                Lupa PIN? Hubungi Owner / Supervisor toko untuk reset PIN petugas.
              </span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer System Info */}
      <footer className="py-2 px-4 text-center text-slate-500 text-xs shrink-0 select-none border-t border-slate-800">
        <span>POS Minimarket Pro • Mode Keamanan Kasir Aktif • Device ID: {license.deviceId}</span>
      </footer>
    </div>
  );
};
