import React, { useState, useRef, useEffect } from 'react';
import {
  QrCode,
  CreditCard,
  Building2,
  Users,
  Store,
  Upload,
  Trash2,
  Edit2,
  Plus,
  CheckCircle2,
  Copy,
  ExternalLink,
  Eye,
  AlertCircle,
  Save,
  Search,
  Phone,
  MessageCircle,
  MapPin,
  Percent,
  DollarSign,
  Printer,
  Sparkles,
  ShieldCheck,
  Check,
  X,
  RefreshCw,
  Settings,
  Lock,
  Coins,
  Gift,
  HelpCircle,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { BankAccount, CustomerMember, MemberPointSettings } from '../../types/pos';
import { INITIAL_MEMBER_POINT_SETTINGS } from '../../data/initialData';
import { formatRupiah } from '../../utils/formatters';
import { PelangganModal } from '../pelanggan/PelangganModal';

export const SettingPembayaranView: React.FC = () => {
  const {
    paymentSettings,
    updatePaymentSettings,
    updateQRISSettings,
    addBankAccount,
    updateBankAccount,
    deleteBankAccount,
    customers,
    deleteCustomer,
    setSelectedCustomer,
    storeProfile,
    updateStoreProfile,
    memberPointSettings,
    updateMemberPointSettings,
  } = usePOS();

  // Active Tab: 'PEMBAYARAN' | 'PELANGGAN' | 'POIN_MEMBER' | 'PROFIL_TOKO'
  const [activeTab, setActiveTab] = useState<'PEMBAYARAN' | 'PELANGGAN' | 'POIN_MEMBER' | 'PROFIL_TOKO'>('PEMBAYARAN');

  // Customer Member Search & Filter
  const [memberFilterCategory, setMemberFilterCategory] = useState<'ALL' | 'POINTS' | 'DEBT' | 'DISCOUNT'>('ALL');

  // Member Points form state
  const [pointForm, setPointForm] = useState<MemberPointSettings>(() => {
    return memberPointSettings || INITIAL_MEMBER_POINT_SETTINGS;
  });
  const [pointSavedToast, setPointSavedToast] = useState(false);

  // Live Simulator state
  const [simSpendAmount, setSimSpendAmount] = useState<number>(100000);
  const [simCustomerPoints, setSimCustomerPoints] = useState<number>(150);

  useEffect(() => {
    if (memberPointSettings) {
      setPointForm(memberPointSettings);
    }
  }, [memberPointSettings]);

  // QRIS form state
  const [qrisForm, setQrisForm] = useState({
    imageUrl: paymentSettings.qris.imageUrl || '',
    merchantName: paymentSettings.qris.merchantName || storeProfile.name || 'MINIMARKET BERKAH JAYA',
    nmid: paymentSettings.qris.nmid || 'ID10202488910',
    notes: paymentSettings.qris.notes || 'Scan via BCA Mobile, BRImo, Livin Mandiri, GoPay, OVO, DANA, ShopeePay, LinkAja',
    isActive: paymentSettings.qris.isActive ?? true,
  });

  const [qrisUrlInput, setQrisUrlInput] = useState('');
  const [qrisSavedToast, setQrisSavedToast] = useState(false);
  const [previewZoom, setPreviewZoom] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Bank account modal state
  const [isBankModalOpen, setIsBankModalOpen] = useState(false);
  const [editingBank, setEditingBank] = useState<BankAccount | null>(null);
  const [bankForm, setBankForm] = useState({
    bankName: 'BCA',
    accountNumber: '',
    accountHolder: storeProfile.name || '',
    notes: '',
    color: '#005baa',
    isActive: true,
  });
  const [copiedBankId, setCopiedBankId] = useState<string | null>(null);

  // Customer Management state
  const [customerSearch, setCustomerSearch] = useState('');
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<CustomerMember | null>(null);

  // Store Profile Form State
  const [storeForm, setStoreForm] = useState({
    name: storeProfile.name,
    address: storeProfile.address,
    phone: storeProfile.phone,
    receiptHeader: storeProfile.receiptHeader || 'Selamat Datang di Minimarket Kami',
    receiptFooter: storeProfile.receiptFooter,
    taxRate: storeProfile.taxRate || 0,
  });
  const [storeSavedToast, setStoreSavedToast] = useState(false);

  // Handle QRIS image file upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Mohon pilih file gambar yang valid (PNG, JPG, JPEG, WEBP).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('Ukuran gambar maksimal adalah 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setQrisForm(prev => ({ ...prev, imageUrl: dataUrl }));
      updateQRISSettings({ imageUrl: dataUrl });
      triggerToast();
    };
    reader.readAsDataURL(file);
  };

  const handleSaveQRIS = (e: React.FormEvent) => {
    e.preventDefault();
    updateQRISSettings({
      imageUrl: qrisForm.imageUrl,
      merchantName: qrisForm.merchantName.trim(),
      nmid: qrisForm.nmid.trim(),
      notes: qrisForm.notes.trim(),
      isActive: qrisForm.isActive,
    });
    triggerToast();
  };

  const handleApplyUrl = () => {
    if (!qrisUrlInput.trim()) return;
    setQrisForm(prev => ({ ...prev, imageUrl: qrisUrlInput.trim() }));
    updateQRISSettings({ imageUrl: qrisUrlInput.trim() });
    setQrisUrlInput('');
    triggerToast();
  };

  const handleRemoveQRISImage = () => {
    if (confirm('Hapus gambar QRIS kustom dan gunakan QRIS generator otomatis?')) {
      setQrisForm(prev => ({ ...prev, imageUrl: '' }));
      updateQRISSettings({ imageUrl: '' });
      triggerToast();
    }
  };

  const triggerToast = () => {
    setQrisSavedToast(true);
    setTimeout(() => setQrisSavedToast(false), 3000);
  };

  // Bank form handler
  const openAddBankModal = () => {
    setEditingBank(null);
    setBankForm({
      bankName: 'BCA',
      accountNumber: '',
      accountHolder: storeProfile.name || 'Minimarket Berkah Jaya',
      notes: '',
      color: '#005baa',
      isActive: true,
    });
    setIsBankModalOpen(true);
  };

  const openEditBankModal = (bank: BankAccount) => {
    setEditingBank(bank);
    setBankForm({
      bankName: bank.bankName,
      accountNumber: bank.accountNumber,
      accountHolder: bank.accountHolder,
      notes: bank.notes || '',
      color: bank.color || '#005baa',
      isActive: bank.isActive,
    });
    setIsBankModalOpen(true);
  };

  const handleSaveBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankForm.accountNumber.trim()) {
      alert('Nomor rekening tidak boleh kosong');
      return;
    }
    if (!bankForm.accountHolder.trim()) {
      alert('Nama pemilik rekening (atas nama) tidak boleh kosong');
      return;
    }

    if (editingBank) {
      updateBankAccount({
        ...editingBank,
        bankName: bankForm.bankName.toUpperCase(),
        accountNumber: bankForm.accountNumber.trim(),
        accountHolder: bankForm.accountHolder.trim(),
        notes: bankForm.notes.trim(),
        color: bankForm.color,
        isActive: bankForm.isActive,
      });
    } else {
      addBankAccount({
        bankName: bankForm.bankName.toUpperCase(),
        accountNumber: bankForm.accountNumber.trim(),
        accountHolder: bankForm.accountHolder.trim(),
        notes: bankForm.notes.trim(),
        color: bankForm.color,
        isActive: bankForm.isActive,
      });
    }

    setIsBankModalOpen(false);
  };

  const copyAccountNumber = (accNo: string, id: string) => {
    navigator.clipboard.writeText(accNo.replace(/[^0-9]/g, ''));
    setCopiedBankId(id);
    setTimeout(() => setCopiedBankId(null), 2000);
  };

  // Store Profile save
  const handleSaveStoreProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateStoreProfile({
      ...storeProfile,
      name: storeForm.name.trim(),
      address: storeForm.address.trim(),
      phone: storeForm.phone.trim(),
      receiptHeader: storeForm.receiptHeader.trim(),
      receiptFooter: storeForm.receiptFooter.trim(),
      taxRate: Number(storeForm.taxRate) || 0,
    });
    setStoreSavedToast(true);
    setTimeout(() => setStoreSavedToast(false), 3000);
  };

  // Member Points save
  const handleSavePoints = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    updateMemberPointSettings(pointForm);
    setPointSavedToast(true);
    setTimeout(() => setPointSavedToast(false), 3000);
  };

  const handleResetPoints = () => {
    if (confirm('Kembalikan aturan poin member ke pengaturan standar minimarket?')) {
      setPointForm(INITIAL_MEMBER_POINT_SETTINGS);
      updateMemberPointSettings(INITIAL_MEMBER_POINT_SETTINGS);
      setPointSavedToast(true);
      setTimeout(() => setPointSavedToast(false), 3000);
    }
  };

  // Filtered customers with search and category tags
  const filteredCustomers = customers.filter(c => {
    const q = customerSearch.trim().toLowerCase();
    const matchSearch =
      !q ||
      c.name.toLowerCase().includes(q) ||
      (c.memberCode && c.memberCode.toLowerCase().includes(q)) ||
      (c.phone && c.phone.includes(q)) ||
      (c.address && c.address.toLowerCase().includes(q));

    if (!matchSearch) return false;

    if (memberFilterCategory === 'POINTS') return (c.points || 0) > 0;
    if (memberFilterCategory === 'DEBT') return (c.totalDebt || 0) > 0;
    if (memberFilterCategory === 'DISCOUNT') return (c.discountRate || 0) > 0;
    return true;
  });

  const totalCustomerDebt = customers.reduce((acc, c) => acc + (c.totalDebt || 0), 0);
  const totalCustomerPoints = customers.reduce((acc, c) => acc + (c.points || 0), 0);

  // Bank Preset Colors & Names
  const bankPresets = [
    { name: 'BCA', color: '#005baa' },
    { name: 'BRI', color: '#00529c' },
    { name: 'MANDIRI', color: '#002f6c' },
    { name: 'BNI', color: '#f15a24' },
    { name: 'BSI', color: '#00a39d' },
    { name: 'CIMB', color: '#ed1b24' },
    { name: 'JAGO', color: '#5925dc' },
    { name: 'SEABANK', color: '#ff5c00' },
  ];

  return (
    <div className="flex-1 bg-slate-100 flex flex-col overflow-hidden text-slate-800">
      {/* Toast Notifikasi */}
      {qrisSavedToast && (
        <div className="fixed top-16 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-xl border-2 border-emerald-400 flex items-center gap-2.5 text-xs font-bold animate-in fade-in slide-in-from-top-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-200" />
          <span>Pengaturan QRIS & Pembayaran Berhasil Disimpan!</span>
        </div>
      )}
      {storeSavedToast && (
        <div className="fixed top-16 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-xl border-2 border-emerald-400 flex items-center gap-2.5 text-xs font-bold animate-in fade-in slide-in-from-top-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-200" />
          <span>Profil Toko & Struk Berhasil Diperbarui!</span>
        </div>
      )}
      {pointSavedToast && (
        <div className="fixed top-16 right-6 z-50 bg-purple-600 text-white px-5 py-3 rounded-2xl shadow-xl border-2 border-purple-400 flex items-center gap-2.5 text-xs font-bold animate-in fade-in slide-in-from-top-3">
          <Sparkles className="w-5 h-5 text-purple-200" />
          <span>Aturan & Ketentuan Poin Member Berhasil Disimpan!</span>
        </div>
      )}

      {/* Header View */}
      <div className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3.5 shadow-xs shrink-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-600 to-blue-700 text-white flex items-center justify-center shadow-md border border-sky-300 font-black">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black tracking-wide text-slate-900 uppercase">
                Setting Toko & Sistem
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300 text-[10px] font-black uppercase flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Khusus Owner
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Kelola QRIS, rekening bank kasir, data pelanggan, aturan poin member, dan identitas struk toko
            </p>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('PEMBAYARAN')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'PEMBAYARAN'
                ? 'bg-sky-600 text-white shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Setting Pembayaran (QRIS & Bank)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PELANGGAN')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'PELANGGAN'
                ? 'bg-sky-600 text-white shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Data Pelanggan & Member ({customers.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('POIN_MEMBER')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'POIN_MEMBER'
                ? 'bg-purple-600 text-white shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Aturan Poin Member</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PROFIL_TOKO')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'PROFIL_TOKO'
                ? 'bg-sky-600 text-white shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>Profil Toko & Struk</span>
          </button>
        </div>
      </div>

      {/* Konten Utama */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-6">
        {/* ========================================================================= */}
        {/* TAB 1: SETTING PEMBAYARAN (QRIS & REKENING BANK) */}
        {/* ========================================================================= */}
        {activeTab === 'PEMBAYARAN' && (
          <div className="max-w-6xl mx-auto space-y-6">
            {/* 1. BAGIAN SETTING GAMBAR QRIS */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-4 sm:p-5 bg-gradient-to-r from-red-50 via-white to-amber-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-xs">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                      Edit Gambar & Konfigurasi QRIS
                    </h3>
                    <p className="text-xs text-slate-500">
                      Upload foto barcode QRIS resmi toko Anda agar muncul otomatis saat kasir menerima pembayaran non-tunai
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-600">Status QRIS di Kasir:</span>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !qrisForm.isActive;
                      setQrisForm(p => ({ ...p, isActive: next }));
                      updateQRISSettings({ isActive: next });
                    }}
                    className={`px-3 py-1 rounded-full text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                      qrisForm.isActive
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-slate-200 text-slate-600 border border-slate-300'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${qrisForm.isActive ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                    <span>{qrisForm.isActive ? 'Aktif' : 'Nonaktif'}</span>
                  </button>
                </div>
              </div>

              <div className="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Form Pengaturan QRIS */}
                <form onSubmit={handleSaveQRIS} className="lg:col-span-7 space-y-4 text-xs">
                  {/* Upload Box Gambar QRIS */}
                  <div>
                    <label className="font-bold text-slate-700 block mb-1.5">
                      Upload Gambar / Foto QRIS Toko
                    </label>
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-red-300 hover:border-red-500 bg-red-50/40 hover:bg-red-50/80 rounded-2xl p-4 sm:p-5 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2 group"
                    >
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/png,image/jpeg,image/jpg,image/webp"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 group-hover:bg-red-600 group-hover:text-white transition flex items-center justify-center shadow-xs">
                        <Upload className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-xs sm:text-sm">
                          Klik untuk Unggah Gambar QRIS
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Format PNG, JPG, JPEG, WEBP (Maksimal 5MB)
                        </p>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full bg-red-600 text-white font-bold text-[10px]">
                        Pilih File dari Komputer / HP
                      </span>
                    </div>

                    {/* URL Alternatif */}
                    <div className="mt-2.5 flex items-center gap-2">
                      <input
                        type="url"
                        value={qrisUrlInput}
                        onChange={e => setQrisUrlInput(e.target.value)}
                        placeholder="Atau tempelkan link URL gambar QRIS di sini..."
                        className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-red-600 font-mono"
                      />
                      <button
                        type="button"
                        onClick={handleApplyUrl}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition shrink-0 cursor-pointer"
                      >
                        Pasang URL
                      </button>
                    </div>
                  </div>

                  {/* Nama Merchant QRIS */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        Nama Merchant QRIS
                      </label>
                      <input
                        type="text"
                        required
                        value={qrisForm.merchantName}
                        onChange={e => setQrisForm({ ...qrisForm, merchantName: e.target.value })}
                        placeholder="Contoh: MINIMARKET BERKAH JAYA"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-red-600 uppercase"
                      />
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        NMID (National Merchant ID)
                      </label>
                      <input
                        type="text"
                        value={qrisForm.nmid}
                        onChange={e => setQrisForm({ ...qrisForm, nmid: e.target.value })}
                        placeholder="Contoh: ID10202488910"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-red-600"
                      />
                    </div>
                  </div>

                  {/* Catatan / Keterangan Pembayaran */}
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">
                      Catatan / Petunjuk Scan Pelanggan
                    </label>
                    <textarea
                      rows={2}
                      value={qrisForm.notes}
                      onChange={e => setQrisForm({ ...qrisForm, notes: e.target.value })}
                      placeholder="Contoh: Mendukung BCA, Mandiri, BRI, BNI, GoPay, OVO, DANA, ShopeePay, LinkAja"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-red-600"
                    />
                  </div>

                  {/* Tombol Simpan & Hapus */}
                  <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-100">
                    {qrisForm.imageUrl ? (
                      <button
                        type="button"
                        onClick={handleRemoveQRISImage}
                        className="px-3 py-2 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Hapus Gambar Kustom</span>
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400 italic">
                        *Sedang menggunakan generator QRIS standar sistem
                      </span>
                    )}

                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-black shadow-md flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Pengaturan QRIS</span>
                    </button>
                  </div>
                </form>

                {/* Preview Kartu Stand QRIS (Stand Meja Kasir) */}
                <div className="lg:col-span-5 flex flex-col items-center justify-center">
                  <div className="w-full max-w-xs bg-gradient-to-b from-red-600 via-red-700 to-slate-900 p-4 rounded-3xl shadow-xl text-white border-4 border-yellow-400 relative">
                    <div className="bg-white rounded-2xl p-4 text-slate-900 flex flex-col items-center text-center shadow-inner">
                      {/* Logo QRIS Header */}
                      <div className="w-full flex items-center justify-between border-b border-slate-200 pb-2 mb-3">
                        <div className="flex items-center gap-1">
                          <span className="font-black tracking-tighter text-red-600 text-base">QRIS</span>
                          <span className="text-[9px] font-bold text-slate-500 bg-slate-100 px-1 py-0.5 rounded">
                            GPN
                          </span>
                        </div>
                        <span className="text-[9px] font-bold text-slate-400">STAND RESMI</span>
                      </div>

                      <h4 className="font-black text-xs text-slate-900 uppercase tracking-wide truncate w-full">
                        {qrisForm.merchantName || storeProfile.name || 'MINIMARKET KAMI'}
                      </h4>
                      <p className="text-[10px] font-mono text-slate-500">
                        NMID: {qrisForm.nmid || 'ID10202488910'}
                      </p>

                      {/* Display Gambar QRIS atau Placeholder */}
                      <div className="my-3 p-2 bg-white rounded-xl border-2 border-slate-200 shadow-xs w-44 h-44 flex items-center justify-center overflow-hidden relative group">
                        {qrisForm.imageUrl ? (
                          <img
                            src={qrisForm.imageUrl}
                            alt="Preview QRIS"
                            className="w-full h-full object-contain"
                          />
                        ) : (
                          <div className="flex flex-col items-center justify-center p-2 text-slate-400 text-center">
                            <QrCode className="w-16 h-16 text-slate-300 mb-1 animate-pulse" />
                            <span className="text-[10px] font-bold text-slate-500">
                              QR Generator Sistem
                            </span>
                            <span className="text-[9px] text-slate-400">
                              Belum ada gambar kustom diunggah
                            </span>
                          </div>
                        )}

                        {qrisForm.imageUrl && (
                          <button
                            type="button"
                            onClick={() => setPreviewZoom(true)}
                            className="absolute inset-0 bg-black/40 text-white flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition rounded-xl cursor-pointer"
                          >
                            <Eye className="w-6 h-6 mb-1" />
                            <span className="text-[10px] font-bold">Klik Perbesar</span>
                          </button>
                        )}
                      </div>

                      <div className="w-full text-center space-y-1">
                        <p className="text-[10px] font-bold text-slate-700 line-clamp-2">
                          {qrisForm.notes}
                        </p>
                        <div className="flex items-center justify-center gap-1 text-[9px] font-black text-red-600 bg-red-50 py-1 px-2 rounded-lg">
                          <span>SATU QR UNTUK SEMUA PEMBAYARAN</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-center pt-2 text-[10px] text-yellow-200 font-bold">
                      Tampilan Stand Kasir & Pembayaran
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. BAGIAN EDIT REKENING BANK */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-50 via-white to-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center shadow-xs">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                      Edit Rekening Bank Toko
                    </h3>
                    <p className="text-xs text-slate-500">
                      Kelola daftar nomor rekening bank (BCA, BRI, Mandiri, BNI, BSI, dll) untuk pembayaran transfer di kasir
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={openAddBankModal}
                  className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition cursor-pointer shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Rekening Baru</span>
                </button>
              </div>

              <div className="p-4 sm:p-6">
                {paymentSettings.bankAccounts.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                    <Building2 className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-sm text-slate-600">Belum Ada Rekening Bank Ditambahkan</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Klik tombol "+ Tambah Rekening Baru" untuk menambahkan rekening BCA, BRI, Mandiri, dll.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {paymentSettings.bankAccounts.map(acc => {
                      const isCopied = copiedBankId === acc.id;

                      return (
                        <div
                          key={acc.id}
                          className={`rounded-2xl p-4 border transition relative flex flex-col justify-between ${
                            acc.isActive
                              ? 'bg-white border-slate-200 shadow-sm hover:border-blue-400'
                              : 'bg-slate-50 border-slate-200 opacity-60'
                          }`}
                        >
                          <div>
                            {/* Header Card Bank */}
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <div
                                  className="w-8 h-8 rounded-lg text-white font-black text-xs flex items-center justify-center shadow-xs"
                                  style={{ backgroundColor: acc.color || '#005baa' }}
                                >
                                  {acc.bankName.slice(0, 3)}
                                </div>
                                <div>
                                  <h4 className="font-black text-xs text-slate-900">
                                    BANK {acc.bankName}
                                  </h4>
                                  <span className="text-[10px] text-slate-400 block">
                                    {acc.notes || 'Rekening Operasional'}
                                  </span>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() =>
                                  updateBankAccount({
                                    ...acc,
                                    isActive: !acc.isActive,
                                  })
                                }
                                className={`px-2 py-0.5 rounded-full text-[10px] font-black cursor-pointer ${
                                  acc.isActive
                                    ? 'bg-emerald-100 text-emerald-700'
                                    : 'bg-slate-200 text-slate-600'
                                }`}
                              >
                                {acc.isActive ? 'Aktif' : 'Nonaktif'}
                              </button>
                            </div>

                            {/* Nomor Rekening */}
                            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 mb-3">
                              <span className="text-[10px] text-slate-400 block uppercase font-semibold">
                                Nomor Rekening:
                              </span>
                              <div className="flex items-center justify-between mt-0.5">
                                <span className="font-mono font-black text-sm text-slate-900 tracking-wider">
                                  {acc.accountNumber}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => copyAccountNumber(acc.accountNumber, acc.id)}
                                  className="p-1 rounded bg-white hover:bg-slate-200 text-slate-600 transition shadow-2xs cursor-pointer"
                                  title="Salin No Rekening"
                                >
                                  {isCopied ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                              <span className="text-[11px] text-slate-600 font-bold block mt-1">
                                a/n {acc.accountHolder}
                              </span>
                            </div>
                          </div>

                          {/* Tombol Aksi Edit & Hapus */}
                          <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-1.5 text-xs">
                            <button
                              type="button"
                              onClick={() => openEditBankModal(acc)}
                              className="px-2.5 py-1 rounded-lg text-slate-600 hover:text-blue-700 hover:bg-blue-50 font-bold transition flex items-center gap-1 cursor-pointer"
                            >
                              <Edit2 className="w-3 h-3" />
                              <span>Edit</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (confirm(`Hapus rekening Bank ${acc.bankName} (${acc.accountNumber})?`)) {
                                  deleteBankAccount(acc.id);
                                }
                              }}
                              className="px-2.5 py-1 rounded-lg text-slate-400 hover:text-red-700 hover:bg-red-50 font-bold transition flex items-center gap-1 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Hapus</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: DATA PELANGGAN & MEMBER */}
        {/* ========================================================================= */}
        {activeTab === 'PELANGGAN' && (
          <div className="max-w-6xl mx-auto space-y-4">
            {/* Header Statistik Pelanggan */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-black">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-slate-400 block uppercase">
                    Total Member Terdaftar
                  </span>
                  <span className="text-lg font-black text-slate-900">
                    {customers.length} Orang
                  </span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center font-black">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-slate-400 block uppercase">
                    Total Kasbon Pelanggan
                  </span>
                  <span className="text-lg font-black font-mono text-red-600">
                    {formatRupiah(totalCustomerDebt)}
                  </span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center font-black">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-slate-400 block uppercase">
                    Total Poin Belanja Member
                  </span>
                  <span className="text-lg font-black text-purple-700 font-mono">
                    {totalCustomerPoints.toLocaleString('id-ID')} Poin
                  </span>
                </div>
              </div>
            </div>

            {/* Toolbar: Menu Pencarian & Filter Member */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl shadow-xs border border-slate-200 space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                {/* Search Input Box */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-sky-600 absolute left-3.5 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={e => setCustomerSearch(e.target.value)}
                    placeholder="Cari nama member (misal: Budi) atau kode member (misal: MBR-001)..."
                    className="w-full bg-slate-50 border-2 border-slate-200 focus:border-sky-500 rounded-xl pl-10 pr-9 py-2.5 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:bg-white focus:ring-3 focus:ring-sky-100 transition placeholder:text-slate-400 placeholder:font-normal"
                  />
                  {customerSearch && (
                    <button
                      type="button"
                      onClick={() => setCustomerSearch('')}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
                      title="Hapus pencarian"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setActiveTab('POIN_MEMBER')}
                    className="px-3.5 py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    <span>Edit Aturan Poin</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEditingCustomer(null);
                      setIsCustomerModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition cursor-pointer shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah Data Pelanggan Baru</span>
                  </button>
                </div>
              </div>

              {/* Filter Chips & Feedback Indicator */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] font-bold text-slate-400 uppercase mr-1">Filter:</span>
                  <button
                    type="button"
                    onClick={() => setMemberFilterCategory('ALL')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      memberFilterCategory === 'ALL'
                        ? 'bg-sky-600 text-white shadow-2xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    Semua ({customers.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setMemberFilterCategory('POINTS')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                      memberFilterCategory === 'POINTS'
                        ? 'bg-purple-600 text-white shadow-2xs'
                        : 'bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200'
                    }`}
                  >
                    <Coins className="w-3 h-3" />
                    <span>Punya Poin ({customers.filter(c => (c.points || 0) > 0).length})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMemberFilterCategory('DEBT')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                      memberFilterCategory === 'DEBT'
                        ? 'bg-red-600 text-white shadow-2xs'
                        : 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200'
                    }`}
                  >
                    <span>Ada Kasbon ({customers.filter(c => (c.totalDebt || 0) > 0).length})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMemberFilterCategory('DISCOUNT')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                      memberFilterCategory === 'DISCOUNT'
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
                    }`}
                  >
                    <span>Diskon Member ({customers.filter(c => (c.discountRate || 0) > 0).length})</span>
                  </button>
                </div>

                <div className="flex items-center gap-2 text-slate-500 font-medium self-end sm:self-auto">
                  <span>
                    Ditemukan <strong className="text-slate-900 font-bold">{filteredCustomers.length}</strong> dari {customers.length} member
                  </span>
                  {(customerSearch || memberFilterCategory !== 'ALL') && (
                    <button
                      type="button"
                      onClick={() => {
                        setCustomerSearch('');
                        setMemberFilterCategory('ALL');
                      }}
                      className="text-sky-600 hover:text-sky-800 font-bold underline cursor-pointer text-[11px]"
                    >
                      Reset Filter
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Daftar Tabel Pelanggan */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-black tracking-wider text-[10px]">
                    <tr>
                      <th className="py-3 px-4">Kode & Nama Member</th>
                      <th className="py-3 px-4">No. HP / WhatsApp</th>
                      <th className="py-3 px-4">Diskon Member</th>
                      <th className="py-3 px-4">Poin & Belanja</th>
                      <th className="py-3 px-4">Kasbon / Limit</th>
                      <th className="py-3 px-4">Alamat & Catatan</th>
                      <th className="py-3 px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredCustomers.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-slate-400">
                          <div className="max-w-xs mx-auto space-y-2 text-center">
                            <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                              <Search className="w-6 h-6" />
                            </div>
                            <h4 className="font-bold text-slate-700 text-sm">Member Tidak Ditemukan</h4>
                            <p className="text-xs text-slate-500">
                              Tidak ada data member yang cocok dengan kata kunci{' '}
                              <strong className="text-slate-800">"{customerSearch}"</strong>.
                            </p>
                            <button
                              type="button"
                              onClick={() => {
                                setCustomerSearch('');
                                setMemberFilterCategory('ALL');
                              }}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
                            >
                              Bersihkan Pencarian
                            </button>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      filteredCustomers.map(cust => (
                        <tr key={cust.id} className="hover:bg-slate-50/80 transition">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono font-bold text-[10px] border border-slate-200 shrink-0">
                                {cust.memberCode}
                              </span>
                              <span className="font-bold text-slate-900 text-xs">
                                {cust.name}
                              </span>
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            <div className="flex items-center gap-1.5 font-mono text-slate-700">
                              <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span>{cust.phone}</span>
                              {cust.phone && (
                                <a
                                  href={`https://wa.me/${cust.phone.replace(/[^0-9]/g, '')}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="ml-1 p-1 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition"
                                  title="Chat WhatsApp"
                                >
                                  <MessageCircle className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-black text-[11px]">
                              {cust.discountRate || 0}% Diskon
                            </span>
                          </td>

                          <td className="py-3 px-4">
                            <div className="text-slate-900 font-mono">
                              <span className="font-bold text-purple-700">{cust.points || 0} Pts</span>
                              <span className="text-[10px] text-slate-400 block">
                                Tot: {formatRupiah(cust.totalSpent || 0)}
                              </span>
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            <div>
                              <span
                                className={`font-mono font-bold text-xs ${
                                  (cust.totalDebt || 0) > 0 ? 'text-red-600' : 'text-slate-600'
                                }`}
                              >
                                {formatRupiah(cust.totalDebt || 0)}
                              </span>
                              <span className="text-[10px] text-slate-400 block font-mono">
                                Limit: {formatRupiah(cust.creditLimit || 500000)}
                              </span>
                            </div>
                          </td>

                          <td className="py-3 px-4 max-w-xs">
                            <p className="text-[11px] text-slate-700 truncate">{cust.address || '-'}</p>
                            {cust.notes && (
                              <p className="text-[10px] text-slate-400 truncate italic">
                                {cust.notes}
                              </p>
                            )}
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedCustomer(cust);
                                  alert(`Member ${cust.name} dipilih untuk kasir! Silakan buka tab Kasir.`);
                                }}
                                className="px-2 py-1 rounded bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold text-[11px] transition cursor-pointer"
                                title="Pilih Sebagai Member Belanja"
                              >
                                Kasir
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingCustomer(cust);
                                  setIsCustomerModalOpen(true);
                                }}
                                className="p-1 rounded text-slate-600 hover:bg-slate-100 transition cursor-pointer"
                                title="Edit Pelanggan"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`Hapus data pelanggan ${cust.name} (${cust.memberCode})?`)) {
                                    deleteCustomer(cust.id);
                                  }
                                }}
                                className="p-1 rounded text-red-500 hover:bg-red-50 transition cursor-pointer"
                                title="Hapus Pelanggan"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB: ATURAN POIN MEMBER (EDIT POIN, BELANJA, DAN POTONGAN PEMBAYARAN) */}
        {/* ========================================================================= */}
        {activeTab === 'POIN_MEMBER' && (
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Header Banner & Status Toggle */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-4 sm:p-5 bg-gradient-to-r from-purple-50 via-white to-pink-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                      Edit Ketentuan & Aturan Poin Member
                    </h3>
                    <p className="text-xs text-slate-500">
                      Konfigurasi ketentuan perolehan poin belanja member serta pemakaian poin untuk memotong pembayaran di kasir
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-600">Sistem Poin:</span>
                  <button
                    type="button"
                    onClick={() => setPointForm(p => ({ ...p, isEnabled: !p.isEnabled }))}
                    className={`px-3 py-1 rounded-full text-xs font-black transition cursor-pointer flex items-center gap-1.5 ${
                      pointForm.isEnabled
                        ? 'bg-purple-100 text-purple-800 border border-purple-300'
                        : 'bg-slate-200 text-slate-600 border border-slate-300'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${pointForm.isEnabled ? 'bg-purple-600' : 'bg-slate-400'}`} />
                    <span>{pointForm.isEnabled ? 'Aktif' : 'Nonaktif'}</span>
                  </button>
                </div>
              </div>

              {!pointForm.isEnabled && (
                <div className="p-4 bg-amber-50 border-b border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Program poin saat ini dinonaktifkan. Kasir tidak akan menambah poin baru atau memproses potongan poin belanja hingga fitur diaktifkan kembali.</span>
                </div>
              )}
            </div>

            {/* FORM PENGATURAN */}
            <form onSubmit={handleSavePoints} className="space-y-6">
              {/* BAGIAN 1: PEROLEHAN POIN */}
              <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Coins className="w-4 h-4 text-purple-600" />
                    <h4 className="text-xs font-black uppercase text-slate-800">
                      1. Aturan Perolehan Poin (Tiap Belanja Rp X Dapat Y Poin)
                    </h4>
                  </div>
                  <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">
                    Earning Rules
                  </span>
                </div>

                <div className="p-5 space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">
                        Tiap Belanja Kelipatan (Rp) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-slate-400 font-bold">Rp</span>
                        <input
                          type="number"
                          min="1000"
                          step="500"
                          value={pointForm.earnSpendAmount}
                          onChange={e => setPointForm(p => ({ ...p, earnSpendAmount: Math.max(1, Number(e.target.value)) }))}
                          className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:bg-white focus:border-purple-600"
                          placeholder="10000"
                          required
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1">
                        Contoh: Masukkan 10000 untuk kelipatan Rp 10.000
                      </p>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">
                        Mendapatkan Jumlah Poin <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min="1"
                          step="1"
                          value={pointForm.earnPoints}
                          onChange={e => setPointForm(p => ({ ...p, earnPoints: Math.max(1, Number(e.target.value)) }))}
                          className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-3 pr-14 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:bg-white focus:border-purple-600"
                          placeholder="1"
                          required
                        />
                        <span className="absolute right-3 top-2.5 text-slate-400 font-bold">Poin</span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1">
                        Jumlah poin yang didapatkan untuk setiap kelipatan belanja
                      </p>
                    </div>
                  </div>

                  {/* Preset Pilihan Cepat Earning */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                      Pilihan Cepat (Preset):
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { label: 'Tiap Rp 5.000 = 1 Poin', spend: 5000, pts: 1 },
                        { label: 'Tiap Rp 10.000 = 1 Poin (Rekomendasi)', spend: 10000, pts: 1 },
                        { label: 'Tiap Rp 20.000 = 1 Poin', spend: 20000, pts: 1 },
                        { label: 'Tiap Rp 50.000 = 5 Poin', spend: 50000, pts: 5 },
                        { label: 'Tiap Rp 100.000 = 10 Poin', spend: 100000, pts: 10 },
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setPointForm(p => ({ ...p, earnSpendAmount: preset.spend, earnPoints: preset.pts }))}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer border ${
                            pointForm.earnSpendAmount === preset.spend && pointForm.earnPoints === preset.pts
                              ? 'bg-purple-100 text-purple-800 border-purple-300'
                              : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-purple-50/60 p-3 rounded-xl border border-purple-100 text-slate-700 flex items-start gap-2.5 text-[11px]">
                    <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-purple-900 block">Keterangan Aturan Perolehan:</span>
                      <span>
                        Setiap kali member berbelanja kelipatan <strong className="text-purple-700">{formatRupiah(pointForm.earnSpendAmount)}</strong>, member otomatis memperoleh <strong className="text-purple-700">{pointForm.earnPoints} Poin</strong>. Jika belanja Rp 50.000 (dengan aturan Rp 10.000 = 1 Poin), member akan mendapatkan {Math.floor(50000 / pointForm.earnSpendAmount) * pointForm.earnPoints} Poin.
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* BAGIAN 2: NILAI TUKAR POIN */}
              <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    <h4 className="text-xs font-black uppercase text-slate-800">
                      2. Nilai Konversi Poin ke Rupiah (Nilai Tukar)
                    </h4>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    Redemption Value
                  </span>
                </div>

                <div className="p-5 space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">
                        Nilai 1 Poin saat Dipakai Belanja (Rp) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-slate-400 font-bold">Rp</span>
                        <input
                          type="number"
                          min="1"
                          step="10"
                          value={pointForm.pointValueInRupiah}
                          onChange={e => setPointForm(p => ({ ...p, pointValueInRupiah: Math.max(1, Number(e.target.value)) }))}
                          className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:bg-white focus:border-emerald-600"
                          placeholder="100"
                          required
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1">
                        Berapa rupiah diskon/potongan yang didapat untuk 1 poin
                      </p>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-bold mb-1.5">
                        Minimal Saldo Poin untuk Ditukarkan
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={pointForm.minPointsToRedeem}
                          onChange={e => setPointForm(p => ({ ...p, minPointsToRedeem: Math.max(0, Number(e.target.value)) }))}
                          className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-3 pr-14 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:bg-white focus:border-emerald-600"
                          placeholder="10"
                        />
                        <span className="absolute right-3 top-2.5 text-slate-400 font-bold">Poin</span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1">
                        Member harus mengumpulkan minimal sejumlah poin ini sebelum bisa dipakai di kasir
                      </p>
                    </div>
                  </div>

                  {/* Preset Nilai Tukar */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                      Pilihan Cepat Nilai 1 Poin:
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { label: '1 Poin = Rp 50', val: 50 },
                        { label: '1 Poin = Rp 100 (Standar)', val: 100 },
                        { label: '1 Poin = Rp 200', val: 200 },
                        { label: '1 Poin = Rp 500', val: 500 },
                        { label: '1 Poin = Rp 1.000', val: 1000 },
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setPointForm(p => ({ ...p, pointValueInRupiah: preset.val }))}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer border ${
                            pointForm.pointValueInRupiah === preset.val
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-100 text-slate-700 flex items-start gap-2.5 text-[11px]">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-emerald-900 block">Keterangan Nilai Tukar:</span>
                      <span>
                        100 Poin member setara dengan potongan belanja tunai <strong className="text-emerald-700">{formatRupiah(100 * pointForm.pointValueInRupiah)}</strong>. Penukaran baru dapat dilakukan jika saldo member minimal <strong className="text-emerald-700">{pointForm.minPointsToRedeem} Poin</strong>.
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* BAGIAN 3: KETENTUAN PEMAKAIAN POIN (SEPENUHNYA VS PERSENTASE) */}
              <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Percent className="w-4 h-4 text-sky-600" />
                    <h4 className="text-xs font-black uppercase text-slate-800">
                      3. Ketentuan Pemakaian Poin untuk Membayar / Potongan Belanja
                    </h4>
                  </div>
                  <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-200">
                    Redemption Policy
                  </span>
                </div>

                <div className="p-5 space-y-4 text-xs">
                  <label className="block text-slate-700 font-bold mb-1">
                    Batas Maksimal Penggunaan Poin dalam Transaksi:
                  </label>

                  {/* Dua Pilihan Radio Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Opsi 1: Penuh 100% */}
                    <div
                      onClick={() => setPointForm(p => ({ ...p, redeemMode: 'FULL' }))}
                      className={`p-4 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between ${
                        pointForm.redeemMode === 'FULL'
                          ? 'border-sky-600 bg-sky-50/50 shadow-xs'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-black text-slate-900 flex items-center gap-1.5">
                            <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                              pointForm.redeemMode === 'FULL' ? 'border-sky-600 bg-sky-600' : 'border-slate-400'
                            }`}>
                              {pointForm.redeemMode === 'FULL' && <Check className="w-2.5 h-2.5 text-white" />}
                            </span>
                            Bisa Digunakan Sepenuhnya (100%)
                          </span>
                          <span className="text-[10px] font-black bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full">
                            Full 100%
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-relaxed">
                          Poin dapat memotong total tagihan belanja <strong>hingga 100%</strong> (gratis atau bayar Rp 0 jika poin member mencukupi).
                        </p>
                      </div>
                    </div>

                    {/* Opsi 2: Dibatasi Persentase */}
                    <div
                      onClick={() => setPointForm(p => ({ ...p, redeemMode: 'PERCENT_LIMIT' }))}
                      className={`p-4 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between ${
                        pointForm.redeemMode === 'PERCENT_LIMIT'
                          ? 'border-sky-600 bg-sky-50/50 shadow-xs'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-black text-slate-900 flex items-center gap-1.5">
                            <span className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                              pointForm.redeemMode === 'PERCENT_LIMIT' ? 'border-sky-600 bg-sky-600' : 'border-slate-400'
                            }`}>
                              {pointForm.redeemMode === 'PERCENT_LIMIT' && <Check className="w-2.5 h-2.5 text-white" />}
                            </span>
                            Dibatasi Persentase Belanja (%)
                          </span>
                          <span className="text-[10px] font-black bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full">
                            Custom %
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-relaxed">
                          Poin <strong>hanya bisa memotong maksimal sekian persen (%)</strong> dari total belanja. Sisanya wajib dibayar dengan uang tunai / transfer / QRIS.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Input Persentase jika mode PERCENT_LIMIT */}
                  {pointForm.redeemMode === 'PERCENT_LIMIT' && (
                    <div className="p-4 bg-sky-50/60 rounded-xl border border-sky-200 space-y-3 animate-in fade-in">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <label className="block text-slate-800 font-black">
                            Batas Maksimal Potongan Poin dari Total Belanja:
                          </label>
                          <p className="text-[11px] text-slate-600">
                            Contoh: Jika diset 50% dan total belanja Rp 100.000, maksimal potongan poin adalah Rp 50.000.
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="5"
                            max="99"
                            step="5"
                            value={pointForm.maxRedeemPercentage}
                            onChange={e => setPointForm(p => ({ ...p, maxRedeemPercentage: Math.min(99, Math.max(1, Number(e.target.value))) }))}
                            className="w-20 bg-white border border-sky-300 rounded-xl px-3 py-1.5 text-center text-sm font-black text-slate-900 focus:outline-none focus:border-sky-600"
                          />
                          <span className="font-black text-sky-800 text-sm">%</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 pt-1 border-t border-sky-200/60">
                        {[
                          { label: '20% Belanja', val: 20 },
                          { label: '30% Belanja', val: 30 },
                          { label: '50% Belanja (Rekomendasi)', val: 50 },
                          { label: '70% Belanja', val: 70 },
                          { label: '80% Belanja', val: 80 },
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setPointForm(p => ({ ...p, maxRedeemPercentage: preset.val }))}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer border ${
                              pointForm.maxRedeemPercentage === preset.val
                                ? 'bg-sky-600 text-white border-sky-600'
                                : 'bg-white text-sky-800 border-sky-200 hover:bg-sky-100'
                            }`}
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* BAGIAN 4: SIMULATOR & PREVIEW REAL-TIME */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl shadow-md border border-slate-800 overflow-hidden">
                <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <h4 className="text-xs font-black uppercase tracking-wide text-white">
                      Simulator & Kalkulator Simulasi Transaksi (Live Preview)
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    Uji coba aturan langsung
                  </span>
                </div>

                <div className="p-5 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-slate-300 text-[11px] font-bold mb-1">
                        Simulasi Nilai Belanja:
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-slate-400 font-bold text-xs">Rp</span>
                        <input
                          type="number"
                          step="10000"
                          value={simSpendAmount}
                          onChange={e => setSimSpendAmount(Math.max(0, Number(e.target.value)))}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-300 text-[11px] font-bold mb-1">
                        Simulasi Saldo Poin Member:
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          step="10"
                          value={simCustomerPoints}
                          onChange={e => setSimCustomerPoints(Math.max(0, Number(e.target.value)))}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-3 pr-14 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                        />
                        <span className="absolute right-3 top-2 text-slate-400 font-bold text-xs">Poin</span>
                      </div>
                    </div>
                  </div>

                  {/* Hasil Simulasi Breakdown */}
                  {(() => {
                    const pointValue = pointForm.pointValueInRupiah;
                    const totalPointRupiahValue = simCustomerPoints * pointValue;
                    
                    // Hitung batas maksimal diskon rupiah
                    let maxAllowedDiscount = simSpendAmount;
                    if (pointForm.redeemMode === 'PERCENT_LIMIT') {
                      maxAllowedDiscount = Math.floor((simSpendAmount * (pointForm.maxRedeemPercentage || 50)) / 100);
                    }

                    // Poin yang dapat dipakai
                    const actualDiscountRupiah = Math.min(totalPointRupiahValue, maxAllowedDiscount);
                    const pointsActuallyUsed = Math.floor(actualDiscountRupiah / pointValue);
                    const sisaBelanjaWajibBayar = Math.max(0, simSpendAmount - (pointsActuallyUsed * pointValue));

                    // Poin baru yang didapatkan
                    let earnedNew = 0;
                    if (pointForm.isEnabled && pointForm.earnSpendAmount > 0) {
                      earnedNew = Math.floor(sisaBelanjaWajibBayar / pointForm.earnSpendAmount) * (pointForm.earnPoints || 1);
                    }

                    const canRedeem = simCustomerPoints >= (pointForm.minPointsToRedeem || 0);

                    return (
                      <div className="bg-slate-800/70 p-4 rounded-xl border border-slate-750 space-y-3">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                          <span className="text-xs text-slate-400">Total Nilai Saldo Poin:</span>
                          <span className="text-xs font-mono font-bold text-emerald-400">
                            {simCustomerPoints} Poin = {formatRupiah(totalPointRupiahValue)}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                          <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                            <span className="text-[10px] text-slate-400 block uppercase font-bold">
                              Maksimal Potongan
                            </span>
                            <span className="text-sm font-black font-mono text-purple-400">
                              {formatRupiah(maxAllowedDiscount)}
                            </span>
                            <span className="text-[10px] text-slate-500 block mt-0.5">
                              {pointForm.redeemMode === 'FULL' ? 'Bebas 100% belanja' : `Maksimal ${pointForm.maxRedeemPercentage}% belanja`}
                            </span>
                          </div>

                          <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                            <span className="text-[10px] text-slate-400 block uppercase font-bold">
                              Poin yang Terpakai
                            </span>
                            <span className="text-sm font-black font-mono text-amber-400">
                              {canRedeem ? `${pointsActuallyUsed} Poin` : '0 Poin (Kurang)'}
                            </span>
                            <span className="text-[10px] text-slate-500 block mt-0.5">
                              {canRedeem ? `- ${formatRupiah(pointsActuallyUsed * pointValue)}` : `Min ${pointForm.minPointsToRedeem} Poin`}
                            </span>
                          </div>

                          <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                            <span className="text-[10px] text-slate-400 block uppercase font-bold">
                              Sisa Bayar Tunai / Transfer
                            </span>
                            <span className="text-sm font-black font-mono text-emerald-400">
                              {formatRupiah(canRedeem ? sisaBelanjaWajibBayar : simSpendAmount)}
                            </span>
                            <span className="text-[10px] text-slate-500 block mt-0.5">
                              Dapat +{earnedNew} Poin baru
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* ACTION BUTTONS */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleResetPoints}
                  className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer w-full sm:w-auto justify-center"
                >
                  <RefreshCw className="w-4 h-4 text-slate-500" />
                  <span>Kembalikan ke Default</span>
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-xs shadow-md flex items-center gap-2 transition cursor-pointer w-full sm:w-auto justify-center"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Aturan Poin Member</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: PROFIL TOKO & STRUK */}
        {/* ========================================================================= */}
        {activeTab === 'PROFIL_TOKO' && (
          <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-50 via-white to-red-50 border-b border-slate-200 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-xs">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                  Profil Minimarket & Header / Footer Struk
                </h3>
                <p className="text-xs text-slate-500">
                  Data ini akan tercetak otomatis pada struk belanja kasir dan laporan transaksi
                </p>
              </div>
            </div>

            <form onSubmit={handleSaveStoreProfile} className="p-4 sm:p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    Nama Minimarket / Toko <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={storeForm.name}
                    onChange={e => setStoreForm({ ...storeForm, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-amber-600 uppercase"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    No. Telepon / WhatsApp Toko
                  </label>
                  <input
                    type="text"
                    value={storeForm.phone}
                    onChange={e => setStoreForm({ ...storeForm, phone: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-amber-600"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Alamat Lengkap Toko
                </label>
                <input
                  type="text"
                  value={storeForm.address}
                  onChange={e => setStoreForm({ ...storeForm, address: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-amber-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    Header Pesan Struk (Atas)
                  </label>
                  <textarea
                    rows={2}
                    value={storeForm.receiptHeader}
                    onChange={e => setStoreForm({ ...storeForm, receiptHeader: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-amber-600"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    Footer Pesan Struk (Bawah)
                  </label>
                  <textarea
                    rows={2}
                    value={storeForm.receiptFooter}
                    onChange={e => setStoreForm({ ...storeForm, receiptFooter: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-amber-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-black shadow-md flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Perubahan Profil Toko</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL: TAMBAH / EDIT REKENING BANK */}
      {/* ========================================================================= */}
      {isBankModalOpen && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 animate-in fade-in">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
            <div className="p-4 bg-gradient-to-r from-blue-700 to-indigo-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-yellow-300" />
                <h3 className="font-black text-sm">
                  {editingBank ? 'Edit Rekening Bank' : 'Tambah Rekening Bank Toko'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsBankModalOpen(false)}
                className="text-white hover:text-slate-200 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveBank} className="p-4 sm:p-5 space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Pilih / Ketik Nama Bank <span className="text-red-500">*</span>
                </label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {bankPresets.map(preset => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() =>
                        setBankForm({
                          ...bankForm,
                          bankName: preset.name,
                          color: preset.color,
                        })
                      }
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition cursor-pointer ${
                        bankForm.bankName === preset.name
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  required
                  value={bankForm.bankName}
                  onChange={e => setBankForm({ ...bankForm, bankName: e.target.value.toUpperCase() })}
                  placeholder="Nama Bank (misal: BCA, BRI, BSI)"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-blue-600 uppercase"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Nomor Rekening Bank <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={bankForm.accountNumber}
                  onChange={e => setBankForm({ ...bankForm, accountNumber: e.target.value })}
                  placeholder="Contoh: 8820-1928-331"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-blue-600 tracking-wider"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Nama Pemilik Rekening (Atas Nama / a.n.) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={bankForm.accountHolder}
                  onChange={e => setBankForm({ ...bankForm, accountHolder: e.target.value })}
                  placeholder="Contoh: Minimarket Berkah Jaya"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:bg-white focus:border-blue-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Keterangan / Cabang (Opsional)
                </label>
                <input
                  type="text"
                  value={bankForm.notes}
                  onChange={e => setBankForm({ ...bankForm, notes: e.target.value })}
                  placeholder="Contoh: KCP Sudirman / Rekening Operasional Kasir"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-blue-600"
                />
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBankModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 font-bold hover:bg-slate-100 transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-black shadow-md flex items-center gap-1.5 transition cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingBank ? 'Simpan Perubahan' : 'Tambahkan Rekening'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: TAMBAH / EDIT DATA PELANGGAN */}
      {/* ========================================================================= */}
      <PelangganModal
        isOpen={isCustomerModalOpen}
        onClose={() => setIsCustomerModalOpen(false)}
        editCustomer={editingCustomer}
      />

      {/* ========================================================================= */}
      {/* MODAL ZOOM PREVIEW QRIS */}
      {/* ========================================================================= */}
      {previewZoom && qrisForm.imageUrl && (
        <div
          onClick={() => setPreviewZoom(false)}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 cursor-pointer animate-in fade-in"
        >
          <div
            onClick={e => e.stopPropagation()}
            className="bg-white p-6 rounded-3xl shadow-2xl max-w-sm w-full flex flex-col items-center text-center space-y-4 border-4 border-yellow-400"
          >
            <div className="flex items-center justify-between w-full border-b pb-2">
              <span className="font-black text-red-600 text-lg">QRIS RESMI</span>
              <button
                type="button"
                onClick={() => setPreviewZoom(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 font-black hover:bg-slate-200"
              >
                ✕
              </button>
            </div>
            <h4 className="font-black text-sm uppercase text-slate-900">
              {qrisForm.merchantName || storeProfile.name}
            </h4>
            <div className="w-64 h-64 border-2 border-slate-200 rounded-2xl p-2 bg-white flex items-center justify-center shadow-inner">
              <img
                src={qrisForm.imageUrl}
                alt="QRIS Zoom"
                className="w-full h-full object-contain"
              />
            </div>
            <p className="text-xs text-slate-500 font-mono">
              NMID: {qrisForm.nmid || 'ID10202488910'}
            </p>
            <p className="text-[11px] text-slate-600 font-bold">
              {qrisForm.notes}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
