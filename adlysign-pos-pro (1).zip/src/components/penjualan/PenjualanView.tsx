import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Printer,
  RotateCcw,
  Eye,
  X,
  FileSpreadsheet,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { SaleTransaction } from '../../types/pos';
import { formatDateTime, formatRupiah, exportToCSV } from '../../utils/formatters';
import { ReceiptModal } from '../kasir/ReceiptModal';

export const PenjualanView: React.FC = () => {
  const { sales, processSalesReturn } = usePOS();

  const [search, setSearch] = useState('');
  const [selectedSale, setSelectedSale] = useState<SaleTransaction | null>(null);
  const [reprintSale, setReprintSale] = useState<SaleTransaction | null>(null);

  // Return / Refund Modal State
  const [returnModalSale, setReturnModalSale] = useState<SaleTransaction | null>(null);
  const [returnItemId, setReturnItemId] = useState<string>('');
  const [returnQty, setReturnQty] = useState<number>(1);
  const [returnReason, setReturnReason] = useState<string>('Kemasan rusak / kadaluwarsa');
  const [returnRefundAmount, setReturnRefundAmount] = useState<number>(0);
  const [returnSupervisorPin, setReturnSupervisorPin] = useState<string>('');
  const [returnPinError, setReturnPinError] = useState<string>('');

  const openReturnModal = (sale: SaleTransaction) => {
    setReturnModalSale(sale);
    setReturnSupervisorPin('');
    setReturnPinError('');
    if (sale.items[0]) {
      setReturnItemId(sale.items[0].productId);
      setReturnQty(1);
      setReturnRefundAmount(sale.items[0].sellingPrice);
    }
  };

  const handleReturnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnModalSale || !returnItemId) return;

    const item = returnModalSale.items.find(i => i.productId === returnItemId);
    if (!item) return;

    if (returnQty > item.quantity) {
      alert(`Kuantitas retur (${returnQty}) tidak boleh melebihi pembelian di struk (${item.quantity})!`);
      return;
    }

    const cleanSupervisorPin = (returnSupervisorPin || '').trim();
    if (!cleanSupervisorPin) {
      setReturnPinError('Masukkan PIN Supervisor / Owner untuk otorisasi pengembalian barang & refund');
      return;
    }

    const res = processSalesReturn(
      returnModalSale.invoiceNumber,
      [
        {
          productId: returnItemId,
          quantity: returnQty,
          refundPrice: returnRefundAmount,
        },
      ],
      returnReason,
      cleanSupervisorPin
    );

    if (res.success) {
      alert(`Retur transaksi ${returnModalSale.invoiceNumber} berhasil diproses. Stok barang ${item.name} dikembalikan ke sistem.`);
      setReturnModalSale(null);
    } else {
      setReturnPinError(res.message);
    }
  };

  const handleExportSales = () => {
    const rows = sales.map(s => ({
      NoStruk: s.invoiceNumber,
      Waktu: s.createdAt,
      Kasir: s.cashierName,
      Pelanggan: s.customerName || 'Umum',
      Metode: s.paymentMethod,
      Subtotal: s.subtotal,
      Diskon: s.transactionDiscount,
      Total: s.totalAmount,
      Status: s.status,
    }));
    exportToCSV(`laporan_penjualan_${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  const filteredSales = sales.filter(s => {
    const q = search.toLowerCase();
    return (
      s.invoiceNumber.toLowerCase().includes(q) ||
      s.cashierName.toLowerCase().includes(q) ||
      (s.customerName && s.customerName.toLowerCase().includes(q)) ||
      s.paymentMethod.toLowerCase().includes(q)
    );
  });

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <ShoppingBag className="w-6 h-6 text-red-600" />
              <span>Riwayat Transaksi Penjualan & Struk Kasir</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Daftar seluruh struk transaksi kasir, cetak ulang struk [F3], dan proses retur / refund uang barang.
            </p>
          </div>

          <button
            onClick={handleExportSales}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Filter search */}
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari berdasarkan no struk, nama kasir, nama pelanggan, atau metode pembayaran..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
        </div>

        {/* Sales Table */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto max-h-[550px]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 z-10 pos-table-header">
                <tr>
                  <th className="py-3 px-4">No. Struk</th>
                  <th className="py-3 px-4">Waktu Transaksi</th>
                  <th className="py-3 px-4">Kasir</th>
                  <th className="py-3 px-4">Pelanggan</th>
                  <th className="py-3 px-4">Metode</th>
                  <th className="py-3 px-4 text-right">Total Belanja</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {filteredSales.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400 font-sans">
                      Belum ada transaksi penjualan kasir.
                    </td>
                  </tr>
                ) : (
                  filteredSales.map(sale => (
                    <tr key={sale.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-4 font-bold text-blue-700">{sale.invoiceNumber}</td>
                      <td className="py-3 px-4 text-slate-500 text-[11px] font-sans">
                        {formatDateTime(sale.createdAt)}
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-sans font-medium">{sale.cashierName}</td>
                      <td className="py-3 px-4 text-slate-700 font-sans">{sale.customerName || 'Umum'}</td>
                      <td className="py-3 px-4 font-sans">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-800 border border-slate-300 uppercase">
                          {sale.paymentMethod}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-black text-red-600">
                        {formatRupiah(sale.totalAmount)}
                      </td>
                      <td className="py-3 px-4 text-center font-sans">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            sale.status === 'COMPLETED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : sale.status === 'VOID'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {sale.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setSelectedSale(sale)}
                            className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-blue-700 rounded-lg transition cursor-pointer"
                            title="Lihat Detail Struk"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setReprintSale(sale)}
                            className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-red-600 rounded-lg transition cursor-pointer"
                            title="Cetak Ulang Struk"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          {sale.status === 'COMPLETED' && (
                            <button
                              onClick={() => openReturnModal(sale)}
                              className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-amber-600 rounded-lg transition cursor-pointer"
                              title="Retur / Refund Barang"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* DETAIL MODAL */}
      {selectedSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto no-print">
          <div className="bg-white border border-slate-300 rounded-3xl w-full max-w-lg shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3">
              <div>
                <h3 className="font-black text-slate-900 text-base">Detail Transaksi Struk</h3>
                <p className="text-xs text-blue-700 font-mono font-bold">{selectedSale.invoiceNumber}</p>
              </div>
              <button onClick={() => setSelectedSale(null)} className="text-slate-400 hover:text-slate-700 font-bold">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Waktu Transaksi:</span>
                <span className="text-slate-900 font-bold">{formatDateTime(selectedSale.createdAt)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Kasir Petugas:</span>
                <span className="text-slate-900 font-bold">{selectedSale.cashierName}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pelanggan:</span>
                <span className="text-slate-900 font-bold">{selectedSale.customerName || 'Pelanggan Umum'}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Metode Pembayaran:</span>
                <span className="text-blue-700 font-black uppercase">{selectedSale.paymentMethod}</span>
              </div>
            </div>

            {/* Items list */}
            <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200 space-y-2 max-h-56 overflow-y-auto">
              <span className="text-[11px] font-bold text-slate-500 uppercase block">Rincian Barang</span>
              {selectedSale.items.map((it, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs py-1 border-b border-slate-200/60">
                  <div>
                    <span className="font-bold text-slate-900 block">{it.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {it.quantity} {it.unit} x {formatRupiah(it.sellingPrice)}
                    </span>
                  </div>
                  <span className="font-mono font-bold text-slate-900">{formatRupiah(it.subtotal)}</span>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="space-y-1 text-xs border-t border-slate-200 pt-3">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-mono font-bold">{formatRupiah(selectedSale.subtotal)}</span>
              </div>
              {selectedSale.transactionDiscount > 0 && (
                <div className="flex justify-between text-red-600 font-bold">
                  <span>Diskon:</span>
                  <span className="font-mono">- {formatRupiah(selectedSale.transactionDiscount)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-black text-red-600 pt-1 border-t border-slate-200">
                <span>TOTAL:</span>
                <span className="font-mono">{formatRupiah(selectedSale.totalAmount)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Uang Diterima:</span>
                <span className="font-mono font-bold">{formatRupiah(selectedSale.cashReceived)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Kembalian:</span>
                <span className="font-mono font-bold">{formatRupiah(selectedSale.changeDue)}</span>
              </div>
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => {
                  setReprintSale(selectedSale);
                  setSelectedSale(null);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-red-600" />
                <span>Cetak Struk Ini</span>
              </button>
              <button
                onClick={() => setSelectedSale(null)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RETURN / REFUND MODAL */}
      {returnModalSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto no-print">
          <div className="bg-white border border-slate-300 rounded-3xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3">
              <h3 className="font-black text-slate-900 text-base">Proses Retur & Refund Barang Kasir</h3>
              <button onClick={() => setReturnModalSale(null)} className="text-slate-400 hover:text-slate-700 font-bold">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReturnSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-700 font-bold mb-1 block">Pilih Barang yang Dikembalikan:</label>
                <select
                  value={returnItemId}
                  onChange={e => {
                    setReturnItemId(e.target.value);
                    const it = returnModalSale.items.find(i => i.productId === e.target.value);
                    if (it) {
                      setReturnRefundAmount(it.sellingPrice * returnQty);
                    }
                  }}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold"
                >
                  {returnModalSale.items.map(it => (
                    <option key={it.productId} value={it.productId}>
                      {it.name} (Beli: {it.quantity} {it.unit} @ {formatRupiah(it.sellingPrice)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold mb-1 block">Jumlah Retur (Qty)</label>
                  <input
                    type="number"
                    min={1}
                    value={returnQty}
                    onChange={e => {
                      const q = parseInt(e.target.value) || 1;
                      setReturnQty(q);
                      const it = returnModalSale.items.find(i => i.productId === returnItemId);
                      if (it) setReturnRefundAmount(it.sellingPrice * q);
                    }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-slate-900 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-700 font-bold mb-1 block">Nominal Refund (Rp)</label>
                  <input
                    type="number"
                    value={returnRefundAmount}
                    onChange={e => setReturnRefundAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-yellow-50 border-2 border-yellow-400 rounded-xl p-2 text-red-600 font-black font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold mb-1 block">Alasan Pengembalian / Retur</label>
                <textarea
                  value={returnReason}
                  onChange={e => setReturnReason(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2 text-slate-900"
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold mb-1 block text-xs">
                  PIN Otorisasi Supervisor / Owner <span className="text-red-600">*</span>
                </label>
                <input
                  type="password"
                  maxLength={6}
                  required
                  placeholder="Masukkan PIN otorisasi"
                  value={returnSupervisorPin}
                  onChange={e => {
                    setReturnSupervisorPin(e.target.value);
                    setReturnPinError('');
                  }}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-mono text-center tracking-widest text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                />
                {returnPinError && (
                  <p className="text-xs text-red-600 font-bold mt-1">{returnPinError}</p>
                )}
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-800 font-medium">
                Stok barang akan otomatis ditambahkan kembali ke inventaris minimarket setelah retur dikonfirmasi.
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setReturnModalSale(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold border border-slate-300 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl shadow-xs cursor-pointer"
                >
                  Konfirmasi Retur & Refund
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REPRINT MODAL */}
      {reprintSale && (
        <ReceiptModal
          sale={reprintSale}
          onClose={() => setReprintSale(null)}
        />
      )}
    </div>
  );
};
