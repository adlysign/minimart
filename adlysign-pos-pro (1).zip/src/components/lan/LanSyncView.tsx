import React, { useState } from 'react';
import {
  Wifi,
  WifiOff,
  Server,
  Monitor,
  RefreshCw,
  Send,
  Download,
  Upload,
  CheckCircle2,
  AlertCircle,
  Copy,
  Radio,
  Clock,
  HardDrive,
  Users,
  Settings2,
  Trash2,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { LanDeviceRole } from '../../types/pos';

export const LanSyncView: React.FC = () => {
  const {
    lanSyncStatus,
    updateLanSettings,
    triggerLanSyncNow,
    broadcastLanTestSignal,
    pushFullDbToLan,
    pullFullDbFromLan,
    clearLanLogs,
    products,
    sales,
    currentUser,
  } = usePOS();

  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'TERMINALS' | 'DATABASE' | 'LOGS'>('OVERVIEW');
  const [copiedIp, setCopiedIp] = useState<string | null>(null);
  const [testSignalMsg, setTestSignalMsg] = useState('Uji Sinyal Kasir Toko OK');
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [terminalNameInput, setTerminalNameInput] = useState(lanSyncStatus.terminalName || 'Kasir 01');
  const [serverUrlInput, setServerUrlInput] = useState(lanSyncStatus.serverUrl || '');
  const [roleInput, setRoleInput] = useState<LanDeviceRole>(lanSyncStatus.role || 'SERVER_MASTER');
  const [autoSyncInput, setAutoSyncInput] = useState(lanSyncStatus.autoSync);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [logFilter, setLogFilter] = useState<'ALL' | 'TRANSACTION' | 'PRODUCT' | 'SYSTEM'>('ALL');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIp(text);
    setTimeout(() => setCopiedIp(null), 2000);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateLanSettings({
      terminalName: terminalNameInput,
      serverUrl: serverUrlInput,
      role: roleInput,
      autoSync: autoSyncInput,
    });
    setSaveSuccessMsg('Pengaturan Jaringan LAN berhasil disimpan!');
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  const handleSendTestSignal = async () => {
    if (!testSignalMsg.trim()) return;
    setIsBroadcasting(true);
    try {
      broadcastLanTestSignal(testSignalMsg.trim());
    } finally {
      setTimeout(() => setIsBroadcasting(false), 600);
    }
  };

  const filteredLogs = (lanSyncStatus.activityLogs || []).filter(log => {
    if (logFilter === 'ALL') return true;
    if (logFilter === 'TRANSACTION') return log.eventTitle.toLowerCase().includes('penjualan') || log.eventTitle.toLowerCase().includes('transaksi');
    if (logFilter === 'PRODUCT') return log.eventTitle.toLowerCase().includes('produk') || log.eventTitle.toLowerCase().includes('stok');
    if (logFilter === 'SYSTEM') return log.type === 'CONNECT' || log.type === 'DISCONNECT' || log.eventTitle.toLowerCase().includes('sinyal');
    return true;
  });

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header Banner */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className={`p-3 rounded-2xl ${lanSyncStatus.isConnected ? 'bg-sky-50 text-sky-700 border border-sky-200' : 'bg-rose-50 text-rose-700 border border-rose-200'}`}>
              {lanSyncStatus.isConnected ? (
                <Wifi className="w-7 h-7 animate-pulse" />
              ) : (
                <WifiOff className="w-7 h-7" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-slate-900">
                  Sinkronisasi Jaringan Lokal (LAN) Realtime
                </h2>
                <span
                  className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wide ${
                    lanSyncStatus.isConnected
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-rose-100 text-rose-800 border border-rose-300'
                  }`}
                >
                  {lanSyncStatus.isConnected ? '● ONLINE (Terhubung)' : '○ OFFLINE (Terputus)'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Auto-sinkronisasi instan antar komputer kasir, tablet pramuniaga, dan server toko dalam 1 jaringan Wi-Fi/LAN lokal tanpa internet.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => triggerLanSyncNow()}
              disabled={lanSyncStatus.isSyncing}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-black text-xs rounded-xl shadow-xs transition active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${lanSyncStatus.isSyncing ? 'animate-spin' : ''}`} />
              <span>{lanSyncStatus.isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 border-b border-slate-200 pb-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'OVERVIEW'
                ? 'bg-sky-700 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Overview & Jaringan</span>
          </button>

          <button
            onClick={() => setActiveTab('TERMINALS')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'TERMINALS'
                ? 'bg-sky-700 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Terminal Terhubung</span>
            <span className="px-1.5 py-0.2 rounded-full bg-sky-100 text-sky-800 text-[10px]">
              {(lanSyncStatus.connectedClients || []).length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('DATABASE')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'DATABASE'
                ? 'bg-sky-700 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>Replikasi Database</span>
          </button>

          <button
            onClick={() => setActiveTab('LOGS')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'LOGS'
                ? 'bg-sky-700 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Log Aktivitas Realtime</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-800 text-[10px]">
              {(lanSyncStatus.activityLogs || []).length}
            </span>
          </button>
        </div>

        {/* 4 Status Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Card 1: Status Koneksi */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Status LAN</span>
              <div className={`w-2.5 h-2.5 rounded-full ${lanSyncStatus.isConnected ? 'bg-emerald-500 animate-ping' : 'bg-rose-500'}`} />
            </div>
            <p className={`text-base font-black mt-1 ${lanSyncStatus.isConnected ? 'text-emerald-700' : 'text-rose-700'}`}>
              {lanSyncStatus.isConnected ? 'Terhubung (Online)' : 'Terputus (Offline)'}
            </p>
            <p className="text-[10px] text-slate-400 font-mono mt-1 truncate">
              WS: {lanSyncStatus.serverUrl.replace(/^wss?:\/\//, '')}
            </p>
          </div>

          {/* Card 2: Peran Perangkat */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Peran Komputer</span>
              {lanSyncStatus.role === 'SERVER_MASTER' ? (
                <Server className="w-4 h-4 text-sky-700" />
              ) : (
                <Monitor className="w-4 h-4 text-blue-700" />
              )}
            </div>
            <p className="text-base font-black text-slate-900 mt-1">
              {lanSyncStatus.role === 'SERVER_MASTER'
                ? 'Server Master Toko'
                : lanSyncStatus.role === 'CLIENT'
                ? 'Client Kasir / Terminal'
                : 'Standalone (Mandiri)'}
            </p>
            <p className="text-[10px] text-slate-500 mt-1 truncate">
              Nama: <span className="font-bold text-slate-800">{lanSyncStatus.terminalName}</span>
            </p>
          </div>

          {/* Card 3: Terminal Aktif */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Terminal Aktif</span>
              <Users className="w-4 h-4 text-purple-700" />
            </div>
            <p className="text-base font-black text-slate-900 mt-1">
              {(lanSyncStatus.connectedClients || []).length} Perangkat Kasir
            </p>
            <p className="text-[10px] text-slate-500 mt-1">
              Replikasi realtime 2 arah
            </p>
          </div>

          {/* Card 4: Versi & Waktu */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Database Versi</span>
              <Zap className="w-4 h-4 text-amber-600" />
            </div>
            <p className="text-base font-black text-slate-900 mt-1">
              v{lanSyncStatus.localVersion}
            </p>
            <p className="text-[10px] text-slate-500 mt-1 truncate">
              {lanSyncStatus.lastSyncTime
                ? new Date(lanSyncStatus.lastSyncTime).toLocaleTimeString('id-ID')
                : 'Belum pernah'}
            </p>
          </div>
        </div>

        {/* ===================== TAB 1: OVERVIEW & JARINGAN ===================== */}
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-4">
            {/* IP SERVER LAN DISCOVERY CARD */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Server className="w-5 h-5 text-sky-700" />
                  <h3 className="text-sm font-black text-slate-900">
                    Alamat IP Server Jaringan Lokal Toko
                  </h3>
                </div>
                <span className="text-[11px] bg-sky-50 text-sky-800 font-bold px-3 py-1 rounded-full border border-sky-200">
                  Port: {lanSyncStatus.serverPort || 3000}
                </span>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                Untuk menghubungkan komputer kasir lain, laptop admin, atau tablet barcode scanner di toko Anda, buka browser di perangkat tersebut dan ketik alamat IP di bawah ini (pastikan semua perangkat terhubung ke Wi-Fi / Router toko yang sama):
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {(lanSyncStatus.detectedIps && lanSyncStatus.detectedIps.length > 0 ? lanSyncStatus.detectedIps : ['127.0.0.1']).map((ip, idx) => {
                  const fullUrl = `http://${ip}:${lanSyncStatus.serverPort || 3000}`;
                  const isCopied = copiedIp === fullUrl;
                  return (
                    <div
                      key={idx}
                      className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between hover:bg-sky-50/50 hover:border-sky-300 transition"
                    >
                      <div>
                        <span className="text-[10px] font-black text-slate-400 block uppercase">
                          Alamat Akses Kasir {idx === 0 ? '(IP Rekomendasi)' : `(IP Alternatif ${idx})`}
                        </span>
                        <span className="text-sm font-black font-mono text-sky-900">
                          {fullUrl}
                        </span>
                      </div>
                      <button
                        onClick={() => copyToClipboard(fullUrl)}
                        className={`px-3 py-1.5 text-xs font-black rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                          isCopied
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {isCopied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{isCopied ? 'Tersalin!' : 'Salin URL'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="bg-sky-50/80 border border-sky-200 rounded-xl p-3 text-xs text-sky-900 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block">Tips Integrasi Multi-Kasir Toko:</span>
                  <span>
                    1 Komputer kasir diatur sebagai <b>Server Master Toko</b>, sedangkan komputer kasir 2, 3, dan tablet pramuniaga diatur sebagai <b>Client Kasir</b>. Setiap kali kasir 2 melakukan transaksi penjualan atau kasir 1 mengubah harga barang, data akan tersinkronisasi secara otomatis dalam hitungan milidetik.
                  </span>
                </div>
              </div>
            </div>

            {/* FORM PENGATURAN TERMINAL & LAN */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Settings2 className="w-5 h-5 text-slate-700" />
                  <h3 className="text-sm font-black text-slate-900">
                    Konfigurasi Perangkat Ini di Jaringan
                  </h3>
                </div>
                {saveSuccessMsg && (
                  <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 animate-in fade-in">
                    {saveSuccessMsg}
                  </span>
                )}
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Nama Terminal Kasir
                    </label>
                    <input
                      type="text"
                      value={terminalNameInput}
                      onChange={e => setTerminalNameInput(e.target.value)}
                      placeholder="Contoh: Kasir 01 (Utama), Kasir 02 (Belakang)"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-sky-500 focus:bg-white transition"
                      required
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Nama identitas yang akan muncul di monitor kasir lain.
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Peran Komputer Ini
                    </label>
                    <select
                      value={roleInput}
                      onChange={e => setRoleInput(e.target.value as LanDeviceRole)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-sky-500 focus:bg-white transition cursor-pointer"
                    >
                      <option value="SERVER_MASTER">Server Master Toko (Pusat Data LAN)</option>
                      <option value="CLIENT">Client Kasir / Terminal Cabang LAN</option>
                      <option value="STANDALONE">Standalone (Mandiri - Tanpa Sinkron)</option>
                    </select>
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Pilih Master jika komputer ini menyimpan database utama toko.
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Alamat WebSocket Server LAN
                    </label>
                    <input
                      type="text"
                      value={serverUrlInput}
                      onChange={e => setServerUrlInput(e.target.value)}
                      placeholder="ws://192.168.1.100:3000/api/ws/lan-sync"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold focus:ring-2 focus:ring-sky-500 focus:bg-white transition"
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Biarkan default jika berjalan di komputer ini, atau masukkan IP Master untuk terminal client.
                    </span>
                  </div>

                  <div className="flex flex-col justify-center">
                    <label className="text-xs font-bold text-slate-700 block mb-2">
                      Auto-Sinkronisasi Realtime
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={autoSyncInput}
                        onChange={e => setAutoSyncInput(e.target.checked)}
                        className="w-5 h-5 text-sky-600 rounded-md focus:ring-sky-500 border-slate-300 cursor-pointer"
                      />
                      <span className="text-xs font-bold text-slate-800">
                        {autoSyncInput
                          ? 'Aktif (Otomatis broadcast & terima event seketika)'
                          : 'Nonaktif (Manual hanya lewat tombol)'}
                      </span>
                    </label>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-black text-xs rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                  >
                    Simpan Pengaturan Jaringan
                  </button>
                </div>
              </form>
            </div>

            {/* UJI COBA SINYAL REALTIME */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2">
                  <Send className="w-4 h-4 text-sky-700" />
                  <h3 className="text-sm font-black text-slate-900">
                    Uji Sinyal & Komunikasi Realtime Antar Kasir
                  </h3>
                </div>
                <span className="text-[11px] text-slate-500 font-medium">
                  Kirim pesan notifikasi instan ke seluruh layar kasir lain
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-2">
                <input
                  type="text"
                  value={testSignalMsg}
                  onChange={e => setTestSignalMsg(e.target.value)}
                  placeholder="Ketik pesan uji coba..."
                  className="w-full sm:flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-sky-500 focus:bg-white transition"
                />
                <button
                  type="button"
                  onClick={handleSendTestSignal}
                  disabled={isBroadcasting || !lanSyncStatus.isConnected}
                  className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isBroadcasting ? 'Mengirim...' : 'Kirim Uji Sinyal'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 2: TERMINALS ===================== */}
        {activeTab === 'TERMINALS' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <Users className="w-4 h-4 text-sky-700" />
                  <span>Daftar Komputer Kasir & Perangkat Aktif di Toko</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Daftar perangkat yang saat ini sedang aktif dan tersambung ke jaringan lokal minimarket Anda.
                </p>
              </div>

              <button
                onClick={() => triggerLanSyncNow()}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Fleet</span>
              </button>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-black uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Terminal & Perangkat</th>
                    <th className="py-3 px-4">IP Address</th>
                    <th className="py-3 px-4">Peran di Toko</th>
                    <th className="py-3 px-4">Terakhir Terdeteksi</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {/* Komputer Ini */}
                  <tr className="bg-sky-50/50">
                    <td className="py-3 px-4 font-bold text-sky-950 flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                      <div>
                        <span className="block font-black">{lanSyncStatus.terminalName} (Perangkat Ini)</span>
                        <span className="text-[10px] text-slate-400 font-mono">ID: {localStorage.getItem('pos_lan_device_id') || 'Current'}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">
                      {lanSyncStatus.detectedIps[0] || '127.0.0.1'}
                    </td>
                    <td className="py-3 px-4 font-black text-sky-800">
                      {lanSyncStatus.role}
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                      Baru saja
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                        AKTIF / LOCAL
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-slate-400 text-[10px] italic">Komputer Anda</span>
                    </td>
                  </tr>

                  {/* Terminal Lain yang terhubung */}
                  {(lanSyncStatus.connectedClients || [])
                    .filter(c => c.deviceId !== localStorage.getItem('pos_lan_device_id'))
                    .map((client, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 transition">
                        <td className="py-3 px-4 font-bold text-slate-800">
                          <div className="flex items-center gap-2">
                            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                            <div>
                              <span className="block">{client.terminalName || client.deviceName || 'Terminal Kasir'}</span>
                              <span className="text-[10px] text-slate-400 font-mono">ID: {client.deviceId}</span>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-700">
                          {client.ipAddress}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-700">
                          {client.role || 'CLIENT'}
                        </td>
                        <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                          {client.lastSeen ? new Date(client.lastSeen).toLocaleTimeString('id-ID') : 'Aktif'}
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                            ONLINE
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => broadcastLanTestSignal(`Ping khusus ke ${client.terminalName || 'Terminal'}`)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-sky-50 text-sky-700 font-bold rounded-lg text-[10px] border border-slate-200 transition cursor-pointer"
                          >
                            Ping Sinyal
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ===================== TAB 3: DATABASE ===================== */}
        {activeTab === 'DATABASE' && (
          <div className="space-y-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-sky-700" />
                    <span>Replikasi Data Penuh (Full Database Sync)</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Sebarkan seluruh master produk, persediaan, transaksi, dan akun pelanggan dari server utama ke seluruh kasir dalam 1 kali klik.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                  <span className="text-xs font-bold text-slate-500 block">Total Produk</span>
                  <span className="text-xl font-black text-slate-900 mt-1 block">{(products || []).length} Barang</span>
                </div>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                  <span className="text-xs font-bold text-slate-500 block">Total Transaksi Kasir</span>
                  <span className="text-xl font-black text-slate-900 mt-1 block">{(sales || []).length} Struk</span>
                </div>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                  <span className="text-xs font-bold text-slate-500 block">Versi Database Sinkron</span>
                  <span className="text-xl font-black text-sky-700 mt-1 block">Versi {lanSyncStatus.localVersion}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Kirim seluruh data toko ini ke semua kasir yang terhubung? Data kasir client akan diperbarui sesuai master.')) {
                      pushFullDbToLan();
                    }
                  }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-black text-xs rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Push Database ke Seluruh Terminal Kasir</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Tarik data master terbaru dari Server? Data lokal kasir ini akan disesuaikan dengan master.')) {
                      pullFullDbFromLan();
                    }
                  }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-xs rounded-xl border border-slate-300 transition active:scale-95 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-600" />
                  <span>Tarik Database Terbaru dari Server Master</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 4: LOGS ===================== */}
        {activeTab === 'LOGS' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-sky-700" />
                  <span>Audit Stream: Log Aktivitas Sinkronisasi Realtime</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Catatan waktu-nyata setiap event transaksi, pembaruan stok, dan koneksi kasir yang disinkronkan.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={logFilter}
                  onChange={e => setLogFilter(e.target.value as any)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold cursor-pointer"
                >
                  <option value="ALL">Semua Event</option>
                  <option value="TRANSACTION">Penjualan & Transaksi</option>
                  <option value="PRODUCT">Produk & Stok</option>
                  <option value="SYSTEM">Sistem & Sinyal</option>
                </select>

                <button
                  onClick={clearLanLogs}
                  className="px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl border border-rose-200 transition flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Bersihkan Log</span>
                </button>
              </div>
            </div>

            {filteredLogs.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-xs font-bold">Belum ada aktivitas sinkronisasi baru yang tercatat.</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Log akan muncul secara otomatis saat transaksi baru terjadi atau produk diperbarui.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {filteredLogs.map(log => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-50 transition flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="flex items-start gap-2.5">
                      <div
                        className={`mt-0.5 w-2 h-2 rounded-full shrink-0 ${
                          log.status === 'SUCCESS'
                            ? 'bg-emerald-500'
                            : log.status === 'INFO'
                            ? 'bg-sky-500'
                            : log.status === 'WARNING'
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-slate-900">{log.eventTitle}</span>
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-200 text-slate-700">
                            {log.sourceTerminal}
                          </span>
                        </div>
                        {log.details && (
                          <p className="text-slate-600 text-[11px] mt-0.5 font-medium">{log.details}</p>
                        )}
                      </div>
                    </div>

                    <span className="text-[10px] font-mono text-slate-400 shrink-0">
                      {log.timestamp}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
