import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Barcode,
  Camera,
  Trash2,
  Plus,
  Minus,
  PauseCircle,
  XCircle,
  UserCheck,
  Tag,
  HelpCircle,
  ShoppingBag,
  Mic,
  MicOff,
  CheckCircle2,
  AlertTriangle,
  Lock,
  ShieldAlert,
  Clock,
  UserPlus,
  X,
  Phone,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { Product, SaleTransaction } from '../../types/pos';
import { formatRupiah } from '../../utils/formatters';
import { PaymentModal } from './PaymentModal';
import { ReceiptModal } from './ReceiptModal';
import { CameraScannerModal } from './CameraScannerModal';
import { VoidModal } from './VoidModal';
import { PendingDrawer } from './PendingDrawer';
import { PendingLabelModal } from './PendingLabelModal';
import { PelangganModal } from '../pelanggan/PelangganModal';

export const KasirView: React.FC = () => {
  const {
    products,
    categories,
    customers,
    cart,
    addToCart,
    updateCartQty,
    setCartQtyDirect,
    setCartItemDiscount,
    removeFromCart,
    clearCart,
    selectedCustomer,
    setSelectedCustomer,
    transactionDiscount,
    setTransactionDiscount,
    cartSubtotal,
    cartTotal,
    holdCurrentCart,
    pendingCarts,
    reprintTransaction,
    setReprintTransaction,
    activeShift,
    startShift,
    currentUser,
    verifyPin,
  } = usePOS();

  // Mode View: 'speed' (tabel kasir retail cepat) or 'touch' (galeri produk sentuh)
  const [viewMode, setViewMode] = useState<'speed' | 'touch'>('speed');

  const [barcodeInput, setBarcodeInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedCartIndex, setSelectedCartIndex] = useState<number | null>(null);
  const [lastScannedId, setLastScannedId] = useState<string | null>(null);

  // Modals
  const [showPayment, setShowPayment] = useState(false);
  const [showCameraScan, setShowCameraScan] = useState(false);
  const [showVoid, setShowVoid] = useState(false);
  const [showPending, setShowPending] = useState(false);
  const [showPendingLabelModal, setShowPendingLabelModal] = useState(false);
  const [showShortcutsHelp, setShowShortcutsHelp] = useState(false);
  const [showMemberSelect, setShowMemberSelect] = useState(false);
  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [showFindProductModal, setShowFindProductModal] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [activeReceiptSale, setActiveReceiptSale] = useState<SaleTransaction | null>(null);

  // Open Shift Mandatory Modal State
  const [showOpenShiftModal, setShowOpenShiftModal] = useState(false);
  const [openShiftName, setOpenShiftName] = useState('Shift Pagi');
  const [openShiftInitialCash, setOpenShiftInitialCash] = useState(100000);

  // Pending cart actions with mandatory label
  const handleOpenPendingFlow = () => {
    if (cart.length > 0) {
      setShowPendingLabelModal(true);
    } else if (pendingCarts.length > 0) {
      setShowPending(true);
    } else {
      showNotification('Keranjang masih kosong. Tidak ada transaksi yang dapat dipending.');
    }
  };

  const handleConfirmPendingWithLabel = (label: string, notes?: string) => {
    holdCurrentCart(label, notes);
    setShowPendingLabelModal(false);
    showNotification(`Transaksi berhasil dipending dengan label: "${label}".`);
    setTimeout(() => {
      barcodeInputRef.current?.focus();
    }, 100);
  };

  // Cart item removal/reduction permission authorization state
  const canModifyCartWithoutPin =
    currentUser.role === 'OWNER' ||
    currentUser.role === 'SUPERVISOR' ||
    currentUser.permissions?.canVoid === true;

  const [pendingAuthAction, setPendingAuthAction] = useState<{
    type: 'REMOVE_ITEM' | 'REDUCE_QTY' | 'CLEAR_CART';
    productId?: string;
    productName?: string;
    targetQty?: number;
    description: string;
  } | null>(null);
  const [authPinInput, setAuthPinInput] = useState('');
  const [authPinError, setAuthPinError] = useState('');

  const showNotification = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleReduceQty = (productId: string, currentQty: number, productName: string) => {
    if (canModifyCartWithoutPin) {
      if (currentQty <= 1) {
        removeFromCart(productId);
      } else {
        updateCartQty(productId, -1);
      }
      return;
    }

    setAuthPinError('');
    setAuthPinInput('');
    setPendingAuthAction({
      type: currentQty <= 1 ? 'REMOVE_ITEM' : 'REDUCE_QTY',
      productId,
      productName,
      targetQty: currentQty - 1,
      description:
        currentQty <= 1
          ? `Hapus item "${productName}" dari keranjang belanja`
          : `Kurangi kuantitas item "${productName}" dari ${currentQty} menjadi ${currentQty - 1}`,
    });
  };

  const handleDirectQtyChange = (
    productId: string,
    currentQty: number,
    newQty: number,
    productName: string
  ) => {
    if (newQty >= currentQty || canModifyCartWithoutPin) {
      setCartQtyDirect(productId, Math.max(1, newQty));
      return;
    }

    setAuthPinError('');
    setAuthPinInput('');
    setPendingAuthAction({
      type: 'REDUCE_QTY',
      productId,
      productName,
      targetQty: Math.max(1, newQty),
      description: `Kurangi kuantitas item "${productName}" dari ${currentQty} menjadi ${Math.max(1, newQty)}`,
    });
  };

  const handleRemoveItem = (productId: string, productName: string) => {
    if (canModifyCartWithoutPin) {
      removeFromCart(productId);
      showNotification(`Barang "${productName}" telah dihapus.`);
      return;
    }

    setAuthPinError('');
    setAuthPinInput('');
    setPendingAuthAction({
      type: 'REMOVE_ITEM',
      productId,
      productName,
      description: `Hapus item "${productName}" dari keranjang belanja`,
    });
  };

  const handleClearCartClick = () => {
    if (cart.length === 0) {
      showNotification('Keranjang belanja masih kosong. Tidak ada barang untuk dibatalkan.');
      return;
    }
    if (canModifyCartWithoutPin) {
      setShowClearConfirm(true);
      return;
    }

    setAuthPinError('');
    setAuthPinInput('');
    setPendingAuthAction({
      type: 'CLEAR_CART',
      description: `Batalkan seluruh transaksi keranjang belanja (${cart.length} item, total ${formatRupiah(cartTotal)})`,
    });
  };

  const handleConfirmAuthAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingAuthAction) return;

    const cleanAuthPin = (authPinInput || '').trim();
    const res = verifyPin(cleanAuthPin, 'canVoid');
    if (!res.success) {
      setAuthPinError(res.message || 'PIN Otorisasi salah! Memerlukan hak akses Supervisor / Owner.');
      return;
    }

    if (pendingAuthAction.type === 'REMOVE_ITEM' && pendingAuthAction.productId) {
      removeFromCart(pendingAuthAction.productId);
      showNotification(
        `Penghapusan "${pendingAuthAction.productName}" disetujui oleh ${res.user?.name}.`
      );
    } else if (
      pendingAuthAction.type === 'REDUCE_QTY' &&
      pendingAuthAction.productId &&
      pendingAuthAction.targetQty !== undefined
    ) {
      setCartQtyDirect(pendingAuthAction.productId, pendingAuthAction.targetQty);
      showNotification(
        `Pengurangan kuantitas disetujui oleh ${res.user?.name}.`
      );
    } else if (pendingAuthAction.type === 'CLEAR_CART') {
      clearCart();
      showNotification(
        `Pembatalan keranjang belanja disetujui oleh ${res.user?.name}.`
      );
    }

    setPendingAuthAction(null);
    setAuthPinInput('');
    setAuthPinError('');
  };

  const handleOpenShiftSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    startShift(openShiftInitialCash, openShiftName);
    setShowOpenShiftModal(false);
    showNotification(`Shift "${openShiftName}" berhasil dibuka. Silakan mulai transaksi kasir!`);
    setTimeout(() => {
      barcodeInputRef.current?.focus();
    }, 150);
  };

  // Item discount editing modal
  const [editingDiscountItem, setEditingDiscountItem] = useState<{
    productId: string;
    name: string;
    type: 'PERCENT' | 'NOMINAL';
    value: number;
  } | null>(null);

  // Voice recording state
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  const barcodeInputRef = useRef<HTMLInputElement | null>(null);

  // Play cashier beep sound
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.08);
    } catch {
      // AudioContext might be blocked until user gesture
    }
  };

  // Keyboard shortcuts listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isInput = ['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName);

      if (e.key === 'F1') {
        e.preventDefault();
        setShowFindProductModal(prev => !prev);
      } else if (e.key === 'F2') {
        e.preventDefault();
        barcodeInputRef.current?.focus();
        barcodeInputRef.current?.select();
      } else if (e.key === 'F4') {
        e.preventDefault();
        handleOpenPendingFlow();
      } else if (e.key === 'F5') {
        e.preventDefault();
        setShowVoid(true);
      } else if (e.key === 'F8') {
        e.preventDefault();
        setShowMemberSelect(prev => !prev);
      } else if (e.key === 'F12' || (e.code === 'Space' && !isInput)) {
        if (cart.length > 0) {
          e.preventDefault();
          if (!activeShift) {
            setShowOpenShiftModal(true);
            showNotification('Harap buka shift kasir terlebih dahulu sebelum memulai transaksi!');
            return;
          }
          setShowPayment(true);
        }
      } else if (e.key === 'Escape') {
        setShowPayment(false);
        setShowCameraScan(false);
        setShowVoid(false);
        setShowPending(false);
        setShowShortcutsHelp(false);
        setShowMemberSelect(false);
        setShowFindProductModal(false);
        setShowOpenShiftModal(false);
        setPendingAuthAction(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    const handleTriggerPendingEvent = () => {
      handleOpenPendingFlow();
    };
    const handleTriggerVoidEvent = () => {
      setShowVoid(true);
    };
    window.addEventListener('pos-trigger-pending', handleTriggerPendingEvent);
    window.addEventListener('pos-trigger-void', handleTriggerVoidEvent);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('pos-trigger-pending', handleTriggerPendingEvent);
      window.removeEventListener('pos-trigger-void', handleTriggerVoidEvent);
    };
  }, [cart, holdCurrentCart, pendingCarts.length, activeShift]);

  // Handle barcode submission
  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeShift) {
      setShowOpenShiftModal(true);
      showNotification('Harap buka shift kasir terlebih dahulu sebelum memindai barang!');
      return;
    }

    const code = (barcodeInput || '').trim();
    if (!code) return;

    // Exact barcode or SKU match
    const matched = products.find(
      p => p.barcode === code || (p.sku || '').toLowerCase() === code.toLowerCase()
    );

    if (matched) {
      addToCart(matched, 1);
      setLastScannedId(matched.id);
      playBeep();
      setBarcodeInput('');
    } else {
      // Fuzzy search fallback
      const fuzzy = products.find(p => p.name.toLowerCase().includes(code.toLowerCase()));
      if (fuzzy) {
        addToCart(fuzzy, 1);
        setLastScannedId(fuzzy.id);
        playBeep();
        setBarcodeInput('');
      } else {
        alert(`Produk dengan barcode/kode "${code}" tidak ditemukan!`);
      }
    }
  };

  // Add product to cart helper
  const handleSelectProduct = (p: Product) => {
    if (!activeShift) {
      setShowOpenShiftModal(true);
      showNotification('Harap buka shift kasir terlebih dahulu sebelum memilih barang!');
      return;
    }

    addToCart(p, 1);
    setLastScannedId(p.id);
    playBeep();
    setShowFindProductModal(false);
  };

  // Voice command search
  const toggleVoiceSearch = () => {
    if (!activeShift) {
      setShowOpenShiftModal(true);
      showNotification('Harap buka shift kasir terlebih dahulu sebelum memulai transaksi!');
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Browser Anda belum mendukung Web Speech API. Silakan ketik di kotak pencarian.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'id-ID';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        const found = products.find(p => p.name.toLowerCase().includes(transcript.toLowerCase()));
        if (found) {
          addToCart(found, 1);
          setLastScannedId(found.id);
          playBeep();
        } else {
          setBarcodeInput(transcript);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  // Total items and pcs count
  const totalItemCount = cart.length;
  const totalPcsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Filtered products for touch gallery
  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'ALL' || p.categoryId === selectedCategory;
    const matchesQuery =
      searchQuery === '' ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.barcode.includes(searchQuery) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesQuery && p.isActive;
  });

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 pb-4 sm:pb-6 overflow-y-auto bg-slate-100 text-slate-900 selection:bg-sky-200">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* BANNER: SHIFT BELUM DIBUKA */}
        {!activeShift && (
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-white px-4 py-3.5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md border-2 border-amber-600">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-700/60 rounded-xl text-white shrink-0">
                <AlertTriangle className="w-6 h-6 animate-pulse text-amber-200" />
              </div>
              <div>
                <h3 className="font-black text-sm sm:text-base flex items-center gap-2">
                  <span>Shift Kasir Belum Dibuka!</span>
                  <span className="text-[10px] px-2 py-0.5 bg-white text-amber-900 font-extrabold rounded-full uppercase tracking-wider">
                    Wajib Buka Shift
                  </span>
                </h3>
                <p className="text-xs text-amber-100 mt-0.5">
                  Sebelum melakukan transaksi atau memindai barang, kasir wajib membuka shift dan mencatat modal awal kas laci.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowOpenShiftModal(true)}
              className="px-5 py-2.5 bg-white hover:bg-amber-50 text-amber-950 font-black text-xs sm:text-sm rounded-xl shadow-md transition cursor-pointer shrink-0 flex items-center gap-2 active:scale-95"
            >
              <Clock className="w-4 h-4 text-amber-600" />
              <span>Buka Shift Sekarang</span>
            </button>
          </div>
        )}

        {/* ========================================================
            BARIS ATAS: KOTAK SCAN BARCODE + KOTAK LED DISPLAY TOTAL
           ======================================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 items-stretch">
          {/* KIRI: Input Barcode / PLU Utama */}
          <div className="lg:col-span-7 bg-white p-3.5 sm:p-4 rounded-2xl border-2 border-sky-200 shadow-xs flex flex-col justify-between">
            {/* Toolbar Atas: Tombol 1 (Kasir), Tombol 2 (Produk), Tombol 3 (Member) dari kiri */}
            <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
              <div className="flex items-center gap-2 flex-wrap">
                {/* 1. Kasir & 2. Produk Switcher */}
                <div className="flex items-center gap-1 bg-sky-50 border border-sky-200 p-0.5 rounded-xl text-xs font-bold shadow-2xs">
                  <button
                    type="button"
                    onClick={() => setViewMode('speed')}
                    className={`px-3 py-1 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                      viewMode === 'speed'
                        ? 'bg-sky-600 text-white font-black shadow-xs'
                        : 'text-sky-800 hover:bg-sky-100 font-bold'
                    }`}
                    title="Mode Kasir Cepat (Scan Barcode & Keyboard)"
                  >
                    <span>⚡</span>
                    <span>Kasir</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('touch')}
                    className={`px-3 py-1 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                      viewMode === 'touch'
                        ? 'bg-sky-600 text-white font-black shadow-xs'
                        : 'text-sky-800 hover:bg-sky-100 font-bold'
                    }`}
                    title="Mode Galeri Produk (Touch POS / Gambar)"
                  >
                    <span>🖼️</span>
                    <span>Produk</span>
                  </button>
                </div>

                {/* 3. Member */}
                <div className="flex items-center">
                  {selectedCustomer ? (
                    <div className="flex items-center gap-1.5 bg-sky-50 border border-sky-300 px-2.5 py-1 rounded-xl text-xs text-sky-800 font-bold shadow-2xs">
                      <span>👤 {selectedCustomer.name}</span>
                      <button
                        type="button"
                        onClick={() => setSelectedCustomer(null)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 p-0.5 rounded ml-0.5 cursor-pointer"
                        title="Lepas Member"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowMemberSelect(true)}
                      className="px-3 py-1 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
                      title="Pilih atau Daftarkan Member Pelanggan [F8]"
                    >
                      <span>👤</span>
                      <span>Member</span>
                      <span className="text-[10px] text-sky-500 font-mono">[F8]</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Input field with Kamera, Suara & Cari buttons */}
            <form onSubmit={handleBarcodeSubmit} className="relative flex items-center">
              <input
                ref={barcodeInputRef}
                id="pos-barcode-search"
                type="text"
                value={barcodeInput}
                onChange={e => setBarcodeInput(e.target.value)}
                placeholder="Scan Barcode / Ketik Nama Produk... (F2)"
                autoFocus
                className="w-full pl-3 sm:pl-4 pr-44 sm:pr-56 py-2.5 sm:py-3 bg-slate-50 border-2 border-sky-300 rounded-xl text-sm sm:text-base font-extrabold text-slate-900 focus:bg-white focus:outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 font-mono tracking-wide placeholder:font-sans placeholder:font-normal placeholder:text-slate-400 shadow-2xs"
              />

              <div className="absolute right-1.5 sm:right-2 flex items-center gap-1 sm:gap-1.5">
                <button
                  type="button"
                  onClick={() => setShowCameraScan(true)}
                  className="px-2 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition shadow-xs"
                  title="Scan Barcode Kemasan dengan Kamera HP / Laptop"
                >
                  <span>📷</span>
                  <span className="hidden sm:inline">Kamera</span>
                </button>

                <button
                  type="button"
                  onClick={toggleVoiceSearch}
                  className={`px-2 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                  }`}
                  title="Pencarian Suara Kasir"
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => setShowFindProductModal(true)}
                  className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 active:scale-95 text-slate-800 rounded-lg text-xs font-bold font-mono cursor-pointer transition"
                  title="Pencarian Cepat Produk [F1]"
                >
                  Cari [F1]
                </button>
              </div>
            </form>
          </div>

          {/* KANAN: Kotak Layar LED Monitor Total Digital Kasir */}
          <div className="lg:col-span-5 pos-led-display p-3.5 sm:p-4 text-right flex flex-col justify-between select-none">
            <div className="flex items-center justify-between">
              <span className="pos-led-label text-[10px] sm:text-xs font-bold uppercase tracking-wider">
                TOTAL TAGIHAN
              </span>
              <span className="text-[11px] sm:text-xs text-slate-400 font-mono">
                {totalItemCount} Item ({totalPcsCount} pcs)
              </span>
            </div>

            <div className="pos-led-total text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight my-1 font-mono">
              {formatRupiah(cartTotal)}
            </div>

            <div className="flex items-center justify-between text-[11px] sm:text-xs pt-1.5 border-t border-slate-800">
              <span className="text-slate-400">Status Transaksi:</span>
              <span className="pos-led-change font-bold font-mono">
                {cart.length > 0 ? 'SIAP BAYAR (F12)' : 'STANDBY'}
              </span>
            </div>
          </div>
        </div>

        {/* ========================================================
            VIEW 1: MODE TABEL TRANSAKSI KASIR CEPAT (DEFAULT RETAIL)
           ======================================================== */}
        {viewMode === 'speed' ? (
          <div className="bg-white rounded-2xl border-2 border-slate-200 shadow-sm overflow-hidden flex flex-col">
            <div className="overflow-x-auto min-h-[300px] max-h-[500px] overflow-y-auto">
              <table className="w-full text-left border-collapse">
                <thead className="sticky top-0 z-10">
                  <tr className="pos-table-header">
                    <th className="hidden md:table-cell py-2.5 px-3 w-12 text-center">No</th>
                    <th className="hidden sm:table-cell py-2.5 px-3 w-36">PLU / Barcode</th>
                    <th className="py-2.5 px-2.5 sm:px-3">Nama Produk</th>
                    <th className="py-2.5 px-2 sm:px-3 w-32 text-center">Qty</th>
                    <th className="hidden lg:table-cell py-2.5 px-3 w-20 text-center">Satuan</th>
                    <th className="hidden sm:table-cell py-2.5 px-3 w-28 text-right">Harga</th>
                    <th className="hidden lg:table-cell py-2.5 px-3 w-24 text-right">Diskon</th>
                    <th className="py-2.5 px-2.5 sm:px-3 text-right">Subtotal</th>
                    <th className="py-2.5 px-2 text-center w-12">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-xs">
                  {cart.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-16 text-center text-slate-400 font-sans">
                        <ShoppingBag className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                        <p className="font-bold text-slate-600 text-sm">Keranjang Transaksi Kosong</p>
                        <p className="text-xs text-slate-400 mt-1">
                          Arahkan barcode scanner fisik, scan kamera HP, atau tekan{' '}
                          <kbd className="px-1.5 py-0.5 bg-slate-200 rounded font-mono font-bold">F1</kbd> untuk mencari barang.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    cart.map((item, idx) => {
                      const isNewlyScanned = item.productId === lastScannedId;
                      const isSelected = selectedCartIndex === idx;

                      return (
                        <tr
                          key={item.id}
                          onClick={() => setSelectedCartIndex(idx)}
                          className={`pos-table-row cursor-pointer transition ${
                            isNewlyScanned ? 'active-scan-row' : isSelected ? 'bg-blue-50/70' : ''
                          }`}
                        >
                          <td className="hidden md:table-cell py-2.5 px-3 text-center text-slate-400">
                            {idx + 1}
                          </td>
                          <td className="hidden sm:table-cell py-2.5 px-3 font-mono font-bold text-slate-600">
                            {item.sku}
                          </td>
                          <td className="py-2.5 px-2.5 sm:px-3 font-sans font-bold text-slate-900">
                            <div>{item.name}</div>
                            {item.discountValue > 0 && (
                              <span className="text-[10px] text-red-600 font-bold">
                                Diskon: -
                                {item.discountType === 'PERCENT'
                                  ? `${item.discountValue}%`
                                  : formatRupiah(item.discountValue)}
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-2 sm:px-3">
                            <div className="flex items-center justify-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-300">
                              <button
                                type="button"
                                onClick={e => {
                                  e.stopPropagation();
                                  handleReduceQty(item.productId, item.quantity, item.name);
                                }}
                                className="w-6 h-6 rounded bg-white hover:bg-slate-200 text-slate-700 font-black flex items-center justify-center shadow-xs"
                              >
                                -
                              </button>
                              <input
                                type="number"
                                min={1}
                                value={item.quantity}
                                onClick={e => e.stopPropagation()}
                                onChange={e => {
                                  const val = parseInt(e.target.value) || 1;
                                  handleDirectQtyChange(item.productId, item.quantity, val, item.name);
                                }}
                                className="w-10 text-center font-bold font-mono bg-transparent text-slate-900 focus:outline-none"
                              />
                              <button
                                type="button"
                                onClick={e => {
                                  e.stopPropagation();
                                  updateCartQty(item.productId, 1);
                                }}
                                className="w-6 h-6 rounded bg-white hover:bg-slate-200 text-slate-700 font-black flex items-center justify-center shadow-xs"
                              >
                                +
                              </button>
                            </div>
                          </td>
                          <td className="hidden lg:table-cell py-2.5 px-3 text-center font-sans text-slate-500">
                            {item.unit}
                          </td>
                          <td className="hidden sm:table-cell py-2.5 px-3 text-right font-bold text-slate-700">
                            {formatRupiah(item.sellingPrice)}
                          </td>
                          <td className="hidden lg:table-cell py-2.5 px-3 text-right font-sans">
                            <button
                              type="button"
                              onClick={e => {
                                e.stopPropagation();
                                setEditingDiscountItem({
                                  productId: item.productId,
                                  name: item.name,
                                  type: item.discountType,
                                  value: item.discountValue,
                                });
                              }}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-900 rounded text-[11px] font-bold border border-slate-300"
                            >
                              {item.discountValue > 0 ? 'Edit Diskon' : '+ Diskon'}
                            </button>
                          </td>
                          <td className="py-2.5 px-2.5 sm:px-3 text-right font-black text-slate-950">
                            {formatRupiah(item.subtotal)}
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <button
                              type="button"
                              onClick={e => {
                                e.stopPropagation();
                                handleRemoveItem(item.productId, item.name);
                              }}
                              className="p-1 text-slate-400 hover:text-red-600 transition"
                              title="Hapus Barang"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Footer Keranjang & Tombol Bayar */}
            <div className="p-3 bg-slate-50 border-t-2 border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center justify-between sm:justify-start gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleClearCartClick}
                  className={`px-3 py-2 border rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    cart.length > 0
                      ? 'bg-white border-red-200 text-red-600 hover:bg-red-50 hover:border-red-400 shadow-xs'
                      : 'bg-slate-100 border-slate-200 text-slate-400 hover:bg-slate-200'
                  }`}
                  title="Batalkan seluruh barang belanjaan dalam transaksi kasir saat ini"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Batal Semua</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowVoid(true)}
                  className="px-3 py-2 bg-red-50 hover:bg-red-100 border border-red-300 text-red-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                  title="Void Transaksi / Pembatalan Struk atau Item [F5]"
                >
                  <span>❌ Void [F5]</span>
                </button>

                <button
                  type="button"
                  onClick={handleOpenPendingFlow}
                  className="px-3 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                  title="Tunda Transaksi / Buka Antrean Tertunda [F4]"
                >
                  <PauseCircle className="w-4 h-4 text-amber-700" />
                  <span>{cart.length > 0 ? 'Tunda [F4]' : 'Pending [F4]'}</span>
                </button>

                {pendingCarts.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowPending(true)}
                    className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95 animate-pulse"
                    title="Buka Daftar Antrean Transaksi Tertunda"
                  >
                    <span>Antrean Pending</span>
                    <span className="bg-slate-950 text-amber-400 text-[10px] px-1.5 py-0.5 rounded-full font-black">
                      {pendingCarts.length}
                    </span>
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                <div className="text-left sm:text-right">
                  <span className="text-[10px] text-slate-500 font-bold uppercase block leading-tight">
                    Total Tagihan
                  </span>
                  <span className="text-xl sm:text-2xl font-black text-red-600 font-mono">
                    {formatRupiah(cartTotal)}
                  </span>
                </div>

                <button
                  type="button"
                  disabled={cart.length === 0}
                  onClick={() => {
                    if (!activeShift) {
                      setShowOpenShiftModal(true);
                      showNotification('Harap buka shift kasir terlebih dahulu sebelum memproses pembayaran!');
                      return;
                    }
                    setShowPayment(true);
                  }}
                  className="px-6 sm:px-8 py-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 disabled:opacity-40 text-white rounded-xl font-black text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
                  title="Buka Jendela Pembayaran Kasir [F12 / Spasi]"
                >
                  <span>BAYAR SEKARANG [F12]</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* ========================================================
             VIEW 2: MODE LAYAR SENTUH / GALERI FOTO PRODUK
             ======================================================== */
          <div className="space-y-3">
            {/* Kategori Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              <button
                onClick={() => setSelectedCategory('ALL')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  selectedCategory === 'ALL'
                    ? 'bg-sky-600 text-white font-black shadow-xs'
                    : 'bg-white border border-slate-300 text-slate-700 hover:bg-sky-50 hover:text-sky-700'
                }`}
              >
                Semua Kategori
              </button>
              {categories.map(c => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCategory(c.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    selectedCategory === c.id
                      ? 'bg-sky-600 text-white font-black shadow-xs'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-sky-50 hover:text-sky-700'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>

            {/* Grid Kartu Produk Touch */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
              {filteredProducts.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectProduct(p)}
                  className="bg-white hover:bg-yellow-50 border-2 border-slate-200 hover:border-yellow-400 rounded-2xl p-3 flex flex-col justify-between text-left transition shadow-xs active:scale-95 group cursor-pointer"
                >
                  <div>
                    <div className="flex justify-between items-start mb-1 text-[10px] text-slate-400 font-mono">
                      <span>{p.sku}</span>
                      <span className="font-bold text-emerald-600 bg-emerald-50 px-1 rounded">
                        Stok: {p.stock}
                      </span>
                    </div>
                    <h4 className="font-bold text-slate-800 text-xs line-clamp-2 group-hover:text-red-600">
                      {p.name}
                    </h4>
                  </div>
                  <div className="mt-3 pt-1 border-t border-slate-100 flex items-baseline justify-between">
                    <span className="font-mono font-black text-sm text-red-600">
                      {formatRupiah(p.sellingPrice)}
                    </span>
                    <span className="text-[10px] text-slate-400">/{p.unit}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================
          MODAL: PENCARIAN CEPAT PRODUK (F1)
         ======================================================== */}
      {showFindProductModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border-2 border-blue-500 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-4 bg-gradient-to-r from-blue-700 to-blue-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                <h3 className="font-bold text-sm">Pencarian Cepat Produk Kasir [F1]</h3>
              </div>
              <button
                onClick={() => setShowFindProductModal(false)}
                className="text-white hover:text-slate-200 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-4 border-b border-slate-200 bg-slate-50">
              <input
                type="text"
                autoFocus
                placeholder="Ketik nama produk atau barcode..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 font-sans"
              />
            </div>

            <div className="flex-1 overflow-y-auto p-4 divide-y divide-slate-100">
              {filteredProducts.slice(0, 30).map(p => (
                <div
                  key={p.id}
                  onClick={() => handleSelectProduct(p)}
                  className="py-2.5 px-3 hover:bg-yellow-50 rounded-xl flex items-center justify-between cursor-pointer transition"
                >
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{p.name}</h4>
                    <span className="text-xs text-slate-500 font-mono">
                      Barcode: {p.barcode} • SKU: {p.sku} • Sisa Stok: {p.stock}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-black text-sm text-red-600">
                      {formatRupiah(p.sellingPrice)}
                    </div>
                    <span className="text-[10px] text-slate-400">Pilih [Enter]</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CAMERA SCANNER */}
      {showCameraScan && (
        <CameraScannerModal
          onClose={() => setShowCameraScan(false)}
          onScan={(code) => {
            setShowCameraScan(false);
            const matched = products.find(p => p.barcode === code || p.sku.toLowerCase() === code.toLowerCase());
            if (matched) {
              addToCart(matched, 1);
              setLastScannedId(matched.id);
              playBeep();
            } else {
              setBarcodeInput(code);
            }
          }}
        />
      )}

      {/* MODAL: PAYMENT CHECKOUT */}
      {showPayment && (
        <PaymentModal
          onClose={() => setShowPayment(false)}
          onSuccess={(sale) => {
            setShowPayment(false);
            setActiveReceiptSale(sale);
          }}
        />
      )}

      {/* MODAL: RECEIPT THERMAL */}
      {activeReceiptSale && (
        <ReceiptModal
          sale={activeReceiptSale}
          onClose={() => setActiveReceiptSale(null)}
        />
      )}

      {/* MODAL: VOID ITEM */}
      {showVoid && (
        <VoidModal
          onClose={() => setShowVoid(false)}
          onSuccess={(msg) => {
            setShowVoid(false);
            showNotification(msg);
          }}
        />
      )}

      {/* DRAWER: PENDING CARTS */}
      {showPending && (
        <PendingDrawer
          isOpen={showPending}
          onClose={() => setShowPending(false)}
        />
      )}

      {/* MODAL: PENDING LABEL (F4) */}
      {showPendingLabelModal && (
        <PendingLabelModal
          isOpen={showPendingLabelModal}
          onClose={() => setShowPendingLabelModal(false)}
          onConfirm={handleConfirmPendingWithLabel}
          cartItemsCount={cart.length}
          cartPcsCount={cart.reduce((s, i) => s + i.quantity, 0)}
          cartTotal={cartTotal}
          customerName={selectedCustomer?.name}
          sampleItems={cart.map(i => ({ name: i.name, quantity: i.quantity }))}
        />
      )}

      {/* MODAL: MEMBER SELECT WITH SEARCH */}
      {showMemberSelect && (() => {
        const query = memberSearchQuery.trim().toLowerCase();
        const filteredModalCustomers = customers.filter(c => {
          if (!query) return true;
          return (
            (c.name && c.name.toLowerCase().includes(query)) ||
            (c.memberCode && c.memberCode.toLowerCase().includes(query)) ||
            (c.phone && c.phone.toLowerCase().includes(query)) ||
            (c.address && c.address.toLowerCase().includes(query))
          );
        });

        const handleSelectAndClose = (cust: typeof customers[0] | null) => {
          setSelectedCustomer(cust);
          setShowMemberSelect(false);
          setMemberSearchQuery('');
          if (cust) {
            showNotification(`Member "${cust.name}" (${cust.memberCode}) berhasil dipilih!`);
          } else {
            showNotification('Mode Pelanggan Umum aktif.');
          }
          setTimeout(() => {
            barcodeInputRef.current?.focus();
          }, 100);
        };

        return (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 no-print animate-in fade-in duration-150">
            <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border-2 border-sky-400 overflow-hidden flex flex-col max-h-[90vh]">
              {/* Header Modal */}
              <div className="p-4 bg-gradient-to-r from-sky-600 via-sky-700 to-blue-700 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-white/15 rounded-xl border border-white/20">
                    <UserCheck className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-black text-sm sm:text-base leading-tight">
                      Pilih Member / Pelanggan [F8]
                    </h3>
                    <p className="text-[11px] text-sky-100 font-medium">
                      Cari nama member, kode member, atau nomor telepon
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowMemberSelect(false);
                    setMemberSearchQuery('');
                  }}
                  className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition cursor-pointer"
                  title="Tutup Modal [Esc]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Input Pencarian Member (Live Search) */}
              <div className="p-3.5 bg-slate-50 border-b border-slate-200">
                <div className="relative flex items-center">
                  <Search className="w-4 h-4 text-sky-600 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    autoFocus
                    value={memberSearchQuery}
                    onChange={e => setMemberSearchQuery(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (filteredModalCustomers.length > 0) {
                          handleSelectAndClose(filteredModalCustomers[0]);
                        }
                      } else if (e.key === 'Escape') {
                        e.preventDefault();
                        setShowMemberSelect(false);
                        setMemberSearchQuery('');
                      }
                    }}
                    placeholder="Cari nama, kode member (misal: MBR-001), atau no HP..."
                    className="w-full pl-9 pr-9 py-2.5 bg-white border-2 border-sky-300 focus:border-sky-500 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-3 focus:ring-sky-100 placeholder:text-slate-400 font-sans shadow-2xs"
                  />
                  {memberSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setMemberSearchQuery('')}
                      className="absolute right-3 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
                      title="Hapus pencarian"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-slate-500">
                  <span>
                    Ditemukan <strong className="text-sky-700 font-bold">{filteredModalCustomers.length}</strong> member
                  </span>
                  <span className="hidden sm:inline text-slate-400 font-mono text-[10px]">
                    Tekan [Enter] untuk pilih baris pertama
                  </span>
                </div>
              </div>

              {/* Daftar Member Terfilter */}
              <div className="p-3 space-y-2 overflow-y-auto flex-1 max-h-[50vh]">
                {/* Opsi Pelanggan Umum (Non-Member) */}
                <button
                  type="button"
                  onClick={() => handleSelectAndClose(null)}
                  className={`w-full py-2.5 px-3 text-left rounded-xl border flex items-center justify-between text-xs font-bold transition cursor-pointer ${
                    !selectedCustomer
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">👤</span>
                    <div>
                      <span className="font-extrabold text-slate-900">Pelanggan Umum (Non-Member)</span>
                      <p className="text-[10px] text-slate-500 font-normal">
                        Tidak menggunakan poin atau diskon khusus member
                      </p>
                    </div>
                  </div>
                  {!selectedCustomer ? (
                    <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black">
                      Aktif
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400">Pilih Umum</span>
                  )}
                </button>

                {/* List Member */}
                {filteredModalCustomers.length === 0 ? (
                  <div className="py-8 px-4 text-center space-y-3 bg-slate-50/70 rounded-xl border border-dashed border-slate-200">
                    <p className="text-xs text-slate-500 font-medium">
                      Tidak ditemukan member dengan nama atau kode <strong className="text-slate-800">"{memberSearchQuery}"</strong>.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddMemberModal(true);
                      }}
                      className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-black shadow-xs transition inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Daftarkan Member Baru Sekarang</span>
                    </button>
                  </div>
                ) : (
                  filteredModalCustomers.map(c => {
                    const isSelected = selectedCustomer?.id === c.id;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => handleSelectAndClose(c)}
                        className={`w-full p-3 text-left rounded-xl border transition flex items-center justify-between gap-2 cursor-pointer ${
                          isSelected
                            ? 'bg-sky-50 border-sky-400 ring-2 ring-sky-200 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-sky-300 hover:bg-slate-50/80 shadow-2xs'
                        }`}
                      >
                        <div className="space-y-1 min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 font-mono font-black text-[11px] border border-sky-300 shrink-0">
                              {c.memberCode || 'MBR'}
                            </span>
                            <h5 className="font-extrabold text-slate-900 text-xs sm:text-sm truncate">
                              {c.name}
                            </h5>
                            {c.discountRate > 0 && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-black text-[9px] border border-amber-300">
                                Diskon {c.discountRate}%
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 sm:gap-3 text-[11px] text-slate-500 font-medium flex-wrap">
                            <span className="flex items-center gap-1 text-slate-600 font-mono">
                              <Phone className="w-3 h-3 text-emerald-600" />
                              {c.phone || '-'}
                            </span>
                            <span>•</span>
                            <span className="font-bold text-purple-700">
                              ⭐ {c.points || 0} Poin
                            </span>
                            {c.totalDebt && c.totalDebt > 0 ? (
                              <>
                                <span>•</span>
                                <span className="font-mono font-bold text-red-600">
                                  Kasbon: {formatRupiah(c.totalDebt)}
                                </span>
                              </>
                            ) : null}
                          </div>
                        </div>

                        <div className="shrink-0">
                          {isSelected ? (
                            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-600 text-white text-[11px] font-black shadow-xs">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Terpilih</span>
                            </div>
                          ) : (
                            <span className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-sky-100 text-slate-700 hover:text-sky-800 text-[11px] font-bold border border-slate-200">
                              Pilih
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })
                )}
              </div>

              {/* Footer Modal: Tambah Member Baru & Batal */}
              <div className="p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setShowAddMemberModal(true)}
                  className="px-3 py-1.5 bg-white hover:bg-sky-50 border border-sky-300 text-sky-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Daftarkan Member Baru</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowMemberSelect(false);
                    setMemberSearchQuery('');
                  }}
                  className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* MODAL TAMBAH MEMBER BARU DI KASIR */}
      {showAddMemberModal && (
        <PelangganModal
          isOpen={showAddMemberModal}
          onClose={() => setShowAddMemberModal(false)}
          onSuccess={newCust => {
            setSelectedCustomer(newCust);
            setShowAddMemberModal(false);
            setShowMemberSelect(false);
            setMemberSearchQuery('');
            showNotification(
              `Member "${newCust.name}" (${newCust.memberCode}) berhasil didaftarkan dan dipasang ke kasir!`
            );
          }}
        />
      )}

      {/* MODAL: ITEM DISCOUNT */}
      {editingDiscountItem && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border border-slate-200 p-5 space-y-4">
            <h3 className="font-bold text-sm text-slate-900">
              Diskon Item: {editingDiscountItem.name}
            </h3>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setEditingDiscountItem({ ...editingDiscountItem, type: 'PERCENT' })}
                className={`py-2 rounded-xl text-xs font-bold border ${
                  editingDiscountItem.type === 'PERCENT'
                    ? 'bg-yellow-400 text-slate-950 border-yellow-400 font-black'
                    : 'bg-slate-100 text-slate-700 border-slate-300'
                }`}
              >
                Persen (%)
              </button>
              <button
                type="button"
                onClick={() => setEditingDiscountItem({ ...editingDiscountItem, type: 'NOMINAL' })}
                className={`py-2 rounded-xl text-xs font-bold border ${
                  editingDiscountItem.type === 'NOMINAL'
                    ? 'bg-yellow-400 text-slate-950 border-yellow-400 font-black'
                    : 'bg-slate-100 text-slate-700 border-slate-300'
                }`}
              >
                Nominal (Rp)
              </button>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600 mb-1 block">
                Besaran Diskon ({editingDiscountItem.type === 'PERCENT' ? '%' : 'Rp'})
              </label>
              <input
                type="number"
                min={0}
                value={editingDiscountItem.value}
                onChange={e =>
                  setEditingDiscountItem({
                    ...editingDiscountItem,
                    value: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-900"
              />
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <button
                type="button"
                onClick={() => setEditingDiscountItem(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  setCartItemDiscount(
                    editingDiscountItem.productId,
                    editingDiscountItem.type,
                    editingDiscountItem.value
                  );
                  setEditingDiscountItem(null);
                }}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl"
              >
                Terapkan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI: BATAL SEMUA (CLEAR CART) */}
      {showClearConfirm && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl border border-slate-200 overflow-hidden p-6 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-red-100 text-red-600 flex items-center justify-center shadow-inner">
              <Trash2 className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="font-black text-slate-900 text-base">Batalkan Transaksi Ini?</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Seluruh <strong>{totalItemCount} jenis barang ({totalPcsCount} pcs)</strong> senilai <strong>{formatRupiah(cartTotal)}</strong> akan dikosongkan dari keranjang transaksi kasir.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Kembali
              </button>
              <button
                type="button"
                onClick={() => {
                  clearCart();
                  setShowClearConfirm(false);
                  showNotification('Seluruh isi keranjang transaksi telah berhasil dibatalkan.');
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                Ya, Batalkan Semua
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: BUKA SHIFT KASIR WAJIB (SEBELUM BERTRANSAKSI)
         ======================================================== */}
      {showOpenShiftModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-slate-900 text-base">Buka Shift Kasir</h3>
                <p className="text-xs text-slate-500">Mulai sesi kerja kasir & catat uang kas modal laci</p>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 text-xs text-amber-900 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Aturan Keamanan POS</span>
              </div>
              <p className="text-amber-800">
                Transaksi penjualan tidak dapat dilakukan tanpa shift yang aktif. Silakan isi modal kas kecil untuk uang kembalian.
              </p>
            </div>

            <form onSubmit={handleOpenShiftSubmit} className="space-y-4 pt-1">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">Kasir Bertugas</label>
                <div className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 flex items-center justify-between">
                  <span>👤 {currentUser.name}</span>
                  <span className="text-[10px] px-2 py-0.5 bg-slate-200 text-slate-700 rounded-md font-mono">
                    {currentUser.role}
                  </span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  Nama Sesi Shift <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={openShiftName}
                  onChange={e => setOpenShiftName(e.target.value)}
                  placeholder="Misal: Shift Pagi, Shift Siang..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">
                  Modal Kas Awal di Laci (Rp) <span className="text-red-600">*</span>
                </label>
                <input
                  type="number"
                  min={0}
                  step={1000}
                  required
                  value={openShiftInitialCash}
                  onChange={e => setOpenShiftInitialCash(parseFloat(e.target.value) || 0)}
                  placeholder="100000"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <span className="text-[11px] text-slate-500 block">
                  Terbilang: {formatRupiah(openShiftInitialCash)}
                </span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowOpenShiftModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mulai & Buka Shift</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: OTORISASI SUPERVISOR / OWNER (PENGURANGAN / HAPUS ITEM)
         ======================================================== */}
      {pendingAuthAction && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-slate-900 text-base">Otorisasi Akses Diperlukan</h3>
                <p className="text-xs text-slate-500">Izin Supervisor / Owner untuk memodifikasi keranjang</p>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Tindakan yang Memerlukan Otorisasi:
              </div>
              <div className="text-xs font-black text-slate-800 bg-white border border-slate-200 p-2.5 rounded-xl">
                {pendingAuthAction.description}
              </div>
              <p className="text-[11px] text-slate-500">
                Untuk mencegah kecurangan kasir, tindakan pengurangan atau penghapusan item yang sudah discan harus disetujui Supervisor atau Owner.
              </p>
            </div>

            <form onSubmit={handleConfirmAuthAction} className="space-y-4 pt-1">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Masukkan PIN Supervisor / Owner <span className="text-red-600">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    maxLength={6}
                    autoFocus
                    required
                    value={authPinInput}
                    onChange={e => {
                      setAuthPinInput(e.target.value);
                      setAuthPinError('');
                    }}
                    placeholder="PIN Supervisor / Owner..."
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-mono tracking-widest text-center text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                {authPinError && (
                  <p className="text-xs text-red-600 font-bold mt-1.5 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{authPinError}</span>
                  </p>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setPendingAuthAction(null);
                    setAuthPinInput('');
                    setAuthPinError('');
                  }}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                >
                  Setujui Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TOAST NOTIFIKASI KASIR */}
      {toastMsg && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white px-5 py-3 rounded-2xl shadow-2xl border border-slate-700 text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <span className="text-base">🔔</span>
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
};
