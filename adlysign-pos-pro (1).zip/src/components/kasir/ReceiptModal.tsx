import React, { useState } from 'react';
import { Printer, X, CheckCircle, Smartphone } from 'lucide-react';
import { SaleTransaction } from '../../types/pos';
import { usePOS } from '../../context/POSContext';
import { formatRupiah, formatDateTime, generateBarcodeSvg } from '../../utils/formatters';

interface ReceiptModalProps {
  sale: SaleTransaction | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ sale, onClose }) => {
  const { storeProfile, hardwareSettings } = usePOS();
  const [paperWidth, setPaperWidth] = useState<'58' | '80'>(
    hardwareSettings.printerType === 'THERMAL_80' ? '80' : '58'
  );
  const [printed, setPrinted] = useState(false);

  if (!sale) return null;

  const handlePrint = () => {
    setPrinted(true);
    window.print();
  };

  const handleRawBTPrint = () => {
    // RawBT Android intent format
    const pointsLine = sale.pointsRedeemed && sale.pointsRedeemed > 0
      ? `Tukar Poin (${sale.pointsRedeemed} Pts): -${formatRupiah(sale.pointsDiscountAmount || 0)}\n`
      : '';
    const discountLine = sale.transactionDiscount > 0
      ? `Diskon: -${formatRupiah(sale.transactionDiscount)}\n`
      : '';
    const totalLabel = sale.pointsDiscountAmount && sale.pointsDiscountAmount > 0
      ? 'Sisa Kekurangan Bayar'
      : 'TOTAL';

    const receiptText = `
${storeProfile.name}
${storeProfile.address}
Telp: ${storeProfile.phone}
--------------------------------
No: ${sale.invoiceNumber}
Kasir: ${sale.cashierName}
Tgl: ${formatDateTime(sale.createdAt)}
--------------------------------
${sale.items.map(i => `${i.name.slice(0, 20)}\n${i.quantity} x ${formatRupiah(i.sellingPrice)} = ${formatRupiah(i.subtotal)}`).join('\n')}
--------------------------------
Subtotal: ${formatRupiah(sale.subtotal)}
${discountLine}${pointsLine}${totalLabel}: ${formatRupiah(sale.totalAmount)}
Bayar (${sale.paymentMethod}): ${formatRupiah(sale.cashReceived)}
Kembali: ${formatRupiah(sale.changeDue)}
--------------------------------
${storeProfile.receiptFooter}
`;
    const encoded = encodeURIComponent(receiptText);
    window.location.href = `intent:${encoded}#Intent;scheme=rawbt;package=${hardwareSettings.rawbtPackage};end;`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto no-print">
      <div className="bg-white border border-slate-300 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="font-black text-slate-900 text-base">Struk Transaksi Kasir</h3>
              <p className="text-xs text-blue-700 font-mono font-bold">{sale.invoiceNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-200 transition cursor-pointer font-bold"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Paper switch */}
        <div className="flex items-center justify-between px-5 py-2.5 bg-slate-100 border-b border-slate-200 text-xs">
          <span className="text-slate-700 font-bold">Format Printer Thermal:</span>
          <div className="flex gap-1.5">
            <button
              onClick={() => setPaperWidth('58')}
              className={`px-3 py-1 rounded-lg font-black transition cursor-pointer ${
                paperWidth === '58'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              58 mm
            </button>
            <button
              onClick={() => setPaperWidth('80')}
              className={`px-3 py-1 rounded-lg font-black transition cursor-pointer ${
                paperWidth === '80'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              80 mm
            </button>
          </div>
        </div>

        {/* Receipt Visual Simulator */}
        <div className="flex-1 overflow-y-auto p-4 flex justify-center bg-slate-200/70">
          <div
            id="thermal-receipt-print-area"
            className={`bg-white text-slate-900 rounded-xl p-4 shadow-md font-mono text-[11px] leading-relaxed transition-all border border-slate-300 ${
              paperWidth === '58' ? 'w-[280px]' : 'w-[360px]'
            }`}
          >
            {/* Header */}
            <div className="text-center pb-2 border-b border-dashed border-slate-400">
              <h4 className="font-black text-sm tracking-wide text-black uppercase">{storeProfile.name}</h4>
              <p className="text-[10px] text-slate-600">{storeProfile.address}</p>
              <p className="text-[10px] text-slate-600">Telp: {storeProfile.phone}</p>
            </div>

            {/* Meta */}
            <div className="py-2 border-b border-dashed border-slate-400 text-[10px] space-y-0.5">
              <div className="flex justify-between">
                <span>No. Struk:</span>
                <span className="font-bold">{sale.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Tanggal:</span>
                <span>{formatDateTime(sale.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span>Kasir:</span>
                <span>{sale.cashierName}</span>
              </div>
              {sale.customerName && (
                <div className="flex justify-between text-blue-700 font-bold">
                  <span>Pelanggan/Member:</span>
                  <span>{sale.customerName}</span>
                </div>
              )}
            </div>

            {/* Items */}
            <div className="py-2 border-b border-dashed border-slate-400 space-y-1.5">
              {sale.items.map((item, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="font-bold text-slate-900 truncate">{item.name}</div>
                  <div className="flex justify-between text-slate-700 text-[10px]">
                    <span>
                      {item.quantity} {item.unit} x {formatRupiah(item.sellingPrice)}
                    </span>
                    <span className="font-black text-black">{formatRupiah(item.subtotal)}</span>
                  </div>
                  {item.discountValue > 0 && (
                    <div className="text-[9px] text-red-600 flex justify-between italic font-bold">
                      <span>Hemat ({item.discountType === 'PERCENT' ? `${item.discountValue}%` : 'Potongan'}):</span>
                      <span>- {formatRupiah(item.discountValue)}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="py-2 border-b border-dashed border-slate-400 space-y-0.5 text-[11px]">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-bold">{formatRupiah(sale.subtotal)}</span>
              </div>
              {sale.transactionDiscount > 0 && (
                <div className="flex justify-between text-red-600 font-bold">
                  <span>Diskon:</span>
                  <span>- {formatRupiah(sale.transactionDiscount)}</span>
                </div>
              )}
              {Boolean(sale.pointsRedeemed && sale.pointsRedeemed > 0) && (
                <div className="flex justify-between text-purple-700 font-bold">
                  <span>Tukar Poin ({sale.pointsRedeemed} Pts):</span>
                  <span>- {formatRupiah(sale.pointsDiscountAmount || 0)}</span>
                </div>
              )}
              <div className="flex justify-between text-xs font-black pt-1 border-t border-slate-300 text-black">
                <span>{Boolean(sale.pointsDiscountAmount && sale.pointsDiscountAmount > 0) ? 'SISA KEKURANGAN BAYAR:' : 'TOTAL AKHIR:'}</span>
                <span>{formatRupiah(sale.totalAmount)}</span>
              </div>
              {Boolean(sale.pointsEarned && sale.pointsEarned > 0) && (
                <div className="flex justify-between text-emerald-700 font-bold text-[10px] bg-emerald-50 px-1 py-0.5 rounded">
                  <span>Poin Diperoleh Transaksi Ini:</span>
                  <span>+{sale.pointsEarned} Pts</span>
                </div>
              )}
              <div className="flex justify-between pt-1">
                <span>Metode Pembayaran:</span>
                <span className="font-bold uppercase">{sale.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span>Jumlah Bayar:</span>
                <span className="font-bold">{formatRupiah(sale.cashReceived)}</span>
              </div>
              <div className="flex justify-between font-black text-blue-700">
                <span>Kembalian:</span>
                <span>{formatRupiah(sale.changeDue)}</span>
              </div>
            </div>

            {/* Barcode Footer & Greeting */}
            <div className="pt-3 text-center space-y-2">
              <div
                className="w-44 mx-auto"
                dangerouslySetInnerHTML={{ __html: generateBarcodeSvg(sale.invoiceNumber, 180, 50) }}
              />
              <p className="text-[9px] text-slate-600 italic px-2">{storeProfile.receiptFooter}</p>
              <p className="text-[8px] text-slate-400 uppercase tracking-wider font-bold">POS Minimarket Pro Cloud System</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap gap-2 justify-between">
          <button
            onClick={handleRawBTPrint}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
            title="Cetak langsung ke aplikasi RawBT di tablet/HP Android"
          >
            <Smartphone className="w-4 h-4 text-blue-700" />
            <span>RawBT Android</span>
          </button>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
            >
              Tutup
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{printed ? 'Cetak Ulang (Print)' : 'Cetak Struk (F10)'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
