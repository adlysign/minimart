import React, { useState } from 'react';
import { AlertTriangle, Lock, X, Check, Trash2, Receipt, ShoppingCart } from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { formatRupiah } from '../../utils/formatters';

interface VoidModalProps {
  onClose: () => void;
  onSuccess: (msg: string) => void;
}

export const VoidModal: React.FC<VoidModalProps> = ({ onClose, onSuccess }) => {
  const { sales, voidTransaction, cart, removeFromCart } = usePOS();
  const completedSales = sales.filter(s => s.status === 'COMPLETED');

  // Default mode: if cart has items, open Tab 2 (Hapus Item Aktif), else Tab 1 (Void Struk)
  const [activeTab, setActiveTab] = useState<'STRUK' | 'CART'>(cart.length > 0 ? 'CART' : 'STRUK');
  const [selectedInvoice, setSelectedInvoice] = useState(completedSales[0]?.invoiceNumber || '');
  const [reason, setReason] = useState('Pelanggan salah bawa barang / ganti pikiran');
  const [supervisorPin, setSupervisorPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [cartSuccessMsg, setCartSuccessMsg] = useState<string | null>(null);

  const handleVoidInvoice = () => {
    if (!selectedInvoice) {
      setErrorMsg('Pilih nomor transaksi struk yang hendak di-void');
      return;
    }
    if (!supervisorPin) {
      setErrorMsg('Masukkan PIN Supervisor / Owner untuk otorisasi void');
      return;
    }

    const res = voidTransaction(selectedInvoice, reason, supervisorPin);
    if (res.success) {
      onSuccess(res.message);
      onClose();
    } else {
      setErrorMsg(res.message);
    }
  };

  const handleRemoveCartItem = (idOrProductId: string, itemName: string) => {
    removeFromCart(idOrProductId);
    setCartSuccessMsg(`Item "${itemName}" berhasil dibatalkan dan dihapus dari keranjang.`);
    setTimeout(() => {
      setCartSuccessMsg(null);
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-red-100 bg-red-50">
          <div className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="font-black text-slate-900 text-base">Menu Void Kasir [F5]</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-red-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 p-2 bg-slate-100 border-b border-slate-200 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('STRUK')}
            className={`py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'STRUK'
                ? 'bg-white text-slate-900 shadow-xs font-black'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Receipt className="w-3.5 h-3.5 text-red-500" />
            <span>Void Struk Selesai</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('CART')}
            className={`py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'CART'
                ? 'bg-white text-slate-900 shadow-xs font-black'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5 text-amber-500" />
            <span>Hapus Item Aktif ({cart.length})</span>
          </button>
        </div>

        {/* Tab Content: Void Struk Selesai */}
        {activeTab === 'STRUK' && (
          <div className="p-5 space-y-4 bg-white">
            <p className="text-xs text-slate-600 leading-relaxed">
              Membatalkan struk belanja yang <strong>sudah selesai dibayar</strong>. Stok barang akan otomatis dikembalikan ke sistem dan rekonsiliasi kas disesuaikan.
            </p>

            {errorMsg && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold">
                {errorMsg}
              </div>
            )}

            {completedSales.length === 0 ? (
              <div className="py-6 px-4 bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-center space-y-1">
                <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-1" />
                <p className="text-xs font-bold text-slate-700">Belum Ada Transaksi Selesai</p>
                <p className="text-[11px] text-slate-400">
                  Riwayat transaksi yang sudah tuntas dibayar akan muncul di sini jika ada pelanggan yang ingin membatalkan struk belanja.
                </p>
              </div>
            ) : (
              <>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Pilih Nomor Struk / Faktur</label>
                  <select
                    value={selectedInvoice}
                    onChange={e => {
                      setSelectedInvoice(e.target.value);
                      setErrorMsg('');
                    }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    {completedSales.map(s => (
                      <option key={s.id} value={s.invoiceNumber}>
                        {s.invoiceNumber} - {s.customerName || 'Pelanggan Umum'} ({formatRupiah(s.totalAmount)})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Alasan Pembatalan / Void</label>
                  <textarea
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    rows={2}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="Tuliskan alasan pembatalan..."
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 flex items-center justify-between">
                    <span>PIN Otorisasi Supervisor / Owner</span>
                    <span className="text-[10px] text-slate-500 font-medium">Otorisasi Hak Akses Wajib</span>
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      maxLength={6}
                      value={supervisorPin}
                      onChange={e => {
                        setSupervisorPin(e.target.value);
                        setErrorMsg('');
                      }}
                      autoFocus
                      placeholder="Ketik 4-digit PIN..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-900 font-mono tracking-widest font-black focus:outline-none focus:ring-2 focus:ring-red-500"
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* Tab Content: Hapus / Void Item Keranjang */}
        {activeTab === 'CART' && (
          <div className="p-5 space-y-3 bg-white">
            <p className="text-xs text-slate-600 leading-relaxed">
              Pilih salah satu barang yang ingin dibatalkan dan dikeluarkan dari keranjang transaksi saat ini:
            </p>

            {cartSuccessMsg && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2 animate-in fade-in duration-150">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{cartSuccessMsg}</span>
              </div>
            )}

            {cart.length === 0 ? (
              <div className="py-8 px-4 bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-center space-y-1">
                <ShoppingCart className="w-8 h-8 text-slate-300 mx-auto mb-1" />
                <p className="text-xs font-bold text-slate-700">Keranjang Belanja Masih Kosong</p>
                <p className="text-[11px] text-slate-400">
                  Semua item telah dihapus atau keranjang belum diisi produk.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {cart.map(item => (
                  <div
                    key={item.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-2 hover:bg-red-50/50 hover:border-red-200 transition"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-slate-900 truncate">{item.name}</p>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                        {item.quantity} x {formatRupiah(item.sellingPrice)} ={' '}
                        <span className="font-bold text-slate-800">{formatRupiah(item.subtotal)}</span>
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveCartItem(item.productId, item.name)}
                      className="px-2.5 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-xl text-xs font-bold flex items-center gap-1 shrink-0 transition cursor-pointer active:scale-95"
                      title="Batalkan dan hapus item ini"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Hapus</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
          >
            Tutup
          </button>

          {activeTab === 'CART' && (
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
            >
              Selesai ({cart.length} Item Tersisa)
            </button>
          )}

          {activeTab === 'STRUK' && completedSales.length > 0 && (
            <button
              onClick={handleVoidInvoice}
              className="flex items-center gap-1.5 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Konfirmasi Void Struk</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

