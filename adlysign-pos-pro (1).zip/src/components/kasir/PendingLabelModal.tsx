import React, { useState, useEffect, useRef } from 'react';
import { PauseCircle, Tag, AlertCircle, X, Check, ShoppingBag, Sparkles } from 'lucide-react';
import { formatRupiah } from '../../utils/formatters';

interface PendingLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (label: string, notes?: string) => void;
  cartItemsCount: number;
  cartPcsCount: number;
  cartTotal: number;
  customerName?: string;
  sampleItems?: { name: string; quantity: number }[];
}

const PRESET_LABELS = [
  '👜 Ambil Dompet / Uang',
  '🔍 Tambah Barang di Rak',
  '🔴 Pelanggan Baju Merah',
  '🔵 Pelanggan Baju Biru',
  '🚗 Pelanggan Parkir Mobil',
  '🏍️ Pelanggan Parkir Motor',
  '📱 Tunggu Konfirmasi Transfer',
  '🏷️ Belanjaan Pending Kasir 1',
];

export const PendingLabelModal: React.FC<PendingLabelModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  cartItemsCount,
  cartPcsCount,
  cartTotal,
  customerName,
  sampleItems = [],
}) => {
  const [label, setLabel] = useState('');
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setLabel('');
      setNotes('');
      setErrorMessage('');
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanLabel = (label || '').trim();
    if (!cleanLabel) {
      setErrorMessage('Label pengenal wajib diisi! Transaksi tidak dapat dipending tanpa identitas yang jelas.');
      inputRef.current?.focus();
      return;
    }
    onConfirm(cleanLabel, (notes || '').trim());
  };

  const handleSelectPreset = (preset: string) => {
    // Remove leading emoji for clean label if desired, or keep descriptive
    setLabel(preset);
    setErrorMessage('');
    inputRef.current?.focus();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border-2 border-amber-400 overflow-hidden flex flex-col animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/80 flex items-center justify-center border border-amber-300 shadow-xs">
              <PauseCircle className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-950 tracking-tight flex items-center gap-2">
                Beri Label Transaksi Pending
                <span className="text-[10px] bg-slate-950 text-amber-300 font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Wajib Label
                </span>
              </h3>
              <p className="text-xs text-amber-950/80 font-medium">
                Pintasan tombol F4 • Identifikasi antrean transaksi kasir
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-amber-950/70 hover:text-amber-950 hover:bg-amber-400/50 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Ringkasan Belanjaan Singkat */}
        <div className="bg-amber-50/70 px-6 py-3.5 border-b border-amber-200/80 flex items-center justify-between text-xs">
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5 text-slate-700 font-bold">
              <ShoppingBag className="w-4 h-4 text-amber-600" />
              <span>{cartItemsCount} Produk ({cartPcsCount} pcs)</span>
              {customerName && (
                <span className="ml-1 px-2 py-0.2 bg-blue-100 text-blue-800 rounded font-semibold text-[11px]">
                  Member: {customerName}
                </span>
              )}
            </div>
            {sampleItems.length > 0 && (
              <p className="text-[11px] text-slate-500 truncate max-w-xs font-mono">
                {sampleItems.slice(0, 2).map(i => `${i.name} (${i.quantity}x)`).join(', ')}
                {sampleItems.length > 2 ? `, +${sampleItems.length - 2} lainnya` : ''}
              </p>
            )}
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Total Nilai</span>
            <span className="text-base font-black text-red-600 font-mono">
              {formatRupiah(cartTotal)}
            </span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="pending-label-input" className="text-xs font-black text-slate-800 uppercase tracking-wide flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-amber-600" />
                <span>Nama / Label Pengenal Transaksi</span>
                <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-slate-400">
                {label.length}/60 karakter
              </span>
            </div>

            <input
              id="pending-label-input"
              ref={inputRef}
              type="text"
              maxLength={60}
              value={label}
              onChange={e => {
                setLabel(e.target.value);
                if (errorMessage) setErrorMessage('');
              }}
              placeholder="Contoh: Ibu Kerudung Merah - Ambil Dompet di Mobil"
              className={`w-full px-4 py-3 bg-white border-2 rounded-xl text-sm font-bold text-slate-900 focus:outline-none transition ${
                errorMessage
                  ? 'border-red-500 ring-3 ring-red-100'
                  : 'border-amber-400 focus:border-amber-600 focus:ring-4 focus:ring-amber-200'
              }`}
            />

            {errorMessage ? (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1.5 mt-1 animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </p>
            ) : (
              <p className="text-[11px] text-slate-500">
                Wajib diisi dengan ciri fisik pembeli atau alasan pending agar mudah dipanggil kembali.
              </p>
            )}
          </div>

          {/* Quick Preset Chips */}
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              Pilih Cepat Label / Ciri-Ciri:
            </span>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
              {PRESET_LABELS.map(preset => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleSelectPreset(preset)}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition font-medium cursor-pointer ${
                    label === preset
                      ? 'bg-amber-100 border-amber-400 text-amber-900 font-bold'
                      : 'bg-slate-50 hover:bg-amber-50 border-slate-200 text-slate-700 hover:border-amber-300'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Optional Notes */}
          <div className="space-y-1 pt-1">
            <label htmlFor="pending-notes-input" className="text-xs font-bold text-slate-700">
              Catatan Tambahan (Opsional)
            </label>
            <input
              id="pending-notes-input"
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Misal: Sudah titip kantong kresek di meja kasir"
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:border-amber-400 focus:outline-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition cursor-pointer"
            >
              Batal (Esc)
            </button>
            <button
              type="submit"
              disabled={!(label || '').trim()}
              className={`px-6 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition cursor-pointer shadow-md ${
                !(label || '').trim()
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-60 shadow-none'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 active:scale-95'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>Simpan & Pending Transaksi</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
