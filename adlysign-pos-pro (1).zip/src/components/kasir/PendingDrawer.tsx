import React, { useState } from 'react';
import {
  PauseCircle,
  Play,
  Trash2,
  X,
  Clock,
  ShieldAlert,
  KeyRound,
  AlertTriangle,
  CheckCircle2,
  UserCheck,
  Tag,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { formatDateTime, formatRupiah } from '../../utils/formatters';
import { PendingCart } from '../../types/pos';

interface PendingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PendingDrawer: React.FC<PendingDrawerProps> = ({ isOpen, onClose }) => {
  const {
    pendingCarts,
    resumePendingCart,
    removePendingCart,
    currentUser,
    users,
    verifyPin,
    cart: activeCart,
  } = usePOS();

  // State for pending item deletion
  const [selectedPendingToDelete, setSelectedPendingToDelete] = useState<PendingCart | null>(null);
  const [supervisorPin, setSupervisorPin] = useState('');
  const [authError, setAuthError] = useState('');
  const [feedbackToast, setFeedbackToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  // Check if active user already has authorization rights
  const isAuthorizedManager =
    currentUser.role === 'OWNER' ||
    currentUser.role === 'SUPERVISOR' ||
    currentUser.role === 'ADMIN' ||
    Boolean(currentUser.permissions?.canVoid);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setFeedbackToast({ type, message });
    setTimeout(() => {
      setFeedbackToast(null);
    }, 4000);
  };

  const handleInitiateDelete = (cart: PendingCart) => {
    setSelectedPendingToDelete(cart);
    setSupervisorPin('');
    setAuthError('');
  };

  const handleCancelDelete = () => {
    setSelectedPendingToDelete(null);
    setSupervisorPin('');
    setAuthError('');
  };

  const handleConfirmDeleteByAuthorizedUser = () => {
    if (!selectedPendingToDelete) return;
    const deletedName = selectedPendingToDelete.name;
    removePendingCart(selectedPendingToDelete.id);
    setSelectedPendingToDelete(null);
    showToast(`Antrean pending "${deletedName}" berhasil dihapus.`);
  };

  const handleAuthorizeDeleteWithPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPendingToDelete) return;

    const trimmedPin = (supervisorPin || '').trim();
    if (!trimmedPin) {
      setAuthError('Masukkan PIN Supervisor / Owner!');
      return;
    }

    // Check PIN across active users with authorization rights
    const authResult = verifyPin(trimmedPin, 'canVoid');
    // Also accept Owner/Supervisor/Admin roles even if canVoid flag was unset
    const matchingAuthUser = users.find(
      u =>
        u.pin === trimmedPin &&
        u.isActive !== false &&
        (u.role === 'OWNER' || u.role === 'SUPERVISOR' || u.role === 'ADMIN' || u.permissions?.canVoid)
    );

    if (authResult.success || matchingAuthUser) {
      const approver = matchingAuthUser || authResult.user;
      const deletedName = selectedPendingToDelete.name;
      removePendingCart(selectedPendingToDelete.id);
      setSelectedPendingToDelete(null);
      setSupervisorPin('');
      setAuthError('');
      showToast(
        `Antrean pending "${deletedName}" berhasil dihapus setelah disetujui oleh ${approver?.name} (${approver?.role}).`
      );
    } else {
      setAuthError('PIN salah atau pengguna tidak memiliki wewenang Supervisor / Owner!');
      setSupervisorPin('');
    }
  };

  const appendPinDigit = (digit: string) => {
    if (supervisorPin.length < 6) {
      setSupervisorPin(prev => prev + digit);
      setAuthError('');
    }
  };

  const clearPin = () => {
    setSupervisorPin('');
    setAuthError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white border-l border-slate-200 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200 relative">
        {/* Toast Feedback */}
        {feedbackToast && (
          <div className="absolute top-16 left-4 right-4 z-20 bg-slate-900 text-white p-3 rounded-xl shadow-xl flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-top duration-150 border border-slate-700">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="flex-1">{feedbackToast.message}</span>
            <button
              onClick={() => setFeedbackToast(null)}
              className="text-slate-400 hover:text-white p-1"
            >
              ✕
            </button>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-sky-600/30 bg-gradient-to-r from-sky-600 via-sky-700 to-blue-700 text-white shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-white/15 rounded-lg border border-white/20">
              <PauseCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-black text-white text-base leading-tight">
                Antrean Transaksi Pending
              </h3>
              <p className="text-[11px] text-sky-100 font-medium">
                Pintasan tombol F4 • {pendingCarts.length} transaksi ditunda
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-100">
          {pendingCarts.length === 0 ? (
            <div className="py-16 text-center text-slate-500 space-y-2.5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
              <div className="w-14 h-14 mx-auto rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-500">
                <PauseCircle className="w-7 h-7" />
              </div>
              <p className="text-sm font-black text-slate-800">Tidak ada transaksi yang dipending</p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Gunakan tombol <kbd className="px-1.5 py-0.5 bg-slate-200 rounded font-bold font-mono">F4</kbd> di kasir saat pembeli ingin mengambil barang tambahan atau dompet.
              </p>
            </div>
          ) : (
            pendingCarts.map(pendingItem => {
              const total = pendingItem.items.reduce((s, i) => s + i.subtotal, 0);
              const totalPcs = pendingItem.items.reduce((s, i) => s + i.quantity, 0);

              return (
                <div
                  key={pendingItem.id}
                  className="bg-white border-2 border-slate-200 hover:border-sky-400 rounded-2xl p-4 space-y-3 transition shadow-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                        <h4 className="font-black text-slate-900 text-sm tracking-tight line-clamp-1">
                          {pendingItem.name}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap text-[11px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-sky-500" />
                          {formatDateTime(pendingItem.createdAt)}
                        </span>
                        {pendingItem.createdByCashier && (
                          <span className="text-slate-400">• Kasir: {pendingItem.createdByCashier}</span>
                        )}
                      </div>

                      {pendingItem.customer && (
                        <span className="inline-block text-[10px] px-2 py-0.5 bg-sky-50 text-sky-700 border border-sky-200 rounded-full font-bold">
                          Member: {pendingItem.customer.name}
                        </span>
                      )}

                      {pendingItem.notes && (
                        <p className="text-[11px] text-sky-900 italic bg-sky-50/70 px-2 py-1 rounded-md border border-sky-100">
                          Catatan: {pendingItem.notes}
                        </p>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-sm font-mono font-black text-sky-700 block">
                        {formatRupiah(total)}
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">
                        {pendingItem.items.length} item ({totalPcs} pcs)
                      </span>
                    </div>
                  </div>

                  {/* Items mini summary */}
                  <div className="text-xs text-slate-700 bg-slate-50 rounded-xl p-2.5 space-y-1 border border-slate-200">
                    {pendingItem.items.slice(0, 3).map((it, idx) => (
                      <div key={idx} className="flex justify-between text-[11px] text-slate-600 font-medium">
                        <span className="truncate max-w-[210px]">{it.name}</span>
                        <span className="font-bold text-slate-800">{it.quantity}x</span>
                      </div>
                    ))}
                    {pendingItem.items.length > 3 && (
                      <div className="text-[10px] text-slate-400 italic pt-0.5">
                        +{pendingItem.items.length - 3} barang lainnya...
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 justify-between items-center pt-1 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => handleInitiateDelete(pendingItem)}
                      className="flex items-center gap-1 px-2.5 py-1.5 text-red-600 hover:bg-red-50 hover:border-red-300 rounded-xl text-xs font-bold transition cursor-pointer border border-transparent"
                      title={
                        isAuthorizedManager
                          ? 'Hapus antrean pending'
                          : 'Hapus antrean pending (Memerlukan Otorisasi Supervisor / Owner)'
                      }
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Hapus</span>
                      {!isAuthorizedManager && (
                        <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.2 rounded font-semibold ml-0.5">
                          PIN
                        </span>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (activeCart.length > 0) {
                          const confirmResume = confirm(
                            `Keranjang kasir saat ini memiliki ${activeCart.length} barang belanjaan.\n\nMelanjutkan antrean "${pendingItem.name}" akan menimpa keranjang saat ini.\n\nKlik OK untuk menimpa dan melanjutkan, atau Batal jika Anda ingin mempending transaksi saat ini terlebih dahulu.`
                          );
                          if (!confirmResume) return;
                        }
                        resumePendingCart(pendingItem.id);
                        onClose();
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-sky-600 to-sky-700 hover:from-sky-700 hover:to-blue-700 text-white text-xs font-black rounded-xl shadow-xs transition cursor-pointer active:scale-95"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Lanjutkan Kasir</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* ========================================================
            MODAL OTORISASI / KONFIRMASI PENGHAPUSAN PENDING
           ======================================================== */}
        {selectedPendingToDelete && (
          <div className="absolute inset-0 z-30 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border-2 border-red-500 overflow-hidden flex flex-col animate-in zoom-in-95 duration-150">
              {/* Header */}
              <div className="p-4 bg-gradient-to-r from-red-600 to-red-700 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-yellow-300" />
                  <h4 className="font-black text-sm">
                    {isAuthorizedManager
                      ? 'Konfirmasi Hapus Antrean'
                      : 'Otorisasi Hapus Antrean Pending'}
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={handleCancelDelete}
                  className="text-white hover:text-slate-200 p-1 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <div className="p-5 space-y-4">
                {/* Security policy explanation */}
                {!isAuthorizedManager ? (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex gap-2.5 items-start text-xs text-red-900">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-black block">Aturan Keamanan Kasir:</span>
                      Kasir tidak diperbolehkan menghapus item pending tanpa persetujuan pemilik hak akses (Supervisor / Owner).
                    </div>
                  </div>
                ) : (
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex gap-2.5 items-start text-xs text-blue-900">
                    <UserCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      Anda masuk sebagai <span className="font-black">{currentUser.name} ({currentUser.role})</span> yang memiliki wewenang untuk menghapus antrean transaksi.
                    </div>
                  </div>
                )}

                {/* Target details */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-1.5 text-xs">
                  <div className="flex justify-between items-start">
                    <span className="text-slate-500">Label Transaksi:</span>
                    <span className="font-black text-slate-900 text-right font-sans">
                      {selectedPendingToDelete.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Jumlah Produk:</span>
                    <span className="font-bold text-slate-800">
                      {selectedPendingToDelete.items.length} item
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Total Belanja:</span>
                    <span className="font-mono font-black text-red-600">
                      {formatRupiah(
                        selectedPendingToDelete.items.reduce((s, i) => s + i.subtotal, 0)
                      )}
                    </span>
                  </div>
                </div>

                {/* PIN Input if NOT Authorized Manager */}
                {!isAuthorizedManager ? (
                  <form onSubmit={handleAuthorizeDeleteWithPin} className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-xs font-black text-slate-800 flex items-center gap-1">
                        <KeyRound className="w-3.5 h-3.5 text-red-600" />
                        <span>Masukkan PIN Supervisor / Owner *</span>
                      </label>
                      <input
                        type="password"
                        autoFocus
                        maxLength={6}
                        value={supervisorPin}
                        onChange={e => {
                          setSupervisorPin(e.target.value);
                          setAuthError('');
                        }}
                        placeholder="••••"
                        className="w-full text-center text-xl tracking-[0.5em] font-mono font-bold py-2.5 bg-slate-50 border-2 border-slate-300 rounded-xl focus:bg-white focus:border-red-500 focus:outline-none"
                      />
                    </div>

                    {authError && (
                      <p className="text-xs font-bold text-red-600 text-center bg-red-50 py-1.5 px-2 rounded-lg border border-red-200">
                        {authError}
                      </p>
                    )}

                    {/* Numeric keypad for touch screens */}
                    <div className="grid grid-cols-3 gap-1.5 pt-1">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0'].map(k => (
                        <button
                          key={k}
                          type="button"
                          onClick={() => (k === 'C' ? clearPin() : appendPinDigit(k))}
                          className={`py-2 text-xs font-bold rounded-lg border transition active:scale-95 cursor-pointer ${
                            k === 'C'
                              ? 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100 col-span-1'
                              : 'bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-200'
                          }`}
                        >
                          {k}
                        </button>
                      ))}
                      <button
                        type="submit"
                        disabled={!(supervisorPin || '').trim()}
                        className="py-2 text-xs font-black rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 transition cursor-pointer active:scale-95 shadow-xs"
                      >
                        Setujui
                      </button>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={handleCancelDelete}
                        className="flex-1 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                      >
                        Batal
                      </button>
                      <button
                        type="submit"
                        disabled={!(supervisorPin || '').trim()}
                        className="flex-1 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                      >
                        Hapus Antrean
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-3 pt-2">
                    <p className="text-xs text-slate-600">
                      Apakah Anda yakin ingin menghapus antrean transaksi ini? Keranjang yang dihapus tidak dapat dipulihkan kembali.
                    </p>
                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={handleCancelDelete}
                        className="flex-1 py-2.5 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                      >
                        Batal
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmDeleteByAuthorizedUser}
                        className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-md active:scale-95"
                      >
                        Ya, Hapus Antrean Ini
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
