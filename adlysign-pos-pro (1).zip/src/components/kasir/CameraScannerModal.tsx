import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, RefreshCw, Zap, CheckCircle2 } from 'lucide-react';
import { usePOS } from '../../context/POSContext';

interface CameraScannerModalProps {
  onClose: () => void;
  onScan: (barcode: string) => void;
}

export const CameraScannerModal: React.FC<CameraScannerModalProps> = ({ onClose, onScan }) => {
  const { products } = usePOS();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [lastScanned, setLastScanned] = useState<string | null>(null);

  useEffect(() => {
    let activeStream: MediaStream | null = null;
    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        activeStream = mediaStream;
        setStream(mediaStream);
        setHasPermission(true);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.warn('Camera access error:', err);
        setHasPermission(false);
      }
    };

    startCamera();

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleSimulateQuickScan = (barcode: string) => {
    setLastScanned(barcode);
    onScan(barcode);
    setTimeout(() => {
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Scan Barcode Kamera HP / Scanner</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video stream viewport */}
        <div className="relative bg-black h-64 flex items-center justify-center overflow-hidden">
          {hasPermission ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="p-6 text-center space-y-2">
              <Camera className="w-12 h-12 text-slate-600 mx-auto animate-pulse" />
              <p className="text-xs text-slate-300">
                Kamera aktif untuk memindai barcode kemasan produk minimarket.
              </p>
              <p className="text-[11px] text-slate-500">
                Posisikan garis merah tepat di atas barcode produk
              </p>
            </div>
          )}

          {/* Laser overlay animation */}
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
            <div className="w-56 h-36 border-2 border-dashed border-emerald-400/80 rounded-2xl relative">
              <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] animate-pulse" />
            </div>
          </div>

          {lastScanned && (
            <div className="absolute bottom-3 bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Barcode Terbaca: {lastScanned}</span>
            </div>
          )}
        </div>

        {/* Quick Click Sample Barcodes for instant testing */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Pilih Barcode Cepat (Simulasi Scanner):
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
            {products.slice(0, 6).map(prod => (
              <button
                key={prod.id}
                onClick={() => handleSimulateQuickScan(prod.barcode)}
                className="flex flex-col text-left p-2 rounded-xl bg-slate-800/80 hover:bg-emerald-950/40 hover:border-emerald-500 border border-slate-700 transition text-xs"
              >
                <span className="font-bold text-slate-100 truncate">{prod.name}</span>
                <span className="text-[10px] font-mono text-emerald-400">{prod.barcode}</span>
              </button>
            ))}
          </div>

          <button
            onClick={onClose}
            className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl transition"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
