import React, { useState } from 'react';
import {
  X,
  Banknote,
  QrCode,
  CreditCard,
  Building2,
  Check,
  RotateCcw,
  Copy,
  CheckCircle2,
  BookOpen,
  Calendar,
  User,
  AlertCircle,
  Sparkles,
  Coins,
} from 'lucide-react';
import { PaymentMethod, SaleTransaction } from '../../types/pos';
import { usePOS } from '../../context/POSContext';
import { formatRupiah, generateQRISSvg } from '../../utils/formatters';

interface PaymentModalProps {
  onClose: () => void;
  onSuccess: (sale: SaleTransaction) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ onClose, onSuccess }) => {
  const {
    cartTotal,
    completeCheckout,
    selectedCustomer,
    storeProfile,
    paymentSettings,
    memberPointSettings,
  } = usePOS();
  const [method, setMethod] = useState<PaymentMethod>('TUNAI');

  // Nominal TIDAK lagi otomatis terisi (dibuat kosong agar kasir mengetik nominal uang yang diterima)
  const [cashInput, setCashInput] = useState<string>('');
  const [bankRefCode, setBankRefCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [zoomQRIS, setZoomQRIS] = useState(false);

  // -------------------------------------------------------------
  // PERHITUNGAN PENUKARAN POIN MEMBER
  // -------------------------------------------------------------
  const pointSettings = memberPointSettings;
  const isPointsEnabled = Boolean(pointSettings?.isEnabled && selectedCustomer);
  const customerPoints = selectedCustomer?.points || 0;
  const pointValueInRupiah = pointSettings?.pointValueInRupiah || 100;
  const minPointsToRedeem = pointSettings?.minPointsToRedeem || 0;

  // Batas maksimal potongan rupiah berdasarkan aturan yang dikonfigurasi owner:
  let maxDiscountAllowedByPolicy = cartTotal;
  if (pointSettings?.redeemMode === 'PERCENT_LIMIT') {
    const pct = pointSettings.maxRedeemPercentage || 50;
    maxDiscountAllowedByPolicy = Math.floor((cartTotal * pct) / 100);
  }

  // Maksimal poin yang dapat ditukarkan (tidak melebihi saldo member & tidak melebihi aturan toko)
  const maxPossibleDiscountRupiah = Math.min(
    customerPoints * pointValueInRupiah,
    maxDiscountAllowedByPolicy
  );
  const maxRedeemablePoints = Math.floor(maxPossibleDiscountRupiah / pointValueInRupiah);
  const canRedeemPoints =
    isPointsEnabled && customerPoints >= minPointsToRedeem && maxRedeemablePoints > 0;

  // State toggle & input penukaran poin
  const [usePoints, setUsePoints] = useState(false);
  const [pointsRedeemedInput, setPointsRedeemedInput] = useState<string>('');

  const handleTogglePoints = (enable: boolean) => {
    setUsePoints(enable);
    if (enable) {
      setPointsRedeemedInput(maxRedeemablePoints.toString());
      const discount = maxRedeemablePoints * pointValueInRupiah;
      const deficiency = Math.max(0, cartTotal - discount);
      // Otomatis hanya membayar kekurangannya saja
      setCashInput(deficiency.toString());
    } else {
      setPointsRedeemedInput('');
      setCashInput('');
    }
  };

  const handlePointsChange = (val: string) => {
    setPointsRedeemedInput(val);
    const parsed = Math.min(maxRedeemablePoints, Math.max(0, parseInt(val, 10) || 0));
    const discount = parsed * pointValueInRupiah;
    const deficiency = Math.max(0, cartTotal - discount);
    // Otomatis hanya membayar kekurangannya saja
    setCashInput(deficiency.toString());
  };

  const handleApplyPresetPoints = (pts: number) => {
    const validPts = Math.min(maxRedeemablePoints, Math.max(0, pts));
    setPointsRedeemedInput(validPts.toString());
    const discount = validPts * pointValueInRupiah;
    const deficiency = Math.max(0, cartTotal - discount);
    // Otomatis hanya membayar kekurangannya saja
    setCashInput(deficiency.toString());
  };

  const parsedPointsRedeemed = usePoints
    ? Math.min(maxRedeemablePoints, Math.max(0, parseInt(pointsRedeemedInput, 10) || 0))
    : 0;

  const pointsDiscountAmount = parsedPointsRedeemed * pointValueInRupiah;
  const netPayable = Math.max(0, cartTotal - pointsDiscountAmount);

  const activeBanks = paymentSettings?.bankAccounts?.filter(b => b.isActive) || [];
  const [selectedBankId, setSelectedBankId] = useState<string>(() => {
    return activeBanks[0]?.id || '';
  });

  const selectedBank = activeBanks.find(b => b.id === selectedBankId || b.bankName === method) || activeBanks[0];

  // State khusus PIUTANG / Kasbon
  const [piutangCustName, setPiutangCustName] = useState<string>(selectedCustomer?.name || '');
  const [piutangCustPhone, setPiutangCustPhone] = useState<string>(selectedCustomer?.phone || '');
  const [piutangDownPayment, setPiutangDownPayment] = useState<string>('');
  const [piutangDueDate, setPiutangDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().slice(0, 10);
  });
  const [piutangNotes, setPiutangNotes] = useState<string>('');

  const parsedCash = parseFloat(cashInput) || 0;
  const changeDue = Math.max(0, parsedCash - netPayable);

  // Validation: jika netPayable === 0, cashInput 0 sudah dianggap cukup (lunas dengan poin)
  const isCashSufficient = method === 'TUNAI' ? (netPayable === 0 ? true : parsedCash >= netPayable) : true;

  const parsedPiutangDP = Math.max(0, parseFloat(piutangDownPayment) || 0);
  const remainingPiutang = Math.max(0, netPayable - parsedPiutangDP);
  const isPiutangValid =
    method === 'PIUTANG'
      ? Boolean(selectedCustomer?.name || piutangCustName.trim()) &&
        parsedPiutangDP <= netPayable &&
        Boolean(piutangDueDate)
      : true;

  const isFormValid = method === 'TUNAI' ? isCashSufficient : method === 'PIUTANG' ? isPiutangValid : true;

  // Quick cash addition denominations in IDR (based on netPayable kekurangan)
  const quickCashOptions = [
    { label: netPayable === 0 ? 'Lunas Poin (Rp 0)' : `Uang Pas (${formatRupiah(netPayable)})`, value: netPayable },
    { label: '+ Rp 5.000', delta: 5000 },
    { label: '+ Rp 10.000', delta: 10000 },
    { label: '+ Rp 20.000', delta: 20000 },
    { label: '+ Rp 50.000', delta: 50000 },
    { label: '+ Rp 100.000', delta: 100000 },
    { label: 'Rp 50.000', value: 50000 },
    { label: 'Rp 100.000', value: 100000 },
  ];

  const handleQuickCash = (val?: number, delta?: number) => {
    if (val !== undefined) {
      setCashInput(val.toString());
    } else if (delta !== undefined) {
      const base = parsedCash > 0 ? parsedCash : netPayable;
      setCashInput((base + delta).toString());
    }
  };

  const handlePay = () => {
    if (method === 'TUNAI' && !isCashSufficient) {
      alert('Nominal uang tunai kurang dari total tagihan!');
      return;
    }

    if (method === 'PIUTANG') {
      const finalCustName = selectedCustomer?.name || piutangCustName.trim();
      if (!finalCustName) {
        alert('Harap masukkan nama pelanggan kasbon!');
        return;
      }
      if (parsedPiutangDP > netPayable) {
        alert('Uang muka (DP) tidak boleh melebihi total tagihan!');
        return;
      }

      const sale = completeCheckout('PIUTANG', parsedPiutangDP, {
        downPayment: parsedPiutangDP,
        dueDate: piutangDueDate,
        bankName: finalCustName,
        approvalCode: piutangNotes || undefined,
        pointsRedeemed: parsedPointsRedeemed,
        pointsDiscountAmount: pointsDiscountAmount,
      });
      onSuccess(sale);
      return;
    }

    const sale = completeCheckout(
      method,
      method === 'TUNAI' ? (netPayable === 0 ? 0 : parsedCash) : netPayable,
      {
        approvalCode: bankRefCode || undefined,
        bankName: ['BCA', 'BRI', 'MANDIRI', 'BNI'].includes(method) ? method : undefined,
        pointsRedeemed: parsedPointsRedeemed,
        pointsDiscountAmount: pointsDiscountAmount,
      }
    );
    onSuccess(sale);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div>
            <h3 className="text-lg font-bold text-white">Pembayaran Kasir</h3>
            <p className="text-xs text-slate-400">
              Pelanggan:{' '}
              <span className="text-emerald-400 font-semibold">
                {selectedCustomer?.name || 'Pelanggan Umum'}
              </span>
              {selectedCustomer && (
                <span className="ml-2 text-slate-400">
                  (Diskon: {selectedCustomer.discountRate}%) •{' '}
                  <span className="text-purple-400 font-bold">{customerPoints} Poin</span>
                </span>
              )}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Total Banner */}
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-950/70 via-slate-900 to-emerald-950/70 border-b border-emerald-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-medium">TOTAL BELANJA:</span>
              {pointsDiscountAmount > 0 ? (
                <span className="text-sm text-slate-400 font-bold line-through font-mono">
                  {formatRupiah(cartTotal)}
                </span>
              ) : (
                <span className="text-sm text-slate-300 font-bold font-mono">
                  {formatRupiah(cartTotal)}
                </span>
              )}
            </div>
            {pointsDiscountAmount > 0 && (
              <div className="text-xs text-purple-400 font-bold flex items-center gap-1.5 mt-0.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Tukar {parsedPointsRedeemed} Poin: -{formatRupiah(pointsDiscountAmount)}</span>
              </div>
            )}
            <span className="text-xs text-emerald-300 font-bold uppercase tracking-wider block mt-0.5">
              {pointsDiscountAmount > 0 ? 'SISA TAGIHAN WAJIB DIBAYAR:' : 'TOTAL TAGIHAN:'}
            </span>
          </div>
          <span className="text-3xl font-extrabold text-emerald-400 font-mono tracking-tight">
            {formatRupiah(netPayable)}
          </span>
        </div>

        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Section Penukaran Poin Member */}
          {selectedCustomer && pointSettings?.isEnabled && (
            <div className="bg-gradient-to-br from-purple-950/40 via-slate-900 to-purple-900/20 border border-purple-800/60 rounded-2xl p-4 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300 shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                      Poin Loyalitas Member
                      <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-mono border border-purple-500/30">
                        {customerPoints} Poin (Senilai {formatRupiah(customerPoints * pointValueInRupiah)})
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      1 Poin = {formatRupiah(pointValueInRupiah)}
                      {pointSettings.redeemMode === 'FULL'
                        ? ' • Bebas dipakai hingga 100% lunas'
                        : ` • Maksimal potongan ${pointSettings.maxRedeemPercentage}% total belanja`}
                    </p>
                  </div>
                </div>

                {/* Switch Tukar Poin */}
                {canRedeemPoints ? (
                  <button
                    type="button"
                    onClick={() => handleTogglePoints(!usePoints)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 shrink-0 ${
                      usePoints
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30 ring-1 ring-purple-400'
                        : 'bg-slate-800 text-purple-300 border border-purple-500/40 hover:bg-slate-750'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>{usePoints ? 'Poin Digunakan' : 'Gunakan Poin'}</span>
                  </button>
                ) : (
                  <span className="text-[10px] font-bold text-amber-400/90 bg-amber-950/40 border border-amber-800/50 px-2.5 py-1 rounded-lg">
                    {customerPoints < minPointsToRedeem
                      ? `Minimal ${minPointsToRedeem} poin untuk tukar`
                      : 'Belum ada poin'}
                  </span>
                )}
              </div>

              {/* Form Input Poin yang Ingin Ditukarkan jika toggle ON */}
              {usePoints && (
                <div className="pt-3 border-t border-purple-800/40 space-y-2 animate-in fade-in">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex-1">
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        Jumlah Poin Ditukar (Maks: {maxRedeemablePoints} Poin):
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min="1"
                          max={maxRedeemablePoints}
                          value={pointsRedeemedInput}
                          onChange={e => handlePointsChange(e.target.value)}
                          className="w-full bg-slate-950 border border-purple-600/60 rounded-xl px-3 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-purple-400"
                          placeholder={`Maks ${maxRedeemablePoints}`}
                        />
                        <span className="absolute right-3 top-2 text-[10px] text-purple-400 font-bold">
                          = -{formatRupiah(pointsDiscountAmount)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 self-end">
                      <button
                        type="button"
                        onClick={() => handleApplyPresetPoints(maxRedeemablePoints)}
                        className="px-2.5 py-1.5 bg-purple-900/60 hover:bg-purple-800 text-purple-200 border border-purple-700/50 rounded-lg text-[10px] font-bold transition cursor-pointer"
                      >
                        Pakai Maks ({maxRedeemablePoints} Pts)
                      </button>
                      {maxRedeemablePoints > 1 && (
                        <button
                          type="button"
                          onClick={() => handleApplyPresetPoints(Math.floor(maxRedeemablePoints / 2))}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-[10px] font-bold transition cursor-pointer"
                        >
                          50% ({Math.floor(maxRedeemablePoints / 2)} Pts)
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleTogglePoints(false)}
                        className="px-2.5 py-1.5 bg-slate-800 hover:bg-red-900/40 text-slate-400 hover:text-red-300 border border-slate-700 rounded-lg text-[10px] font-bold transition cursor-pointer"
                      >
                        Batal
                      </button>
                    </div>
                  </div>

                  <div className="bg-purple-950/60 p-2.5 rounded-xl border border-purple-800/30 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-purple-300 font-medium">
                        Potongan Poin:
                      </span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">
                        - {formatRupiah(pointsDiscountAmount)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-purple-200 font-semibold">
                      <span>Sisa yang Wajib Dibayar:</span>
                      <span className="font-mono font-black text-white text-xs bg-purple-900/80 px-2 py-0.5 rounded-md border border-purple-700/50">
                        {netPayable === 0 ? 'Rp 0 (Lunas)' : formatRupiah(netPayable)}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Payment Method Selector Grid */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Pilih Metode Pembayaran
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <button
                type="button"
                onClick={() => setMethod('TUNAI')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer ${
                  method === 'TUNAI'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 shadow-md ring-1 ring-emerald-500'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Banknote className="w-5 h-5 mb-1" />
                <span className="text-xs font-bold">Tunai (Cash)</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('QRIS')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer ${
                  method === 'QRIS'
                    ? 'bg-red-500/20 border-red-500 text-red-400 shadow-md ring-1 ring-red-500'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <QrCode className="w-5 h-5 mb-1" />
                <span className="text-xs font-bold">QRIS Standar</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('PIUTANG')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer ${
                  method === 'PIUTANG'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-400 shadow-md ring-1 ring-amber-500'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <BookOpen className="w-5 h-5 mb-1 text-amber-400" />
                <span className="text-xs font-bold text-amber-300">Kasbon / Piutang</span>
              </button>

              {/* Transfer Bank Buttons */}
              {activeBanks.length > 0 ? (
                activeBanks.map(bank => {
                  const isSelected =
                    method === bank.bankName ||
                    (method === 'TRANSFER' && selectedBankId === bank.id) ||
                    (selectedBank?.id === bank.id && ['BCA', 'BRI', 'MANDIRI', 'BNI', 'TRANSFER'].includes(method));

                  return (
                    <button
                      key={bank.id}
                      type="button"
                      onClick={() => {
                        setMethod(bank.bankName as PaymentMethod);
                        setSelectedBankId(bank.id);
                      }}
                      className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer ${
                        isSelected
                          ? 'bg-blue-500/20 border-blue-500 text-blue-400 shadow-md ring-1 ring-blue-500'
                          : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <Building2 className="w-5 h-5 mb-1" />
                      <span className="text-xs font-bold truncate max-w-full">TF {bank.bankName}</span>
                    </button>
                  );
                })
              ) : (
                ['BCA', 'BRI', 'MANDIRI', 'BNI'].map(b => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setMethod(b as PaymentMethod)}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer ${
                      method === b
                        ? 'bg-blue-500/20 border-blue-500 text-blue-400 shadow-md ring-1 ring-blue-500'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <Building2 className="w-5 h-5 mb-1" />
                    <span className="text-xs font-bold">Transfer {b}</span>
                  </button>
                ))
              )}

              <button
                type="button"
                onClick={() => setMethod('EDC')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer ${
                  method === 'EDC'
                    ? 'bg-purple-500/20 border-purple-500 text-purple-400 shadow-md ring-1 ring-purple-500'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <CreditCard className="w-5 h-5 mb-1" />
                <span className="text-xs font-bold">Mesin EDC</span>
              </button>
            </div>
          </div>

          {/* ========================================================
              METHOD SPECIFIC CONTENT: TUNAI
             ======================================================== */}
          {method === 'TUNAI' && (
            <div className="space-y-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              {/* Notifikasi Potongan Poin jika aktif */}
              {pointsDiscountAmount > 0 && (
                <div className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                  netPayable === 0
                    ? 'bg-emerald-950/70 border-emerald-700/80 text-emerald-300'
                    : 'bg-purple-950/60 border-purple-800/60 text-purple-200'
                }`}>
                  <div className="flex items-center gap-2">
                    <Coins className="w-4 h-4 text-purple-400 shrink-0" />
                    <div>
                      <span className="font-bold block">
                        {netPayable === 0 ? 'Tagihan Tertutup 100% oleh Poin' : 'Potongan Poin Member Aktif'}
                      </span>
                      <span className="text-[11px] opacity-80">
                        {netPayable === 0
                          ? 'Pembeli tidak perlu membayar uang tunai'
                          : `Tukar ${parsedPointsRedeemed} poin (-${formatRupiah(pointsDiscountAmount)}), hanya bayar kekurangannya`}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-semibold text-slate-400 block">Kekurangan Tagihan:</span>
                    <span className="text-sm font-mono font-black text-emerald-400">
                      {formatRupiah(netPayable)}
                    </span>
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 flex items-center justify-between">
                  <span>Uang Diterima dari Pembeli (Rp)</span>
                  {pointsDiscountAmount > 0 && netPayable > 0 && (
                    <span className="text-[11px] text-purple-300 font-bold">
                      Kekurangan: {formatRupiah(netPayable)}
                    </span>
                  )}
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-lg">
                    Rp
                  </span>
                  <input
                    type="number"
                    value={cashInput}
                    onChange={e => setCashInput(e.target.value)}
                    autoFocus
                    className="w-full bg-slate-900 border-2 border-emerald-500/60 rounded-xl pl-12 pr-4 py-3 text-2xl font-bold font-mono text-white focus:outline-none focus:border-emerald-400"
                    placeholder={netPayable === 0 ? 'Lunas 100% Poin (Rp 0)' : `Ketik nominal (Kekurangan: ${formatRupiah(netPayable)})`}
                  />
                </div>
              </div>

              {/* Quick Cash Buttons */}
              <div className="space-y-1.5">
                <span className="text-[11px] text-slate-400 font-medium">Pilihan Cepat Nominal:</span>
                <div className="grid grid-cols-4 gap-2">
                  {quickCashOptions.map((opt, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleQuickCash(opt.value, opt.delta)}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-medium text-slate-200 transition active:scale-95 cursor-pointer"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Kembalian Banner */}
              <div
                className={`p-4 rounded-xl flex items-center justify-between border ${
                  netPayable === 0
                    ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
                    : changeDue > 0
                    ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
                    : parsedCash === netPayable && parsedCash > 0
                    ? 'bg-blue-950/60 border-blue-800/80 text-blue-300'
                    : 'bg-red-950/60 border-red-800/80 text-red-300'
                }`}
              >
                <div>
                  <span className="text-xs uppercase font-bold tracking-wider block">
                    {netPayable === 0
                      ? (parsedCash > 0 ? 'Uang Kembalian:' : 'Status Pembayaran:')
                      : parsedCash < netPayable
                      ? 'Sisa Kurang Bayar (Kekurangan):'
                      : parsedCash === netPayable
                      ? 'Status Pembayaran:'
                      : 'Uang Kembalian:'}
                  </span>
                  <span className="text-xs opacity-75">
                    {netPayable === 0
                      ? (parsedCash > 0 ? 'Serahkan ke pembeli' : 'Lunas 100% menggunakan poin member')
                      : parsedCash < netPayable
                      ? 'Ketik nominal uang atau klik pilihan cepat di atas'
                      : parsedCash === netPayable
                      ? 'Uang pas diterima sesuai kekurangan tagihan'
                      : 'Serahkan ke pembeli'}
                  </span>
                </div>
                <span className="text-2xl font-black font-mono">
                  {netPayable === 0
                    ? (parsedCash > 0 ? formatRupiah(parsedCash) : 'LUNAS (POIN)')
                    : parsedCash < netPayable
                    ? formatRupiah(netPayable - parsedCash)
                    : parsedCash === netPayable
                    ? 'UANG PAS'
                    : formatRupiah(changeDue)}
                </span>
              </div>
            </div>
          )}

          {/* ========================================================
              METHOD SPECIFIC CONTENT: PIUTANG / KASBON
             ======================================================== */}
          {method === 'PIUTANG' && (
            <div className="space-y-4 bg-slate-950 p-4 rounded-2xl border border-amber-900/60">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-bold bg-amber-950/40 p-2.5 rounded-xl border border-amber-900/50">
                <BookOpen className="w-4 h-4 shrink-0" />
                <span>Transaksi ini akan dicatat sebagai Piutang/Kasbon Pelanggan</span>
              </div>

              {/* Customer Data */}
              {selectedCustomer ? (
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Member:</span>
                    <span className="font-bold text-white">{selectedCustomer.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">No. WhatsApp/HP:</span>
                    <span className="text-slate-200">{selectedCustomer.phone || '-'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Kasbon Saat Ini:</span>
                    <span className="font-mono font-bold text-red-400">
                      {formatRupiah(selectedCustomer.totalDebt || 0)}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">
                      Nama Pelanggan Kasbon <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={piutangCustName}
                      onChange={e => setPiutangCustName(e.target.value)}
                      placeholder="Masukkan nama pelanggan..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">
                      No. WhatsApp / HP (Opsional)
                    </label>
                    <input
                      type="tel"
                      value={piutangCustPhone}
                      onChange={e => setPiutangCustPhone(e.target.value)}
                      placeholder="0812xxxx..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              )}

              {/* Financial Inputs for Piutang */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">
                    Uang Muka / DP Awal (Rp)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">
                      Rp
                    </span>
                    <input
                      type="number"
                      min={0}
                      max={netPayable}
                      step={1000}
                      value={piutangDownPayment}
                      onChange={e => setPiutangDownPayment(e.target.value)}
                      placeholder="0 (jika tanpa DP)"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-sm font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">
                    Tanggal Jatuh Tempo <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={piutangDueDate}
                    onChange={e => setPiutangDueDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Remaining Piutang Balance */}
              <div className="p-3 bg-red-950/40 border border-red-900/60 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs text-red-300 font-bold uppercase block">
                    Sisa Kasbon yang Harus Dibayar:
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {parsedPiutangDP > 0 ? `DP: ${formatRupiah(parsedPiutangDP)}` : 'Tanpa Uang Muka'}
                  </span>
                </div>
                <span className="text-xl font-black font-mono text-red-400">
                  {formatRupiah(remainingPiutang)}
                </span>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">
                  Catatan / Keterangan Kasbon
                </label>
                <input
                  type="text"
                  value={piutangNotes}
                  onChange={e => setPiutangNotes(e.target.value)}
                  placeholder="Misal: Kasbon mingguan, janji bayar saat gajian..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          {/* ========================================================
              METHOD SPECIFIC CONTENT: QRIS
             ======================================================== */}
          {method === 'QRIS' && (
            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 flex flex-col items-center text-center space-y-3">
              <div className="p-3 bg-white rounded-2xl shadow-md flex flex-col items-center relative group">
                {paymentSettings?.qris?.imageUrl ? (
                  <img
                    src={paymentSettings.qris.imageUrl}
                    alt="QRIS Toko"
                    className="w-52 h-52 object-contain rounded-xl border border-slate-200"
                  />
                ) : (
                  <div
                    dangerouslySetInnerHTML={{
                      __html: generateQRISSvg(
                        `00020101021226${storeProfile.phone || '08123456789'}520454115303360540${netPayable}5802ID5910${paymentSettings?.qris?.merchantName || storeProfile.name || 'MINIMARKET'}6007JAKARTA6304`
                      ),
                    }}
                    className="w-48 h-48 flex items-center justify-center"
                  />
                )}

                {paymentSettings?.qris?.imageUrl && (
                  <button
                    type="button"
                    onClick={() => setZoomQRIS(true)}
                    className="absolute inset-0 bg-black/40 text-white rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition text-xs font-bold gap-1 cursor-pointer"
                  >
                    <span>🔍 Perbesar QRIS</span>
                  </button>
                )}
              </div>

              <div className="space-y-1">
                <div className="text-sm font-bold text-white flex items-center justify-center gap-1.5">
                  <span>{paymentSettings?.qris?.merchantName || storeProfile.name}</span>
                  <span className="text-emerald-400 font-mono font-black">
                    {formatRupiah(netPayable)}
                  </span>
                </div>
                {pointsDiscountAmount > 0 && (
                  <p className="text-[11px] text-purple-300 font-medium">
                    (Nominal tagihan setelah potongan poin: -{formatRupiah(pointsDiscountAmount)})
                  </p>
                )}
                {paymentSettings?.qris?.nmid && (
                  <p className="text-[11px] font-mono text-slate-400">
                    NMID: {paymentSettings.qris.nmid}
                  </p>
                )}
                <p className="text-xs text-slate-400">
                  {paymentSettings?.qris?.notes ||
                    'Mendukung BCA, Mandiri, BRI, BNI, GoPay, OVO, DANA, ShopeePay, LinkAja'}
                </p>
              </div>

              <div className="w-full max-w-sm pt-2">
                <label className="text-xs text-slate-400 font-medium mb-1 block text-left">
                  Nomor Referensi RRN / Transaksi QRIS (Opsional)
                </label>
                <input
                  type="text"
                  value={bankRefCode}
                  onChange={e => setBankRefCode(e.target.value)}
                  placeholder="Contoh: RRN-108291823"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>
          )}

          {/* ========================================================
              METHOD SPECIFIC CONTENT: BANK TRANSFER
             ======================================================== */}
          {(['BCA', 'BRI', 'MANDIRI', 'BNI', 'TRANSFER'].includes(method) || activeBanks.some(b => b.bankName === method)) && (
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div>
                  <span className="text-xs text-slate-400 block">
                    Nomor Rekening Tujuan ({selectedBank ? selectedBank.bankName : method}):
                  </span>
                  <span className="text-base font-mono font-bold text-white tracking-wider">
                    {selectedBank ? selectedBank.accountNumber : '8820-1928-331'}
                  </span>
                  <span className="text-xs text-slate-400 block mt-0.5">
                    a/n {selectedBank ? selectedBank.accountHolder : (storeProfile.name || 'Minimarket')}
                    {selectedBank?.notes ? ` • ${selectedBank.notes}` : ''}
                  </span>
                  <span className="text-xs text-emerald-400 font-bold font-mono block mt-1">
                    Nominal Transfer: {formatRupiah(netPayable)}
                    {pointsDiscountAmount > 0 && ' (Kekurangan setelah poin)'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const num = selectedBank ? selectedBank.accountNumber : '88201928331';
                    copyToClipboard(num.replace(/[^0-9]/g, ''));
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-emerald-400 rounded-lg border border-slate-700 flex items-center gap-1 transition cursor-pointer"
                >
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Tersalin' : 'Salin No'}</span>
                </button>
              </div>

              <div>
                <label className="text-xs text-slate-400 font-medium mb-1 block">
                  Nomor Referensi Transfer / 4 Digit Terakhir (Opsional)
                </label>
                <input
                  type="text"
                  value={bankRefCode}
                  onChange={e => setBankRefCode(e.target.value)}
                  placeholder="Contoh: REF-8819 atau nama pengirim"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>
          )}

          {/* ========================================================
              METHOD SPECIFIC CONTENT: EDC
             ======================================================== */}
          {method === 'EDC' && (
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <p className="text-xs text-slate-300">
                Silakan gesek atau masukkan kartu Debit/Kredit pembeli pada mesin EDC kasir senilai{' '}
                <span className="font-bold text-emerald-400">{formatRupiah(netPayable)}</span>.
                {pointsDiscountAmount > 0 && (
                  <span className="text-purple-300 block mt-1">
                    (Potongan poin: -{formatRupiah(pointsDiscountAmount)}, hanya menagih sisa kekurangan)
                  </span>
                )}
              </p>
              <div>
                <label className="text-xs text-slate-400 font-medium mb-1 block">
                  Nomor Approval Code / Trace Number EDC:
                </label>
                <input
                  type="text"
                  value={bankRefCode}
                  onChange={e => setBankRefCode(e.target.value)}
                  placeholder="Contoh: APP-992104"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-5 bg-slate-950 border-t border-slate-800 flex justify-between items-center">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold rounded-xl transition cursor-pointer"
          >
            Batal (Esc)
          </button>

          <button
            type="button"
            onClick={handlePay}
            disabled={!isFormValid}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm shadow-lg transition cursor-pointer ${
              isFormValid
                ? method === 'PIUTANG'
                  ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-amber-500/25 active:scale-98'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/25 active:scale-98'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Check className="w-4 h-4" />
            <span>
              {netPayable === 0
                ? 'Selesaikan Transaksi (Lunas 100% Poin)'
                : method === 'PIUTANG'
                ? 'Simpan & Proses Piutang'
                : 'Selesaikan & Cetak Struk (F9)'}
            </span>
          </button>
        </div>
      </div>

      {/* MODAL ZOOM QRIS PEMBAYARAN */}
      {zoomQRIS && paymentSettings?.qris?.imageUrl && (
        <div
          onClick={() => setZoomQRIS(false)}
          className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 z-60 cursor-pointer animate-in fade-in"
        >
          <div
            onClick={e => e.stopPropagation()}
            className="bg-white p-6 rounded-3xl shadow-2xl max-w-sm w-full flex flex-col items-center text-center space-y-4 border-4 border-yellow-400"
          >
            <div className="flex items-center justify-between w-full border-b pb-2">
              <span className="font-black text-red-600 text-base">QRIS TOKO</span>
              <button
                type="button"
                onClick={() => setZoomQRIS(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 font-black hover:bg-slate-200"
              >
                ✕
              </button>
            </div>
            <h4 className="font-black text-sm uppercase text-slate-900">
              {paymentSettings.qris.merchantName || storeProfile.name}
            </h4>
            <div className="w-64 h-64 border-2 border-slate-200 rounded-2xl p-2 bg-white flex items-center justify-center shadow-inner">
              <img
                src={paymentSettings.qris.imageUrl}
                alt="QRIS Zoom"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="text-emerald-600 font-mono font-black text-lg">
              {formatRupiah(netPayable)}
            </div>
            {pointsDiscountAmount > 0 && (
              <span className="text-xs text-purple-600 font-bold">
                (Kekurangan tagihan setelah poin)
              </span>
            )}
            {paymentSettings.qris.nmid && (
              <p className="text-xs text-slate-500 font-mono">
                NMID: {paymentSettings.qris.nmid}
              </p>
            )}
            <p className="text-[11px] text-slate-600 font-bold">
              {paymentSettings.qris.notes}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
