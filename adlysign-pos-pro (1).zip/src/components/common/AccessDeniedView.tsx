import React, { useState } from 'react';
import { ShieldAlert, ArrowLeft, KeyRound, CheckCircle2 } from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { ActiveModule } from '../layout/HeaderNav';

interface AccessDeniedViewProps {
  moduleName: ActiveModule;
  reason?: string;
  onBackToKasir: () => void;
  onGrantTemporaryAccess?: () => void;
}

export const AccessDeniedView: React.FC<AccessDeniedViewProps> = ({
  moduleName,
  reason,
  onBackToKasir,
  onGrantTemporaryAccess,
}) => {
  const { currentUser, verifyPin } = usePOS();
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [showPinInput, setShowPinInput] = useState(false);

  const isOwnerOnlyModule = moduleName === 'SETTING_PEMBAYARAN' || moduleName === 'LISENSI' || moduleName === 'CLOUD';

  const handleAuthorize = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    const cleanPin = (pin || '').trim();
    // Setting menu strictly requires Owner PIN; other restricted modules require Supervisor or Owner
    const requiredRole = isOwnerOnlyModule ? 'OWNER' : 'SUPERVISOR';
    const res = verifyPin(cleanPin, requiredRole);
    if (res.success && res.user) {
      if (onGrantTemporaryAccess) {
        onGrantTemporaryAccess();
      }
    } else {
      setPinError(res.message || (isOwnerOnlyModule ? 'PIN Owner tidak valid' : 'PIN Supervisor / Owner tidak valid'));
    }
  };

  const getModuleTitle = (mod: ActiveModule) => {
    switch (mod) {
      case 'SETTING_PEMBAYARAN':
        return 'Setting Toko & Sistem';
      case 'STOK':
        return 'Persediaan & Stock Opname [F6]';
      case 'PEMBELIAN':
        return 'Pembelian Barang Supplier (LPB) [F7]';
      case 'LAPORAN':
        return 'Laporan Omzet & Keuangan [F9]';
      case 'HARDWARE':
        return 'Pengaturan Hardware & Printer';
      case 'CLOUD':
        return 'Sinkronisasi Cloud Database';
      case 'LISENSI':
        return 'Lisensi & Profil Toko';
      default:
        return mod;
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center p-4 bg-slate-100">
      <div className="w-full max-w-md bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-8 text-center space-y-5">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-red-100 text-red-600 flex items-center justify-center shadow-inner">
          <ShieldAlert className="w-9 h-9" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 border border-red-200 text-red-700 text-xs font-bold rounded-full">
            <span>Hak Akses Dibatasi</span>
          </div>
          <h2 className="text-xl font-black text-slate-900">
            Akses Modul {getModuleTitle(moduleName)} Ditolak
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            {reason ||
              `Akun kasir aktif (${currentUser.name} - ${currentUser.role}) tidak diberikan wewenang untuk membuka modul ini.`}
          </p>
        </div>

        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-left text-xs space-y-1">
          <div className="flex justify-between text-slate-600">
            <span>Pengguna Aktif:</span>
            <span className="font-bold text-slate-900">{currentUser.name}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Role / Jabatan:</span>
            <span className="font-black text-amber-700 uppercase">{currentUser.role}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Status Wewenang:</span>
            <span className="font-bold text-red-600">Tidak Memiliki Izin</span>
          </div>
        </div>

        {showPinInput ? (
          <form onSubmit={handleAuthorize} className="space-y-3 pt-1 text-left">
            <div>
              <label className="text-xs font-bold text-slate-700 mb-1 block flex items-center gap-1">
                <KeyRound className="w-3.5 h-3.5 text-indigo-600" />
                <span>{isOwnerOnlyModule ? 'Masukkan PIN Owner Toko:' : 'Masukkan PIN Supervisor / Owner:'}</span>
              </label>
              <input
                type="password"
                maxLength={6}
                autoFocus
                value={pin}
                onChange={e => {
                  setPin(e.target.value.replace(/\D/g, ''));
                  setPinError('');
                }}
                placeholder="4-6 Digit PIN"
                className="w-full text-center tracking-widest text-lg font-mono font-black py-2.5 px-3 bg-slate-50 border-2 border-indigo-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              {pinError && <p className="text-xs font-bold text-red-600 mt-1">{pinError}</p>}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowPinInput(false);
                  setPin('');
                  setPinError('');
                }}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl transition flex items-center justify-center gap-1"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Buka Akses</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="flex flex-col gap-2 pt-2">
            <button
              type="button"
              onClick={onBackToKasir}
              className="w-full py-3 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali ke Kasir [F2]</span>
            </button>

            {onGrantTemporaryAccess && (
              <button
                type="button"
                onClick={() => setShowPinInput(true)}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                <span>{isOwnerOnlyModule ? 'Buka dengan Otorisasi Owner Toko' : 'Buka dengan Otorisasi Supervisor'}</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
