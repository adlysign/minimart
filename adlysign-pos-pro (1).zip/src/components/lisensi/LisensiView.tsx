import React, { useState } from 'react';
import {
  Key,
  ShieldCheck,
  Sparkles,
  CheckCircle2,
  Copy,
  Store,
  Save,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';

export const LisensiView: React.FC = () => {
  const {
    license,
    activateLicenseKey,
    storeProfile,
    updateStoreProfile,
  } = usePOS();

  // License activation input
  const [inputKey, setInputKey] = useState('');
  const [activateMsg, setActivateMsg] = useState<{ text: string; success: boolean } | null>(null);

  // License Generator state (for software owner / reseller)
  const [genPlan, setGenPlan] = useState<'LIFETIME' | 'BULANAN'>('LIFETIME');
  const [genStoreName, setGenStoreName] = useState('Minimarket Mitra Sejahtera');
  const [genDevices, setGenDevices] = useState(5);
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Store Profile Form State
  const [storeForm, setStoreForm] = useState({
    name: storeProfile.name,
    address: storeProfile.address,
    phone: storeProfile.phone,
    receiptHeader: storeProfile.receiptHeader || 'Selamat Datang di Minimarket Kami',
    receiptFooter: storeProfile.receiptFooter,
    taxRate: storeProfile.taxRate || 0,
  });
  const [storeSaved, setStoreSaved] = useState(false);

  const handleActivate = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanKey = (inputKey || '').trim();
    if (!cleanKey) return;

    const res = activateLicenseKey(cleanKey);
    setActivateMsg({ text: res.message, success: res.success });
    if (res.success) {
      setInputKey('');
    }
  };

  const handleGenerateLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/license/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storeName: genStoreName,
          plan: genPlan,
          maxDevices: genDevices,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setGeneratedKey(data.licenseKey);
      } else {
        const year = new Date().getFullYear();
        const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
        setGeneratedKey(`POSM-${genPlan}-${year}-${rand}-${genDevices}DEV`);
      }
    } catch (err) {
      // Fallback generator
      const year = new Date().getFullYear();
      const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
      setGeneratedKey(`POSM-${genPlan}-${year}-${rand}-${genDevices}DEV`);
    }
  };

  const handleSaveStore = (e: React.FormEvent) => {
    e.preventDefault();
    updateStoreProfile({
      ...storeProfile,
      name: storeForm.name,
      address: storeForm.address,
      phone: storeForm.phone,
      receiptHeader: storeForm.receiptHeader,
      receiptFooter: storeForm.receiptFooter,
      taxRate: storeForm.taxRate,
    });
    setStoreSaved(true);
    setTimeout(() => setStoreSaved(false), 2000);
  };

  const copyKey = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Key className="w-6 h-6 text-red-600" />
              <span>Sistem Lisensi, Reseller White-Label & Profil Toko</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola status lisensi aplikasi, generator aktivasi untuk dijual kembali ke pembeli lain, dan kustomisasi identitas minimarket pada struk.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* CURRENT ACTIVE LICENSE STATUS */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Status Lisensi Aplikasi Ini</span>
              </h3>
              <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full text-xs font-black">
                {license.status}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-medium">Paket Lisensi:</span>
                  <span className="font-black text-blue-700 font-sans">{license.plan}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-medium">Batas Jumlah Device:</span>
                  <span className="font-bold text-slate-900 font-sans">
                    {license.activeDevicesCount} / {license.maxDevices} Perangkat
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-medium">Kode Serial Aktif:</span>
                  <span className="text-red-600 font-black">{license.licenseKey}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-medium">Masa Berlaku:</span>
                  <span className="text-slate-700 font-sans font-bold">
                    {license.validUntil || 'Seumur Hidup (Lifetime)'}
                  </span>
                </div>
              </div>

              {/* Form aktivasi */}
              <form onSubmit={handleActivate} className="space-y-2 pt-1">
                <label className="text-slate-700 font-bold block">Aktivasi / Ganti Kode Serial Lisensi:</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inputKey}
                    onChange={e => setInputKey(e.target.value)}
                    placeholder="Contoh: POSM-LIFETIME-2026-X89B-10DEV"
                    className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                  >
                    Aktivasi
                  </button>
                </div>
                {activateMsg && (
                  <p
                    className={`text-xs font-bold ${
                      activateMsg.success ? 'text-emerald-700' : 'text-red-600'
                    }`}
                  >
                    {activateMsg.text}
                  </p>
                )}
              </form>
            </div>
          </div>

          {/* GENERATOR KODE LISENSI (UNTUK DIJUAL KE TOKO LAIN) */}
          <div className="bg-white border-2 border-indigo-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-indigo-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>Generator Lisensi (Jual Kembali / Reseller)</span>
              </h3>
              <span className="text-[10px] px-2.5 py-0.5 bg-indigo-100 text-indigo-800 rounded-full font-black border border-indigo-200">
                Software Owner / Reseller
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Anda dapat men-generate kode lisensi resmi untuk dipasarkan dan dijual ke toko atau minimarket lain secara independen.
            </p>

            <form onSubmit={handleGenerateLicense} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-bold mb-1 block">Nama Toko Pembeli Lisensi</label>
                <input
                  type="text"
                  value={genStoreName}
                  onChange={e => setGenStoreName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold mb-1 block">Tipe Paket Lisensi</label>
                  <select
                    value={genPlan}
                    onChange={e => setGenPlan(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold"
                  >
                    <option value="LIFETIME">LIFETIME (Sekali Bayar)</option>
                    <option value="BULANAN">BULANAN (Langganan)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold mb-1 block">Maksimal Device (Kasir)</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={genDevices}
                    onChange={e => setGenDevices(parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                Generate Serial Key Baru
              </button>
            </form>

            {generatedKey && (
              <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl space-y-1 text-xs">
                <span className="text-[10px] text-indigo-900 font-black block uppercase">
                  Kode Serial Baru Siap Dikirim ke Pembeli:
                </span>
                <div className="flex items-center justify-between font-mono font-bold text-slate-900 bg-white p-2.5 rounded-lg border border-indigo-300 shadow-xs">
                  <span className="text-red-600 font-black">{generatedKey}</span>
                  <button
                    type="button"
                    onClick={() => copyKey(generatedKey)}
                    className="p-1 text-slate-500 hover:text-indigo-700 cursor-pointer"
                  >
                    {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* WHITE LABEL STORE PROFILE */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <Store className="w-4 h-4 text-red-600" />
                <span>Pengaturan White-Label Brand Toko & Header Struk</span>
              </h3>
              {storeSaved && (
                <span className="text-xs text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Berhasil Disimpan!</span>
                </span>
              )}
            </div>

            <form onSubmit={handleSaveStore} className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-700 font-bold mb-1 block">Nama Toko Minimarket *</label>
                <input
                  type="text"
                  required
                  value={storeForm.name}
                  onChange={e => setStoreForm({ ...storeForm, name: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold"
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold mb-1 block">Nomor Telepon Toko *</label>
                <input
                  type="text"
                  required
                  value={storeForm.phone}
                  onChange={e => setStoreForm({ ...storeForm, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-slate-700 font-bold mb-1 block">Alamat Lengkap Toko *</label>
                <input
                  type="text"
                  required
                  value={storeForm.address}
                  onChange={e => setStoreForm({ ...storeForm, address: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-slate-700 font-bold mb-1 block">Pesan Footer Struk Belanja</label>
                <input
                  type="text"
                  value={storeForm.receiptFooter}
                  onChange={e => setStoreForm({ ...storeForm, receiptFooter: e.target.value })}
                  placeholder="Terima kasih atas kunjungan Anda • Barang yang dibeli tidak dapat ditukar"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900"
                />
              </div>

              <div className="sm:col-span-2 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Brand Toko</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
