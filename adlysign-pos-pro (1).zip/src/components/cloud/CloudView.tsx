import React, { useState } from 'react';
import {
  Cloud,
  Database,
  Store,
  RefreshCw,
  CheckCircle2,
  Copy,
  Download,
  Upload,
  RotateCcw,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';

export const CloudView: React.FC = () => {
  const {
    storeProfile,
    cloudSyncStatus,
    triggerSync,
    exportDatabaseJson,
    importDatabaseJson,
    resetToSampleData,
  } = usePOS();

  const [copied, setCopied] = useState(false);
  const [branches] = useState([
    { id: 'b1', name: storeProfile.name + ' (Pusat)', address: storeProfile.address, phone: storeProfile.phone, isCurrent: true },
    { id: 'b2', name: 'Cabang 02 - Dago Plaza', address: 'Jl. Ir. H. Juanda No. 88, Bandung', phone: '022-87654321', isCurrent: false },
    { id: 'b3', name: 'Cabang 03 - Buah Batu', address: 'Jl. Buah Batu No. 120, Bandung', phone: '022-98765432', isCurrent: false },
  ]);
  const [selectedBranchId, setSelectedBranchId] = useState('b1');

  const copySqlSchema = () => {
    navigator.clipboard.writeText(
      `-- POS Minimarket Supabase Schema
CREATE TABLE stores (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, address TEXT);
CREATE TABLE products (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, barcode TEXT UNIQUE, sku TEXT, cost_price NUMERIC, selling_price NUMERIC, stock NUMERIC);
CREATE TABLE sales (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), invoice_number TEXT UNIQUE, total_amount NUMERIC, cashier_name TEXT, payment_method TEXT);
`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      const content = evt.target?.result as string;
      const ok = importDatabaseJson(content);
      if (ok) {
        alert('Database JSON berhasil diimpor!');
      } else {
        alert('Gagal mengimpor file JSON.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Cloud className="w-6 h-6 text-red-600" />
              <span>Sinkronisasi Cloud, Multi-Outlet Cabang & Supabase Database</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Arsitektur cloud untuk pengelolaan banyak cabang minimarket (multi-store) dan sinkronisasi offline-first otomatis.
            </p>
          </div>

          <button
            onClick={() => triggerSync()}
            disabled={cloudSyncStatus.isSyncing}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${cloudSyncStatus.isSyncing ? 'animate-spin' : ''}`} />
            <span>{cloudSyncStatus.isSyncing ? 'Sinkronisasi...' : 'Sinkronkan Sekarang'}</span>
          </button>
        </div>

        {/* SYNC STATUS BANNER */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center gap-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-bold block">Status Koneksi Cloud</span>
              <span className="text-sm font-black text-emerald-700">
                {cloudSyncStatus.supabaseConnected ? 'ONLINE (Supabase Terhubung)' : 'OFFLINE MODE (Local Cache)'}
              </span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center gap-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-bold block">Database Engine</span>
              <span className="text-sm font-black text-slate-900">PostgreSQL / Supabase Ready</span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center gap-3 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-bold block">Terakhir Disinkronkan</span>
              <span className="text-sm font-black text-slate-900">
                {cloudSyncStatus.lastSynced ? new Date(cloudSyncStatus.lastSynced).toLocaleTimeString() : 'Baru Saja'}
              </span>
            </div>
          </div>
        </div>

        {/* MULTI-OUTLET CABANG SECTION */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <Store className="w-4 h-4 text-red-600" />
              <span>Pilih Cabang Outlet yang Sedang Dioperasikan</span>
            </h3>
            <span className="text-[10px] text-slate-500 font-bold bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
              Multi-Outlet Mode Aktif
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {branches.map(branch => {
              const isSelected = selectedBranchId === branch.id;
              return (
                <button
                  key={branch.id}
                  onClick={() => setSelectedBranchId(branch.id)}
                  className={`p-4 rounded-2xl text-left border transition cursor-pointer ${
                    isSelected
                      ? 'bg-red-50/60 border-2 border-red-500 text-slate-900 shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-black text-sm text-slate-900">{branch.name}</h4>
                    {isSelected && (
                      <span className="px-2 py-0.5 bg-red-600 text-white rounded text-[10px] font-black">
                        Aktif
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{branch.address}</p>
                  <p className="text-[11px] text-blue-700 font-mono font-bold mt-2">Telp: {branch.phone}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* BACKUP & RESTORE */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-700" />
              <span>Backup, Restore & Reset Data JSON Lokal</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Cadangkan data toko, produk, dan transaksi ke file JSON atau pulihkan data lama kapan saja tanpa koneksi internet.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={exportDatabaseJson}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Export Database JSON</span>
            </button>

            <label className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 cursor-pointer transition">
              <Upload className="w-4 h-4 text-blue-700" />
              <span>Import Database JSON</span>
              <input type="file" accept=".json" onChange={handleImport} className="hidden" />
            </label>

            <button
              onClick={() => {
                if (confirm('Yakin ingin mereset data ke sampel default minimarket?')) {
                  resetToSampleData();
                }
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded-xl border border-red-200 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-red-600" />
              <span>Reset ke Sampel Default Toko</span>
            </button>
          </div>
        </div>

        {/* SUPABASE / POSTGRESQL ARCHITECTURE DETAILS */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-700" />
              <span>Skema Database Supabase / PostgreSQL (/database/schema.sql)</span>
            </h3>
            <button
              onClick={copySqlSchema}
              className="flex items-center gap-1 text-xs text-blue-700 hover:text-blue-900 font-bold cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'Tersalin!' : 'Salin Skema SQL'}</span>
            </button>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Aplikasi telah dirancang dengan skema database PostgreSQL komprehensif yang siap digunakan langsung di akun Supabase Anda. Seluruh entitas toko, produk, persediaan, pembelian, kasir, log aktivitas, dan lisensi tersimpan dengan aman dengan fitur Realtime Replication.
          </p>

          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-300 space-y-1 overflow-x-auto shadow-inner">
            <p className="text-emerald-400 font-bold">-- 11 Tabel Utama di database/schema.sql:</p>
            <p>• stores (Profil toko & multi-outlet)</p>
            <p>• licenses (Sistem lisensi lifetime & bulanan)</p>
            <p>• users (Manajemen kasir, supervisor & PIN login)</p>
            <p>• products (Barcode, SKU, HPP & harga jual)</p>
            <p>• inventory_logs (Audit kartu stok & mutasi)</p>
            <p>• sales & sale_items (Transaksi kasir & rincian struk)</p>
            <p>• purchase_orders (Penerimaan barang distributor)</p>
            <p>• shifts (Closing kasir & rekonsiliasi laci)</p>
          </div>
        </div>
      </div>
    </div>
  );
};
