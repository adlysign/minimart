import React, { useState } from 'react';
import {
  Truck,
  Plus,
  FileText,
  Building2,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { formatDateTime, formatRupiah } from '../../utils/formatters';

export const PembelianView: React.FC = () => {
  const { suppliers, addSupplier, products, purchases, addPurchaseOrder, currentUser } = usePOS();

  const [activeTab, setActiveTab] = useState<'PURCHASES' | 'RECEIVE' | 'SUPPLIERS'>('PURCHASES');

  // Supplier Form State
  const [supplierForm, setSupplierForm] = useState({
    name: '',
    contactPerson: '',
    phone: '',
    address: '',
  });

  // Receiving Goods Form State
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || '');
  const [invoiceNumber, setInvoiceNumber] = useState(`FAK-${Date.now().toString().slice(-6)}`);
  const [purchaseItems, setPurchaseItems] = useState<
    Array<{
      productId: string;
      productName: string;
      quantity: number;
      costPrice: number;
      subtotal: number;
    }>
  >([
    {
      productId: products[0]?.id || '',
      productName: products[0]?.name || '',
      quantity: 10,
      costPrice: products[0]?.costPrice || 2500,
      subtotal: (products[0]?.costPrice || 2500) * 10,
    },
  ]);

  const handleAddItemRow = () => {
    const defaultProd = products[0];
    if (!defaultProd) return;
    setPurchaseItems([
      ...purchaseItems,
      {
        productId: defaultProd.id,
        productName: defaultProd.name,
        quantity: 5,
        costPrice: defaultProd.costPrice,
        subtotal: defaultProd.costPrice * 5,
      },
    ]);
  };

  const handleItemChange = (index: number, field: string, value: any) => {
    const updated = [...purchaseItems];
    const row = { ...updated[index] };

    if (field === 'productId') {
      const prod = products.find(p => p.id === value);
      if (prod) {
        row.productId = prod.id;
        row.productName = prod.name;
        row.costPrice = prod.costPrice;
        row.subtotal = row.quantity * prod.costPrice;
      }
    } else if (field === 'quantity') {
      row.quantity = parseFloat(value) || 0;
      row.subtotal = row.quantity * row.costPrice;
    } else if (field === 'costPrice') {
      row.costPrice = parseFloat(value) || 0;
      row.subtotal = row.quantity * row.costPrice;
    }

    updated[index] = row;
    setPurchaseItems(updated);
  };

  const handleRemoveItemRow = (index: number) => {
    if (purchaseItems.length === 1) {
      alert('Minimal 1 item dalam faktur pembelian');
      return;
    }
    setPurchaseItems(purchaseItems.filter((_, i) => i !== index));
  };

  const totalInvoice = purchaseItems.reduce((sum, item) => sum + item.subtotal, 0);

  const handleReceiveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sup = suppliers.find(s => s.id === selectedSupplierId);
    if (!sup) {
      alert('Pilih supplier terlebih dahulu!');
      return;
    }

    if (purchaseItems.some(i => i.quantity <= 0)) {
      alert('Jumlah kuantitas item harus lebih dari 0');
      return;
    }

    addPurchaseOrder({
      supplierId: sup.id,
      supplierName: sup.name,
      invoiceNumber,
      purchaseDate: new Date().toISOString(),
      receivedBy: currentUser.name,
      paymentStatus: 'LUNAS',
      items: purchaseItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        quantity: item.quantity,
        unitCost: item.costPrice,
        subtotal: item.subtotal,
      })),
      totalAmount: totalInvoice,
    });

    alert(`Faktur pembelian ${invoiceNumber} berhasil disimpan. Stok produk telah otomatis ditambahkan!`);
    setInvoiceNumber(`FAK-${Date.now().toString().slice(-6)}`);
    setActiveTab('PURCHASES');
  };

  const handleAddSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierForm.name) return;
    addSupplier({
      ...supplierForm,
    });
    setSupplierForm({ name: '', contactPerson: '', phone: '', address: '' });
    alert('Supplier baru berhasil ditambahkan');
  };

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Truck className="w-6 h-6 text-red-600" />
              <span>Pembelian & Penerimaan Barang Supplier</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Pencatatan faktur barang masuk (LPB) dari distributor, update HPP modal otomatis, dan buku supplier.
            </p>
          </div>

          {/* Tab Switcher */}
          <div className="flex bg-slate-200 p-1 rounded-xl text-xs font-bold flex-wrap gap-1">
            <button
              onClick={() => setActiveTab('PURCHASES')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'PURCHASES'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Riwayat LPB</span>
            </button>
            <button
              onClick={() => setActiveTab('RECEIVE')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'RECEIVE'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Input Faktur Masuk</span>
            </button>
            <button
              onClick={() => setActiveTab('SUPPLIERS')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'SUPPLIERS'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Data Distributor</span>
            </button>
          </div>
        </div>

        {/* TAB 1: RIWAYAT PEMBELIAN */}
        {activeTab === 'PURCHASES' && (
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto max-h-[550px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 z-10 pos-table-header">
                  <tr>
                    <th className="py-3 px-4">No. Faktur</th>
                    <th className="py-3 px-4">Tanggal Terima</th>
                    <th className="py-3 px-4">Supplier</th>
                    <th className="py-3 px-4">Jumlah Item</th>
                    <th className="py-3 px-4 text-right">Total Nilai Faktur</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {purchases.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-400 font-sans">
                        Belum ada faktur pembelian yang tercatat. Klik "Input Faktur Masuk" untuk mencatat kiriman supplier.
                      </td>
                    </tr>
                  ) : (
                    purchases.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50 transition">
                        <td className="py-3 px-4 font-bold text-blue-700">{p.invoiceNumber}</td>
                        <td className="py-3 px-4 font-sans text-slate-500">{formatDateTime(p.purchaseDate)}</td>
                        <td className="py-3 px-4 font-sans font-bold text-slate-900">{p.supplierName}</td>
                        <td className="py-3 px-4 font-sans text-slate-600">
                          {p.items.length} item ({p.items.reduce((s, i) => s + i.quantity, 0)} pcs)
                        </td>
                        <td className="py-3 px-4 text-right font-black text-red-600">
                          {formatRupiah(p.totalAmount)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {p.paymentStatus || 'LUNAS'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: RECEIVE GOODS FORM */}
        {activeTab === 'RECEIVE' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900">Form Penerimaan Faktur Barang Masuk (LPB)</h3>
                <p className="text-xs text-slate-500">
                  Input kuantitas barang masuk dari faktur distributor. Stok produk akan bertambah otomatis.
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 block">Total Nilai Faktur:</span>
                <span className="text-xl font-mono font-black text-red-600">{formatRupiah(totalInvoice)}</span>
              </div>
            </div>

            <form onSubmit={handleReceiveSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Distributor / Supplier *</label>
                  <select
                    value={selectedSupplierId}
                    onChange={e => setSelectedSupplierId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.contactPerson})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Nomor Faktur / Surat Jalan *</label>
                  <input
                    type="text"
                    required
                    value={invoiceNumber}
                    onChange={e => setInvoiceNumber(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              </div>

              {/* Items Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="pos-table-header">
                    <tr>
                      <th className="py-2.5 px-3">Produk Diterima</th>
                      <th className="py-2.5 px-3 text-center w-28">Kuantitas</th>
                      <th className="py-2.5 px-3 text-right w-36">Harga Beli / HPP</th>
                      <th className="py-2.5 px-3 text-right w-36">Subtotal</th>
                      <th className="py-2.5 px-3 text-center w-12">Hapus</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {purchaseItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2">
                          <select
                            value={item.productId}
                            onChange={e => handleItemChange(idx, 'productId', e.target.value)}
                            className="w-full bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-800"
                          >
                            {products.map(prod => (
                              <option key={prod.id} value={prod.id}>
                                {prod.name} ({prod.barcode})
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2 text-center">
                          <input
                            type="number"
                            min={1}
                            value={item.quantity}
                            onChange={e => handleItemChange(idx, 'quantity', e.target.value)}
                            className="w-20 text-center font-bold font-mono py-1 border border-slate-300 rounded-lg"
                          />
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            min={0}
                            value={item.costPrice}
                            onChange={e => handleItemChange(idx, 'costPrice', e.target.value)}
                            className="w-28 text-right font-bold font-mono py-1 px-2 border border-slate-300 rounded-lg text-slate-800"
                          />
                        </td>
                        <td className="p-2 text-right font-mono font-bold text-slate-900">
                          {formatRupiah(item.subtotal)}
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItemRow(idx)}
                            className="text-red-500 hover:text-red-700 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  type="button"
                  onClick={handleAddItemRow}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold border border-slate-300 transition cursor-pointer"
                >
                  + Tambah Baris Produk
                </button>

                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-xs transition cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simpan Faktur LPB & Tambah Stok</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 3: DATA SUPPLIER */}
        {activeTab === 'SUPPLIERS' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
              <h3 className="text-sm font-black text-slate-900">Tambah Distributor Baru</h3>
              <form onSubmit={handleAddSupplier} className="space-y-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Nama PT / CV Distributor *</label>
                  <input
                    type="text"
                    required
                    value={supplierForm.name}
                    onChange={e => setSupplierForm({ ...supplierForm, name: e.target.value })}
                    placeholder="Contoh: PT Wings Surya Distribusi"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Nama Sales / Kontak Person</label>
                  <input
                    type="text"
                    value={supplierForm.contactPerson}
                    onChange={e => setSupplierForm({ ...supplierForm, contactPerson: e.target.value })}
                    placeholder="Contoh: Budi Santoso"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Nomor Telepon / WhatsApp</label>
                  <input
                    type="text"
                    value={supplierForm.phone}
                    onChange={e => setSupplierForm({ ...supplierForm, phone: e.target.value })}
                    placeholder="08123456789"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Alamat Gudang Distributor</label>
                  <input
                    type="text"
                    value={supplierForm.address}
                    onChange={e => setSupplierForm({ ...supplierForm, address: e.target.value })}
                    placeholder="Jl. Pergudangan Blok A"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
                >
                  Simpan Data Supplier
                </button>
              </form>
            </div>

            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-3.5 border-b border-slate-200 bg-slate-50 font-bold text-xs text-slate-700">
                Daftar Distributor Terdaftar ({suppliers.length})
              </div>
              <div className="divide-y divide-slate-100">
                {suppliers.map(s => (
                  <div key={s.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{s.name}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Kontak: <strong className="text-slate-700">{s.contactPerson}</strong> | Telp: {s.phone || '-'}
                      </p>
                      <p className="text-[11px] text-slate-400">{s.address || '-'}</p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                      Aktif
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
