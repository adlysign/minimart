import React, { useState } from 'react';
import {
  Users,
  Clock,
  Plus,
  LogIn,
  AlertTriangle,
  Receipt,
  X,
  Shield,
  ShieldAlert,
  ShieldCheck,
  KeyRound,
  Pencil,
  Trash2,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Search,
  CheckCircle2,
  Sparkles,
  Phone,
  Sliders,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { User, UserRole } from '../../types/pos';
import { formatDateTime, formatRupiah } from '../../utils/formatters';
import { EditKaryawanModal } from './EditKaryawanModal';
import { ResetPinModal } from './ResetPinModal';
import { PembatasanAksesTab } from './PembatasanAksesTab';

export const KaryawanView: React.FC = () => {
  const {
    users,
    addUser,
    updateUser,
    updateMultipleUsers,
    deleteUser,
    deleteAllStaff,
    currentUser,
    setCurrentUser,
    verifyPin,
    activeShift,
    startShift,
    closeShift,
    shiftHistory,
    pendingCarts,
  } = usePOS();

  type TabType = 'USERS' | 'EDIT_STAFF' | 'PERMISSIONS' | 'SHIFTS' | 'CLOSING';
  const [activeTab, setActiveTab] = useState<TabType>('USERS');

  // Owner Protection Authorization state
  const isCurrentlyOwner = currentUser.role === 'OWNER';
  const [isOwnerUnlocked, setIsOwnerUnlocked] = useState<boolean>(false);
  const isOwnerAccessGranted = isCurrentlyOwner || isOwnerUnlocked;

  // Owner PIN Gate input
  const [ownerPinInput, setOwnerPinInput] = useState('');
  const [ownerPinError, setOwnerPinError] = useState('');

  // Delete All Staff state
  const [showDeleteAllModal, setShowDeleteAllModal] = useState(false);
  const [deleteAllOwnerPin, setDeleteAllOwnerPin] = useState('');
  const [deleteAllError, setDeleteAllError] = useState('');
  const [keepOwnerOption, setKeepOwnerOption] = useState(true);

  // Search & Filter in Edit Staff tab
  const [staffSearch, setStaffSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | UserRole>('ALL');

  // Show/hide plain PIN in Owner table
  const [revealedPins, setRevealedPins] = useState<Record<string, boolean>>({});

  // Modals state
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [resetPinUser, setResetPinUser] = useState<User | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  // Quick Login PIN modal
  const [showLoginPinModal, setShowLoginPinModal] = useState(false);
  const [selectedUserToLogin, setSelectedUserToLogin] = useState<User | null>(null);
  const [loginPinInput, setLoginPinInput] = useState('');
  const [loginPinError, setLoginPinError] = useState('');

  // Add User Form Modal
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    username: '',
    phone: '',
    role: 'KASIR' as UserRole,
    pin: '',
    notes: '',
  });

  // Start Shift Form
  const [startShiftName, setStartShiftName] = useState('Shift 1 (Pagi 07:00 - 15:00)');
  const [startFloatCash, setStartFloatCash] = useState(100000);

  // Close Shift Form
  const [actualCashInDrawer, setActualCashInDrawer] = useState(100000);
  const [closingNotes, setClosingNotes] = useState('');

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 4000);
  };

  // Owner PIN Verification Handler
  const handleVerifyOwnerPin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanOwnerPin = (ownerPinInput || '').trim();
    const ownerAccounts = users.filter(u => u.role === 'OWNER');
    const isOwnerPinMatch = ownerAccounts.some(u => (u.pin || '').trim() === cleanOwnerPin);

    if (isOwnerPinMatch) {
      setIsOwnerUnlocked(true);
      setOwnerPinError('');
      setOwnerPinInput('');
      showNotification('Otorisasi Owner Berhasil. Akses Manajemen & Pembatasan Karyawan Terbuka.');
    } else {
      setOwnerPinError('PIN Owner salah! Masukkan PIN pemilik toko yang sah.');
    }
  };

  // Quick Login as Owner
  const handleDirectSwitchToOwner = () => {
    const ownerAccount = users.find(u => u.role === 'OWNER');
    if (ownerAccount) {
      setSelectedUserToLogin(ownerAccount);
      setLoginPinInput('');
      setLoginPinError('');
      setShowLoginPinModal(true);
    }
  };

  // Open Login Modal
  const handleOpenLoginModal = (user: User) => {
    setSelectedUserToLogin(user);
    setLoginPinInput('');
    setLoginPinError('');
    setShowLoginPinModal(true);
  };

  const handleVerifyLoginPin = () => {
    if (!selectedUserToLogin) return;
    const res = verifyPin(loginPinInput);
    if (res.success && res.user && res.user.id === selectedUserToLogin.id) {
      setCurrentUser(res.user);
      setShowLoginPinModal(false);
      showNotification(`Berhasil login sebagai ${res.user.name} (${res.user.role})`);
    } else {
      setLoginPinError('PIN salah! Silakan coba lagi.');
    }
  };

  // Create User
  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    const nameClean = (newUser.name || '').trim();
    const pinClean = (newUser.pin || '').trim();
    if (!nameClean || !pinClean) return;

    const username =
      (newUser.username || '').trim() || nameClean.toLowerCase().replace(/\s+/g, '');

    const created: User = {
      id: 'usr_' + Date.now(),
      username,
      name: nameClean,
      phone: newUser.phone ? newUser.phone.trim() : undefined,
      role: newUser.role,
      pin: pinClean,
      isActive: true,
      notes: newUser.notes ? newUser.notes.trim() : undefined,
      permissions: {
        canVoid: newUser.role === 'OWNER' || newUser.role === 'SUPERVISOR',
        canDiscount: newUser.role === 'OWNER' || newUser.role === 'SUPERVISOR',
        canEditProduct: newUser.role === 'OWNER' || newUser.role === 'ADMIN',
        canViewProfit: newUser.role === 'OWNER',
        canManageStaff: newUser.role === 'OWNER',
        canAccessReports: newUser.role === 'OWNER' || newUser.role === 'SUPERVISOR',
        canManageLicense: newUser.role === 'OWNER',
        canOpname: newUser.role === 'OWNER' || newUser.role === 'SUPERVISOR',
        canPurchases: newUser.role === 'OWNER' || newUser.role === 'ADMIN',
        canHardware: newUser.role === 'OWNER' || newUser.role === 'SUPERVISOR',
      },
    };

    addUser(created);
    setShowAddUserModal(false);
    setNewUser({ name: '', username: '', phone: '', role: 'KASIR', pin: '', notes: '' });
    showNotification(`Karyawan baru ${created.name} (${created.role}) berhasil didaftarkan!`);
  };

  // Save Edited User
  const handleSaveEditedUser = (updatedUser: User) => {
    updateUser(updatedUser);
    setEditingUser(null);
    showNotification(`Data karyawan ${updatedUser.name} berhasil diperbarui!`);
  };

  // Save Reset PIN
  const handleSaveResetPin = (userId: string, newPin: string) => {
    const target = users.find(u => u.id === userId);
    if (!target) return;
    const updated = { ...target, pin: newPin };
    updateUser(updated);
    setResetPinUser(null);
    showNotification(`PIN baru untuk ${target.name} berhasil disimpan (${newPin})`);
  };

  // Delete User
  const handleConfirmDeleteUser = () => {
    if (!userToDelete) return;
    if (userToDelete.id === 'usr-owner' || userToDelete.role === 'OWNER') {
      alert('Akun Pemilik Toko (Owner) utama tidak dapat dihapus demi keamanan sistem.');
      setUserToDelete(null);
      return;
    }
    if (userToDelete.id === currentUser.id) {
      alert('Anda tidak dapat menghapus akun yang sedang aktif digunakan saat ini.');
      setUserToDelete(null);
      return;
    }

    deleteUser(userToDelete.id);
    showNotification(`Akun karyawan ${userToDelete.name} berhasil dihapus.`);
    setUserToDelete(null);
  };

  // Toggle Reveal PIN
  const toggleRevealPin = (userId: string) => {
    setRevealedPins(prev => ({
      ...prev,
      [userId]: !prev[userId],
    }));
  };

  // Shifts
  const handleStartShiftSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    startShift(startFloatCash, startShiftName);
    showNotification(`Shift ${startShiftName} berhasil dibuka.`);
    setActiveTab('CLOSING');
  };

  const handleCloseShiftSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pendingCarts.length > 0) {
      alert(
        `Tidak bisa closing kasir! Masih ada ${pendingCarts.length} transaksi tertunda (pending item).\nHarap selesaikan atau batalkan seluruh transaksi pending di modul Kasir sebelum melakukan closing shift.`
      );
      return;
    }
    try {
      const closedShift = closeShift(actualCashInDrawer, closingNotes);
      alert(
        `Closing shift kasir berhasil dicatat.\n` +
          `Uang di Laci: ${formatRupiah(actualCashInDrawer)}\n` +
          `Selisih (Variance): ${formatRupiah(closedShift.difference || 0)}`
      );
      showNotification(`Shift kasir ditutup. Selisih: ${formatRupiah(closedShift.difference || 0)}`);
      setActiveTab('SHIFTS');
    } catch (err: any) {
      alert(err?.message || 'Gagal melakukan closing shift');
    }
  };

  const handleConfirmDeleteAll = (e: React.FormEvent) => {
    e.preventDefault();
    setDeleteAllError('');
    const cleanOwnerPin = (deleteAllOwnerPin || '').trim();
    const ownerAccounts = users.filter(u => u.role === 'OWNER');
    const isOwnerPinMatch = ownerAccounts.some(u => (u.pin || '').trim() === cleanOwnerPin);

    if (!isOwnerPinMatch) {
      setDeleteAllError('PIN Owner salah! Masukkan PIN pemilik toko yang sah.');
      return;
    }

    deleteAllStaff(keepOwnerOption);
    setShowDeleteAllModal(false);
    setDeleteAllOwnerPin('');
    showNotification(
      keepOwnerOption
        ? 'Semua akun staf karyawan berhasil dihapus. Akun Owner dipertahankan.'
        : 'Seluruh akun staf kasir & karyawan berhasil direset.'
    );
  };

  // Filtered staff list for Edit tab
  const filteredUsers = users.filter(u => {
    const matchesSearch =
      u.name.toLowerCase().includes(staffSearch.toLowerCase()) ||
      u.username.toLowerCase().includes(staffSearch.toLowerCase()) ||
      (u.phone && u.phone.includes(staffSearch));
    const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-18 right-4 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-yellow-400 flex items-center gap-2.5 text-xs font-bold animate-in slide-in-from-top-3">
          <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
          <span>{toastMessage}</span>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="ml-2 text-slate-400 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header with Title & Navigation Tabs */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Users className="w-6 h-6 text-red-600" />
              <span>Manajemen Karyawan, Hak Akses & Shift</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola data staf toko, batasi wewenang role kasir/SPV, otorisasi PIN, buka shift & rekonsiliasi kas.
            </p>
          </div>

          {/* Main Module Tabs Switcher */}
          <div className="flex bg-slate-200 p-1 rounded-xl text-xs font-bold flex-wrap gap-1">
            <button
              type="button"
              onClick={() => setActiveTab('USERS')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'USERS'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Daftar Karyawan</span>
            </button>

            {/* TAB KHUSUS OWNER: EDIT DATA KARYAWAN */}
            <button
              type="button"
              onClick={() => setActiveTab('EDIT_STAFF')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'EDIT_STAFF'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Edit Karyawan</span>
              <span className="px-1.5 py-0.2 bg-yellow-400 text-slate-950 text-[9px] font-black rounded uppercase">
                Owner
              </span>
            </button>

            {/* TAB KHUSUS OWNER: PEMBATASAN AKSES */}
            <button
              type="button"
              onClick={() => setActiveTab('PERMISSIONS')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'PERMISSIONS'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Pembatasan Akses</span>
              <span className="px-1.5 py-0.2 bg-yellow-400 text-slate-950 text-[9px] font-black rounded uppercase">
                Owner
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('SHIFTS')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'SHIFTS'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Buka Shift</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('CLOSING')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'CLOSING'
                  ? 'bg-red-600 text-white font-black shadow-xs'
                  : 'text-slate-700 hover:text-black'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Closing Kasir</span>
            </button>
          </div>
        </div>

        {/* ACTIVE USER & SHIFT SUMMARY BAR */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 border border-red-200 flex items-center justify-center font-black text-red-600">
              {currentUser.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-slate-900 text-sm">{currentUser.name}</h4>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                    currentUser.role === 'OWNER'
                      ? 'bg-amber-100 text-amber-900 border border-amber-300'
                      : currentUser.role === 'SUPERVISOR'
                      ? 'bg-blue-100 text-blue-800 border border-blue-200'
                      : 'bg-red-100 text-red-700 border border-red-200'
                  }`}
                >
                  {currentUser.role}
                </span>
                {isOwnerAccessGranted && !isCurrentlyOwner && (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded flex items-center gap-1">
                    <Unlock className="w-3 h-3 text-emerald-600" />
                    <span>PIN Owner Aktif</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">Sedang login di komputer kasir ini</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isOwnerUnlocked && !isCurrentlyOwner && (
              <button
                type="button"
                onClick={() => {
                  setIsOwnerUnlocked(false);
                  showNotification('Akses Owner telah dikunci kembali.');
                }}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 flex items-center gap-1.5 transition cursor-pointer"
                title="Kunci kembali wewenang Owner"
              >
                <Lock className="w-3 h-3 text-red-600" />
                <span>Kunci Wewenang Owner</span>
              </button>
            )}

            {activeShift ? (
              <div className="text-right">
                <span className="text-[11px] text-emerald-700 font-bold block uppercase tracking-wider">
                  Shift Berjalan: {activeShift.shiftName}
                </span>
                <span className="text-xs text-slate-700 font-mono font-bold">
                  Modal Awal: {formatRupiah(activeShift.initialCash)}
                </span>
              </div>
            ) : (
              <span className="text-xs text-amber-900 bg-amber-100 px-3 py-1.5 rounded-xl border border-amber-300 font-bold">
                Belum Buka Shift Kasir
              </span>
            )}
          </div>
        </div>

        {/* ======================================================== */}
        {/* TAB 1: DAFTAR KARYAWAN & LOGIN CEPAT */}
        {/* ======================================================== */}
        {activeTab === 'USERS' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <h3 className="text-sm font-black text-slate-900">
                  Daftar Karyawan Toko & Ganti Akun Kasir
                </h3>
                <p className="text-xs text-slate-500">
                  Klik "Login Akun Ini" untuk berganti user kasir dengan PIN cepat.
                </p>
              </div>

              {isOwnerAccessGranted && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDeleteAllError('');
                      setDeleteAllOwnerPin('');
                      setShowDeleteAllModal(true);
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 text-xs font-bold rounded-xl border border-slate-300 hover:border-red-300 transition cursor-pointer shadow-xs"
                    title="Hapus semua data staf kasir & karyawan toko"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    <span>Hapus Semua Karyawan</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowAddUserModal(true)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl transition cursor-pointer shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Tambah Karyawan</span>
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {users.map(u => {
                const isCurrent = currentUser.id === u.id;
                return (
                  <div
                    key={u.id}
                    className={`bg-white border rounded-2xl p-4 space-y-3 transition shadow-xs ${
                      isCurrent
                        ? 'border-red-500 ring-2 ring-red-500/20'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{u.name}</h4>
                        <p className="text-[11px] text-slate-400">@{u.username}</p>
                        {u.phone && <p className="text-[10px] text-slate-500 font-mono mt-0.5">{u.phone}</p>}
                      </div>
                      <span
                        className={`text-[10px] font-black px-2 py-0.5 rounded border uppercase ${
                          u.role === 'OWNER'
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : u.role === 'SUPERVISOR'
                            ? 'bg-blue-100 text-blue-800 border-blue-200'
                            : u.role === 'ADMIN'
                            ? 'bg-purple-100 text-purple-800 border-purple-200'
                            : 'bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {u.role}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-600 space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <div className="flex justify-between">
                        <span>Status PIN:</span>
                        <span className="text-emerald-700 font-mono font-bold">Terdaftar (••••)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Status Kerja:</span>
                        <span
                          className={`font-bold ${
                            u.isActive !== false ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {u.isActive !== false ? 'Aktif' : 'Non-Aktif'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Void / Diskon:</span>
                        <span
                          className={
                            u.permissions?.canVoid || ['OWNER', 'SUPERVISOR'].includes(u.role)
                              ? 'text-emerald-700 font-bold'
                              : 'text-slate-400'
                          }
                        >
                          {u.permissions?.canVoid || ['OWNER', 'SUPERVISOR'].includes(u.role)
                            ? 'Diizinkan'
                            : 'Butuh SPV'}
                        </span>
                      </div>
                    </div>

                    {isCurrent ? (
                      <div className="w-full py-2 bg-emerald-100 text-emerald-800 text-center font-bold text-xs rounded-xl border border-emerald-200">
                        Sedang Aktif
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleOpenLoginModal(u)}
                        className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition border border-slate-300 cursor-pointer active:scale-95"
                      >
                        <LogIn className="w-3.5 h-3.5 text-red-600" />
                        <span>Login Akun Ini</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: EDIT DATA KARYAWAN (KHUSUS AKUN OWNER) */}
        {/* ======================================================== */}
        {activeTab === 'EDIT_STAFF' && (
          <div className="space-y-4">
            {!isOwnerAccessGranted ? (
              /* OWNER SECURITY BARRIER */
              <div className="bg-white border-2 border-yellow-400 rounded-3xl p-6 sm:p-8 max-w-lg mx-auto shadow-xl text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-100 text-amber-800 flex items-center justify-center text-3xl font-black shadow-inner">
                  🔐
                </div>

                <div>
                  <span className="px-3 py-1 bg-yellow-400 text-slate-950 font-black text-[10px] rounded-full uppercase tracking-wider">
                    Akses Khusus Pemilik Toko
                  </span>
                  <h3 className="font-black text-lg text-slate-900 mt-2">
                    Menu Edit Data Karyawan Terproteksi
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Untuk mencegah perubahan data, jabatan, dan manipulasi kasir tanpa izin, menu edit karyawan hanya dapat diakses oleh akun <strong>OWNER</strong>.
                  </p>
                </div>

                <form onSubmit={handleVerifyOwnerPin} className="space-y-3 pt-2">
                  <div>
                    <label className="text-xs text-slate-700 font-bold mb-1 block">
                      Masukkan PIN Pemilik / Owner Toko
                    </label>
                    <input
                      type="password"
                      maxLength={6}
                      autoFocus
                      required
                      value={ownerPinInput}
                      onChange={e => {
                        setOwnerPinInput(e.target.value);
                        setOwnerPinError('');
                      }}
                      placeholder="••••"
                      className="w-full text-center tracking-[0.5em] text-2xl font-mono font-black py-3 bg-slate-50 border-2 border-slate-300 rounded-2xl focus:border-red-500 focus:bg-white focus:outline-none"
                    />
                  </div>

                  {ownerPinError && (
                    <p className="text-xs text-red-600 font-bold">{ownerPinError}</p>
                  )}

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-2xl shadow-xs transition cursor-pointer"
                    >
                      Buka Akses Edit Karyawan
                    </button>
                    <button
                      type="button"
                      onClick={handleDirectSwitchToOwner}
                      className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl border border-slate-300 transition cursor-pointer"
                    >
                      Login Akun Owner
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              /* OWNER STAFF MANAGEMENT DASHBOARD */
              <div className="space-y-4 animate-in fade-in duration-150">
                {/* Statistics Row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[11px] text-slate-500 font-bold block">Total Karyawan</span>
                    <span className="text-xl font-black text-slate-900 font-mono">{users.length}</span>
                    <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">
                      {users.filter(u => u.isActive !== false).length} Aktif Bekerja
                    </span>
                  </div>
                  <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[11px] text-slate-500 font-bold block">Kasir (Crew)</span>
                    <span className="text-xl font-black text-amber-600 font-mono">
                      {users.filter(u => u.role === 'KASIR').length}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Staf Kasir Toko</span>
                  </div>
                  <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[11px] text-slate-500 font-bold block">Supervisor & Admin</span>
                    <span className="text-xl font-black text-blue-600 font-mono">
                      {users.filter(u => ['SUPERVISOR', 'ADMIN'].includes(u.role)).length}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Wewenang Khusus</span>
                  </div>
                  <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
                    <span className="text-[11px] text-slate-500 font-bold block">Pemilik (Owner)</span>
                    <span className="text-xl font-black text-emerald-600 font-mono">
                      {users.filter(u => u.role === 'OWNER').length}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Akses Penuh Toko</span>
                  </div>
                </div>

                {/* Search & Actions Bar */}
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto flex-1">
                    {/* Search */}
                    <div className="relative flex-1 sm:max-w-xs">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={staffSearch}
                        onChange={e => setStaffSearch(e.target.value)}
                        placeholder="Cari nama, username, no telp..."
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
                      />
                    </div>

                    {/* Role Filter */}
                    <select
                      value={roleFilter}
                      onChange={e => setRoleFilter(e.target.value as any)}
                      className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                      <option value="ALL">Semua Jabatan</option>
                      <option value="KASIR">Kasir</option>
                      <option value="SUPERVISOR">Supervisor</option>
                      <option value="ADMIN">Admin</option>
                      <option value="OWNER">Owner</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setDeleteAllError('');
                        setDeleteAllOwnerPin('');
                        setShowDeleteAllModal(true);
                      }}
                      className="px-3.5 py-2 bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 text-xs font-bold rounded-xl border border-slate-300 hover:border-red-300 transition flex items-center gap-1.5 cursor-pointer shrink-0 shadow-xs"
                      title="Hapus semua data staf kasir & karyawan toko"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-600" />
                      <span>Hapus Semua Karyawan</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowAddUserModal(true)}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                      <span>+ Tambah Karyawan Baru</span>
                    </button>
                  </div>
                </div>

                {/* Staff Management Table */}
                <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 text-slate-700 font-black border-b border-slate-200">
                          <th className="py-3 px-4">Nama & Username</th>
                          <th className="py-3 px-3">Kontak / Telepon</th>
                          <th className="py-3 px-3">Jabatan / Role</th>
                          <th className="py-3 px-3 text-center">PIN Login</th>
                          <th className="py-3 px-3 text-center">Status</th>
                          <th className="py-3 px-3 text-center">Hak Akses</th>
                          <th className="py-3 px-4 text-right">Aksi Kelola</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredUsers.map(u => {
                          const isRevealed = Boolean(revealedPins[u.id]);
                          const isOwnerUser = u.role === 'OWNER';
                          const isCurrentActive = u.id === currentUser.id;
                          const activePermsCount = Object.values(u.permissions || {}).filter(Boolean).length;

                          return (
                            <tr key={u.id} className="hover:bg-slate-50/70 transition">
                              {/* Nama & Username */}
                              <td className="py-3 px-4">
                                <div className="flex items-center gap-2.5">
                                  <div className="w-8 h-8 rounded-xl bg-red-100 border border-red-200 text-red-700 font-bold flex items-center justify-center text-xs shrink-0">
                                    {u.name.slice(0, 2).toUpperCase()}
                                  </div>
                                  <div>
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-bold text-slate-900 text-xs">{u.name}</span>
                                      {isCurrentActive && (
                                        <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1 py-0.2 rounded">
                                          Aktif
                                        </span>
                                      )}
                                    </div>
                                    <span className="text-[11px] text-slate-400 block font-mono">
                                      @{u.username}
                                    </span>
                                  </div>
                                </div>
                              </td>

                              {/* Kontak */}
                              <td className="py-3 px-3">
                                {u.phone ? (
                                  <span className="font-mono text-slate-700 font-semibold">{u.phone}</span>
                                ) : (
                                  <span className="text-slate-400 italic text-[11px]">- Belum ada -</span>
                                )}
                              </td>

                              {/* Jabatan */}
                              <td className="py-3 px-3">
                                <span
                                  className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider inline-block border ${
                                    u.role === 'OWNER'
                                      ? 'bg-amber-100 text-amber-950 border-amber-300'
                                      : u.role === 'SUPERVISOR'
                                      ? 'bg-blue-100 text-blue-900 border-blue-300'
                                      : u.role === 'ADMIN'
                                      ? 'bg-purple-100 text-purple-900 border-purple-300'
                                      : 'bg-slate-100 text-slate-800 border-slate-300'
                                  }`}
                                >
                                  {u.role}
                                </span>
                              </td>

                              {/* PIN Login */}
                              <td className="py-3 px-3 text-center">
                                <div className="inline-flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200 font-mono">
                                  <span className="font-bold text-slate-800 text-xs">
                                    {isRevealed ? u.pin : '••••'}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => toggleRevealPin(u.id)}
                                    className="text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                                    title={isRevealed ? 'Sembunyikan PIN' : 'Lihat PIN'}
                                  >
                                    {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                  </button>
                                </div>
                              </td>

                              {/* Status */}
                              <td className="py-3 px-3 text-center">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    u.isActive !== false
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-red-100 text-red-800'
                                  }`}
                                >
                                  {u.isActive !== false ? 'Aktif' : 'Non-Aktif'}
                                </span>
                              </td>

                              {/* Hak Akses Count */}
                              <td className="py-3 px-3 text-center">
                                <span className="text-[11px] font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
                                  {activePermsCount} Izin
                                </span>
                              </td>

                              {/* Aksi Kelola */}
                              <td className="py-3 px-4 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {/* Tombol Edit Data */}
                                  <button
                                    type="button"
                                    onClick={() => setEditingUser(u)}
                                    className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer border border-blue-200"
                                    title="Edit Profil & Jabatan Karyawan"
                                  >
                                    <Pencil className="w-3.5 h-3.5" />
                                    <span>Edit</span>
                                  </button>

                                  {/* Tombol Ganti PIN */}
                                  <button
                                    type="button"
                                    onClick={() => setResetPinUser(u)}
                                    className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-bold transition cursor-pointer border border-amber-200"
                                    title="Ganti / Reset PIN Kasir"
                                  >
                                    <KeyRound className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Tombol Hapus */}
                                  <button
                                    type="button"
                                    disabled={isOwnerUser || isCurrentActive}
                                    onClick={() => setUserToDelete(u)}
                                    className={`p-1.5 rounded-xl text-xs font-bold transition border ${
                                      isOwnerUser || isCurrentActive
                                        ? 'opacity-30 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
                                        : 'bg-red-50 hover:bg-red-100 text-red-600 border-red-200 cursor-pointer'
                                    }`}
                                    title={
                                      isOwnerUser
                                        ? 'Akun Owner tidak dapat dihapus'
                                        : isCurrentActive
                                        ? 'Tidak dapat menghapus akun yang sedang aktif'
                                        : 'Hapus Karyawan'
                                    }
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: PEMBATASAN AKSES KARYAWAN (KHUSUS AKUN OWNER) */}
        {/* ======================================================== */}
        {activeTab === 'PERMISSIONS' && (
          <div>
            {!isOwnerAccessGranted ? (
              /* OWNER SECURITY BARRIER */
              <div className="bg-white border-2 border-yellow-400 rounded-3xl p-6 sm:p-8 max-w-lg mx-auto shadow-xl text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-100 text-amber-800 flex items-center justify-center text-3xl font-black shadow-inner">
                  🛡️
                </div>

                <div>
                  <span className="px-3 py-1 bg-yellow-400 text-slate-950 font-black text-[10px] rounded-full uppercase tracking-wider">
                    Akses Khusus Pemilik Toko
                  </span>
                  <h3 className="font-black text-lg text-slate-900 mt-2">
                    Menu Pembatasan Akses Karyawan Terproteksi
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Pengaturan wewenang void, diskon, pengubahan harga barang, stok opname, dan laporan keuangan toko hanya dapat diatur oleh <strong>OWNER</strong>.
                  </p>
                </div>

                <form onSubmit={handleVerifyOwnerPin} className="space-y-3 pt-2">
                  <div>
                    <label className="text-xs text-slate-700 font-bold mb-1 block">
                      Masukkan PIN Pemilik / Owner Toko
                    </label>
                    <input
                      type="password"
                      maxLength={6}
                      autoFocus
                      required
                      value={ownerPinInput}
                      onChange={e => {
                        setOwnerPinInput(e.target.value);
                        setOwnerPinError('');
                      }}
                      placeholder="••••"
                      className="w-full text-center tracking-[0.5em] text-2xl font-mono font-black py-3 bg-slate-50 border-2 border-slate-300 rounded-2xl focus:border-red-500 focus:bg-white focus:outline-none"
                    />
                  </div>

                  {ownerPinError && (
                    <p className="text-xs text-red-600 font-bold">{ownerPinError}</p>
                  )}

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-2xl shadow-xs transition cursor-pointer"
                    >
                      Buka Pembatasan Akses
                    </button>
                    <button
                      type="button"
                      onClick={handleDirectSwitchToOwner}
                      className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl border border-slate-300 transition cursor-pointer"
                    >
                      Login Akun Owner
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <PembatasanAksesTab
                users={users}
                onUpdateUser={updateUser}
                onUpdateMultipleUsers={updateMultipleUsers}
                onShowNotification={showNotification}
              />
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: SHIFT MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'SHIFTS' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Start Shift Form */}
            <form
              onSubmit={handleStartShiftSubmit}
              className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs"
            >
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-red-600" />
                <span>Buka Shift Kasir Baru</span>
              </h3>

              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Nama Shift</label>
                <select
                  value={startShiftName}
                  onChange={e => setStartShiftName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-semibold text-slate-900"
                >
                  <option value="Shift 1 (Pagi 07:00 - 15:00)">Shift 1 (Pagi 07:00 - 15:00)</option>
                  <option value="Shift 2 (Sore 15:00 - 23:00)">Shift 2 (Sore 15:00 - 23:00)</option>
                  <option value="Shift 3 (Malam 23:00 - 07:00)">Shift 3 (Malam 23:00 - 07:00)</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">
                  Modal Awal Uang Kembalian di Laci (Rp)
                </label>
                <input
                  type="number"
                  min={0}
                  value={startFloatCash}
                  onChange={e => setStartFloatCash(parseFloat(e.target.value) || 0)}
                  className="w-full bg-yellow-50 border-2 border-yellow-400 rounded-xl p-2.5 text-xs font-mono font-black text-slate-900"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Uang pecahan kecil untuk kembalian pembeli awal
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer"
              >
                Mulai Buka Shift Kasir
              </button>
            </form>

            {/* Shift History Table */}
            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-3.5 border-b border-slate-200 bg-slate-50">
                <h3 className="font-black text-xs text-slate-800">
                  Riwayat Shift & Closing Kasir Terakhir
                </h3>
              </div>

              <div className="overflow-x-auto max-h-[450px]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 z-10 pos-table-header">
                    <tr>
                      <th className="py-2.5 px-3">Nama Shift / Kasir</th>
                      <th className="py-2.5 px-3">Waktu Buka</th>
                      <th className="py-2.5 px-3 text-right">Modal Awal</th>
                      <th className="py-2.5 px-3 text-right">Fisik Laci</th>
                      <th className="py-2.5 px-3 text-right">Selisih</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {shiftHistory.map(s => (
                      <tr key={s.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-sans">
                          <span className="font-bold text-slate-900 block">{s.shiftName}</span>
                          <span className="text-[11px] text-slate-500">{s.cashierName}</span>
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-500 text-[11px]">
                          {formatDateTime(s.startTime)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-700 font-bold">
                          {formatRupiah(s.initialCash)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-black text-slate-900">
                          {s.actualDrawerCash !== undefined ? formatRupiah(s.actualDrawerCash) : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {s.difference !== undefined ? (
                            <span
                              className={`font-black ${
                                s.difference === 0
                                  ? 'text-emerald-700'
                                  : s.difference > 0
                                  ? 'text-blue-700'
                                  : 'text-red-600'
                              }`}
                            >
                              {formatRupiah(s.difference)}
                            </span>
                          ) : (
                            '-'
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center font-sans">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              s.status === 'OPEN'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {s.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 5: CLOSING KASIR FORM */}
        {/* ======================================================== */}
        {activeTab === 'CLOSING' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-6 max-w-xl mx-auto shadow-xs space-y-5">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Receipt className="w-5 h-5 text-red-600" />
                <span>Closing Kasir & Rekonsiliasi Uang Laci</span>
              </h3>
              <p className="text-xs text-slate-500">
                Hitung uang fisik di laci kasir saat pergantian shift. Sistem otomatis menghitung selisih dengan penjualan tunai.
              </p>
            </div>

            {!activeShift ? (
              <div className="p-6 text-center text-amber-900 bg-amber-50 border border-amber-200 rounded-2xl space-y-2">
                <AlertTriangle className="w-8 h-8 mx-auto text-amber-600" />
                <p className="font-bold text-sm">Tidak ada shift yang sedang terbuka saat ini.</p>
                <p className="text-xs text-slate-600">
                  Buka shift baru di menu "Buka Shift" sebelum melakukan closing.
                </p>
              </div>
            ) : (
              <form onSubmit={handleCloseShiftSubmit} className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Shift Aktif:</span>
                    <span className="text-slate-900 font-bold">{activeShift.shiftName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Kasir Bertugas:</span>
                    <span className="text-slate-900 font-bold">{activeShift.cashierName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Modal Awal Laci:</span>
                    <span className="text-red-600 font-mono font-black">
                      {formatRupiah(activeShift.initialCash)}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">
                    Jumlah Uang Fisik Hasil Hitungan di Laci (Rp) *
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={actualCashInDrawer}
                    onChange={e => setActualCashInDrawer(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full bg-yellow-50 border-2 border-yellow-400 rounded-xl p-3 text-2xl font-mono font-black text-red-600 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">
                    Catatan / Keterangan Penutup
                  </label>
                  <textarea
                    value={closingNotes}
                    onChange={e => setClosingNotes(e.target.value)}
                    rows={2}
                    placeholder="Contoh: Seluruh uang pecahan Rp 100.000 sudah diserahkan ke brankas owner..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900"
                  />
                </div>

                {pendingCarts.length > 0 && (
                  <div className="p-4 bg-red-50 border-2 border-red-300 rounded-2xl text-red-900 space-y-2">
                    <div className="flex items-center gap-2 font-black text-sm text-red-700">
                      <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
                      <span>Closing Kasir Dikunci (Ada {pendingCarts.length} Transaksi Pending)</span>
                    </div>
                    <p className="text-xs leading-relaxed text-red-700">
                      SOP Kasir: Kasir tidak dapat melakukan closing shift selama masih ada transaksi tertunda (pending item) di sistem.
                      Silakan buka modul <strong>Kasir</strong>, klik <strong>Pending [F6]</strong>, lalu selesaikan pembayaran atau batalkan transaksi tersebut terlebih dahulu.
                    </p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={pendingCarts.length > 0}
                  className={`w-full py-3 font-black text-sm rounded-xl shadow-md transition ${
                    pendingCarts.length > 0
                      ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                      : 'bg-red-600 hover:bg-red-700 text-white cursor-pointer'
                  }`}
                >
                  {pendingCarts.length > 0
                    ? `Tidak Bisa Closing (${pendingCarts.length} Transaksi Pending)`
                    : 'Konfirmasi & Cetak Struk Closing'}
                </button>
              </form>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL: EDIT DATA KARYAWAN */}
        {/* ======================================================== */}
        {editingUser && (
          <EditKaryawanModal
            user={editingUser}
            onClose={() => setEditingUser(null)}
            onSave={handleSaveEditedUser}
          />
        )}

        {/* ======================================================== */}
        {/* MODAL: RESET PIN KARYAWAN */}
        {/* ======================================================== */}
        {resetPinUser && (
          <ResetPinModal
            user={resetPinUser}
            onClose={() => setResetPinUser(null)}
            onSavePin={handleSaveResetPin}
          />
        )}

        {/* ======================================================== */}
        {/* MODAL: KONFIRMASI HAPUS KARYAWAN */}
        {/* ======================================================== */}
        {userToDelete && (
          <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-red-100 text-red-600 flex items-center justify-center">
                <Trash2 className="w-6 h-6" />
              </div>

              <div>
                <h3 className="font-black text-slate-900 text-base">Hapus Akun Karyawan?</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Apakah Anda yakin ingin menghapus akun <strong>{userToDelete.name}</strong> ({userToDelete.role})? Tindakan ini tidak dapat dibatalkan.
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setUserToDelete(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeleteUser}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                >
                  Hapus Akun
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL: TAMBAH KARYAWAN BARU */}
        {/* ======================================================== */}
        {showAddUserModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
              <div className="flex justify-between items-center border-b border-slate-200 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                    <Plus className="w-4 h-4" />
                  </div>
                  <h3 className="font-black text-slate-900 text-sm">Tambah Karyawan Baru</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateUser} className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-700 font-bold mb-1 block">Nama Lengkap *</label>
                  <input
                    type="text"
                    required
                    value={newUser.name}
                    onChange={e => setNewUser({ ...newUser, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold"
                    placeholder="Contoh: Rian Pratama"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-700 font-bold mb-1 block">Username</label>
                    <input
                      type="text"
                      value={newUser.username}
                      onChange={e => setNewUser({ ...newUser, username: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-semibold"
                      placeholder="rian"
                    />
                  </div>
                  <div>
                    <label className="text-slate-700 font-bold mb-1 block">No. HP / WA</label>
                    <input
                      type="tel"
                      value={newUser.phone}
                      onChange={e => setNewUser({ ...newUser, phone: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-semibold"
                      placeholder="0812..."
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-700 font-bold mb-1 block">Jabatan / Role Toko</label>
                  <select
                    value={newUser.role}
                    onChange={e => setNewUser({ ...newUser, role: e.target.value as UserRole })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold"
                  >
                    <option value="KASIR">Kasir (Hanya Transaksi & Struk)</option>
                    <option value="SUPERVISOR">Supervisor (Bisa Void, Diskon, Opname)</option>
                    <option value="ADMIN">Admin (Katalog, Stok, Pembelian)</option>
                    <option value="OWNER">Owner (Akses Penuh Seluruh Toko & Laporan)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold mb-1 block">
                    PIN Login Cepat (4-6 Angka) *
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={newUser.pin}
                    onChange={e => setNewUser({ ...newUser, pin: e.target.value.replace(/\D/g, '') })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-mono font-bold tracking-widest"
                    placeholder="Contoh: 7890"
                  />
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddUserModal(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold border border-slate-300 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl cursor-pointer"
                  >
                    Daftarkan Karyawan
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL: LOGIN PIN CEPAT */}
        {/* ======================================================== */}
        {showLoginPinModal && selectedUserToLogin && (
          <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-sm p-6 shadow-2xl text-center space-y-4">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-red-100 text-red-600 flex items-center justify-center text-xl font-black">
                {selectedUserToLogin.name.slice(0, 2).toUpperCase()}
              </div>

              <div>
                <h3 className="font-black text-base text-slate-900">Login Kasir Toko</h3>
                <p className="text-xs text-slate-500">
                  {selectedUserToLogin.name} ({selectedUserToLogin.role})
                </p>
              </div>

              <div className="space-y-3">
                <input
                  type="password"
                  maxLength={6}
                  autoFocus
                  value={loginPinInput}
                  onChange={e => {
                    setLoginPinInput(e.target.value);
                    setLoginPinError('');
                  }}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleVerifyLoginPin();
                  }}
                  placeholder="Ketik PIN..."
                  className="w-full text-center tracking-[0.5em] text-2xl font-mono font-black py-2.5 bg-slate-100 border border-slate-300 rounded-xl focus:outline-none focus:border-red-500 focus:bg-white"
                />

                {loginPinError && <p className="text-xs text-red-600 font-bold">{loginPinError}</p>}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowLoginPinModal(false)}
                    className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-300 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleVerifyLoginPin}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black cursor-pointer shadow-xs"
                  >
                    Masuk
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        {/* ======================================================== */}
        {/* MODAL: KONFIRMASI HAPUS SEMUA KARYAWAN */}
        {/* ======================================================== */}
        {showDeleteAllModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base">Hapus Semua Karyawan Toko</h3>
                  <p className="text-xs text-slate-500">Tindakan pembersihan massal akun staf & kasir</p>
                </div>
              </div>

              <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-xs text-red-800 space-y-2">
                <div className="font-bold flex items-center gap-1.5 text-red-900">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>Peringatan Tindakan Sensitif</span>
                </div>
                <p>
                  Anda akan menghapus seluruh data karyawan toko (total: <strong>{users.length} akun</strong>).
                  Tindakan ini memerlukan verifikasi PIN Pemilik / Owner.
                </p>
              </div>

              <form onSubmit={handleConfirmDeleteAll} className="space-y-4 pt-1">
                <label className="flex items-start gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition">
                  <input
                    type="checkbox"
                    checked={keepOwnerOption}
                    onChange={e => setKeepOwnerOption(e.target.checked)}
                    className="mt-0.5 rounded text-red-600 focus:ring-red-500 w-4 h-4"
                  />
                  <div className="text-xs">
                    <span className="font-black text-slate-900 block">Pertahankan Akun Owner (Direkomendasikan)</span>
                    <span className="text-slate-500 text-[11px] block mt-0.5">
                      Hanya menghapus akun Kasir, Supervisor, dan Admin. Akun Owner tetap ada agar toko tidak terkunci.
                    </span>
                  </div>
                </label>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">
                    Masukkan PIN Owner untuk Otorisasi <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    autoFocus
                    required
                    value={deleteAllOwnerPin}
                    onChange={e => {
                      setDeleteAllOwnerPin(e.target.value);
                      setDeleteAllError('');
                    }}
                    placeholder="PIN Pemilik Toko..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-mono tracking-widest text-center text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                  {deleteAllError && (
                    <p className="text-xs text-red-600 font-bold mt-1">{deleteAllError}</p>
                  )}
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowDeleteAllModal(false);
                      setDeleteAllOwnerPin('');
                      setDeleteAllError('');
                    }}
                    className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                  >
                    Hapus Semua Karyawan
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
