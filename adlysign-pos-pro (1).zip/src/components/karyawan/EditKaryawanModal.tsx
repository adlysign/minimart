import React, { useState } from 'react';
import {
  X,
  UserCheck,
  Lock,
  Phone,
  FileText,
  Check,
  Shield,
  Eye,
  EyeOff,
  User as UserIcon,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { User, UserRole } from '../../types/pos';
import { usePOS } from '../../context/POSContext';

interface EditKaryawanModalProps {
  user: User;
  onClose: () => void;
  onSave: (updatedUser: User) => void;
}

export const EditKaryawanModal: React.FC<EditKaryawanModalProps> = ({
  user,
  onClose,
  onSave,
}) => {
  const { users } = usePOS();

  // Tabs inside edit modal: 'INFO' | 'PERMISSIONS'
  const [activeTab, setActiveTab] = useState<'INFO' | 'PERMISSIONS'>('INFO');

  // Form State
  const [name, setName] = useState(user.name);
  const [username, setUsername] = useState(user.username);
  const [phone, setPhone] = useState(user.phone || '');
  const [role, setRole] = useState<UserRole>(user.role);
  const [pin, setPin] = useState(user.pin);
  const [showPin, setShowPin] = useState(false);
  const [isActive, setIsActive] = useState(user.isActive ?? true);
  const [notes, setNotes] = useState(user.notes || '');
  const [errorMsg, setErrorMsg] = useState('');
  const [successNotice, setSuccessNotice] = useState('');

  // Permissions state initialized from user or default
  const [permissions, setPermissions] = useState({
    canVoid: user.permissions?.canVoid ?? (user.role === 'OWNER' || user.role === 'SUPERVISOR'),
    canDiscount: user.permissions?.canDiscount ?? (user.role === 'OWNER' || user.role === 'SUPERVISOR'),
    canEditProduct: user.permissions?.canEditProduct ?? (user.role === 'OWNER' || user.role === 'ADMIN'),
    canViewProfit: user.permissions?.canViewProfit ?? (user.role === 'OWNER'),
    canManageStaff: user.permissions?.canManageStaff ?? (user.role === 'OWNER'),
    canAccessReports: user.permissions?.canAccessReports ?? (user.role === 'OWNER' || user.role === 'SUPERVISOR'),
    canManageLicense: user.permissions?.canManageLicense ?? (user.role === 'OWNER'),
    canOpname: user.permissions?.canOpname ?? (user.role === 'OWNER' || user.role === 'SUPERVISOR'),
    canPurchases: user.permissions?.canPurchases ?? (user.role === 'OWNER' || user.role === 'ADMIN'),
    canHardware: user.permissions?.canHardware ?? (user.role === 'OWNER' || user.role === 'SUPERVISOR'),
  });

  // When role changes, optionally apply preset permissions
  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    if (newRole === 'OWNER') {
      setPermissions({
        canVoid: true,
        canDiscount: true,
        canEditProduct: true,
        canViewProfit: true,
        canManageStaff: true,
        canAccessReports: true,
        canManageLicense: true,
        canOpname: true,
        canPurchases: true,
        canHardware: true,
      });
    } else if (newRole === 'SUPERVISOR') {
      setPermissions({
        canVoid: true,
        canDiscount: true,
        canEditProduct: true,
        canViewProfit: false,
        canManageStaff: false,
        canAccessReports: true,
        canManageLicense: false,
        canOpname: true,
        canPurchases: true,
        canHardware: true,
      });
    } else if (newRole === 'ADMIN') {
      setPermissions({
        canVoid: false,
        canDiscount: false,
        canEditProduct: true,
        canViewProfit: false,
        canManageStaff: false,
        canAccessReports: true,
        canManageLicense: false,
        canOpname: true,
        canPurchases: true,
        canHardware: false,
      });
    } else {
      // KASIR standard: cannot void without supervisor approval
      setPermissions({
        canVoid: false,
        canDiscount: false,
        canEditProduct: false,
        canViewProfit: false,
        canManageStaff: false,
        canAccessReports: false,
        canManageLicense: false,
        canOpname: false,
        canPurchases: false,
        canHardware: false,
      });
    }
  };

  const togglePermission = (key: keyof typeof permissions) => {
    setPermissions(prev => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanName = (name || '').trim();
    const cleanPin = (pin || '').trim();

    if (!cleanName) {
      setErrorMsg('Nama lengkap karyawan wajib diisi.');
      return;
    }
    if (!cleanPin || cleanPin.length < 4) {
      setErrorMsg('PIN login kasir minimal 4 digit angka (contoh: 1234 atau 5678).');
      return;
    }

    const cleanUsername = (username || '').trim() || cleanName.toLowerCase().replace(/\s+/g, '');

    // Check username collision with other users
    const isDuplicateUsername = users.some(
      u => u.id !== user.id && (u.username || '').toLowerCase() === cleanUsername.toLowerCase()
    );
    if (isDuplicateUsername) {
      setErrorMsg(`Username "${cleanUsername}" sudah digunakan oleh karyawan lain. Silakan pilih username yang berbeda.`);
      return;
    }

    const updatedUser: User = {
      ...user,
      name: cleanName,
      username: cleanUsername,
      phone: phone?.trim() || undefined,
      role,
      pin: cleanPin,
      isActive,
      notes: notes?.trim() || undefined,
      permissions: {
        ...permissions,
      },
    };

    onSave(updatedUser);
  };

  const permissionList: { key: keyof typeof permissions; label: string; desc: string }[] = [
    {
      key: 'canVoid',
      label: 'Void Struk & Hapus/Kurangi Item',
      desc: 'Wewenang menyetujui pembatalan struk dan pengurangan/penghapusan item belanja kasir',
    },
    {
      key: 'canDiscount',
      label: 'Memberikan Diskon Transaksi & Item',
      desc: 'Wewenang memberikan potongan diskon persen atau nominal di kasir',
    },
    {
      key: 'canEditProduct',
      label: 'Kelola & Edit Master Data Produk',
      desc: 'Wewenang menambah barang baru, mengubah harga jual, dan barcode',
    },
    {
      key: 'canViewProfit',
      label: 'Melihat Laba Bersih & Harga Modal',
      desc: 'Wewenang melihat margin keuntungan, harga pokok (HPP), dan laba kotor',
    },
    {
      key: 'canManageStaff',
      label: 'Kelola Akun & Hak Akses Karyawan',
      desc: 'Wewenang menambah, mengedit, mereset PIN, dan mengatur wewenang staf lain',
    },
    {
      key: 'canAccessReports',
      label: 'Akses Laporan Keuangan & Analitik',
      desc: 'Wewenang membuka rekapitulasi penjualan, laporan laba rugi, dan ekspor data',
    },
    {
      key: 'canOpname',
      label: 'Eksekusi Stok Opname Fisik',
      desc: 'Wewenang melakukan audit dan penyesuaian selisih fisik inventori toko',
    },
    {
      key: 'canPurchases',
      label: 'Faktur Pembelian & Restock Supplier',
      desc: 'Wewenang mencatat pembelian barang masuk dari distributor / supplier',
    },
    {
      key: 'canHardware',
      label: 'Pengaturan Printer Kasir & Hardware',
      desc: 'Wewenang konfigurasi printer bluetooth/USB dan scanner barcode',
    },
    {
      key: 'canManageLicense',
      label: 'Kelola Profil Toko & Lisensi Sistem',
      desc: 'Wewenang mengubah nama minimarket, alamat toko, dan aktivasi lisensi POS',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center font-bold shadow-xs">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base">Edit Data & Akses Karyawan</h3>
              <p className="text-xs text-slate-500 font-mono">
                ID: {user.id} • Peran Saat Ini: <strong className="text-red-600">{user.role}</strong>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100 border-b border-slate-200 text-xs font-bold shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('INFO')}
            className={`py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'INFO'
                ? 'bg-white text-slate-900 shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserIcon className="w-4 h-4 text-red-600" />
            <span>1. Profil & Akun Login</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PERMISSIONS')}
            className={`py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'PERMISSIONS'
                ? 'bg-white text-slate-900 shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Shield className="w-4 h-4 text-blue-600" />
            <span>2. Hak Akses & Wewenang Toko</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* TAB 1: PROFIL & AKUN */}
          {activeTab === 'INFO' && (
            <div className="space-y-4">
              {/* Nama Lengkap & Username */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">
                    Nama Lengkap Karyawan <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => {
                      setName(e.target.value);
                      setErrorMsg('');
                    }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="Contoh: Ayu Kartika"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Username Login Kasir</label>
                  <input
                    type="text"
                    value={username}
                    onChange={e => {
                      setUsername(e.target.value);
                      setErrorMsg('');
                    }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="Contoh: ayukartika"
                  />
                </div>
              </div>

              {/* Jabatan & No Telepon */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">
                    Jabatan / Role Toko <span className="text-red-600">*</span>
                  </label>
                  <select
                    value={role}
                    onChange={e => handleRoleChange(e.target.value as UserRole)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    <option value="KASIR">KASIR (Kasir Depan / Cashier)</option>
                    <option value="SUPERVISOR">SUPERVISOR (Kepala Toko / SPV)</option>
                    <option value="ADMIN">ADMIN (Gudang & Inventori)</option>
                    <option value="OWNER">OWNER (Pemilik Toko)</option>
                  </select>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Mengganti role otomatis menyarankan set hak akses di Tab 2.
                  </span>
                </div>

                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>Nomor WhatsApp / HP</span>
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="Contoh: 081234567890"
                  />
                </div>
              </div>

              {/* PIN Login & Status Aktif */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-yellow-50/70 border border-yellow-200 rounded-2xl">
                <div>
                  <label className="text-xs text-slate-800 font-bold mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-yellow-700" />
                      <span>PIN Login Kasir (4-6 Angka) *</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowPin(!showPin)}
                      className="text-slate-500 hover:text-slate-800 p-0.5"
                      title={showPin ? 'Sembunyikan PIN' : 'Tampilkan PIN'}
                    >
                      {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </label>
                  <input
                    type={showPin ? 'text' : 'password'}
                    maxLength={6}
                    required
                    value={pin}
                    onChange={e => {
                      setPin(e.target.value.replace(/\D/g, ''));
                      setErrorMsg('');
                    }}
                    className="w-full bg-white border border-yellow-300 rounded-xl px-3 py-2 text-sm text-slate-900 font-mono font-black tracking-widest focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    placeholder="Contoh: 1234"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Digunakan untuk login dan otorisasi transaksi kasir</p>
                </div>

                <div>
                  <label className="text-xs text-slate-800 font-bold mb-1 block">Status Akun Karyawan</label>
                  <div className="flex gap-2 mt-1">
                    <button
                      type="button"
                      onClick={() => setIsActive(true)}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        isActive
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span>✓ Aktif Bekerja</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsActive(false)}
                      className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        !isActive
                          ? 'bg-red-600 border-red-600 text-white shadow-xs'
                          : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span>✕ Non-Aktif / Cuti</span>
                    </button>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Akun non-aktif tidak dapat masuk ke dalam sistem POS.
                  </span>
                </div>
              </div>

              {/* Catatan / Keterangan Karyawan */}
              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-slate-400" />
                  <span>Catatan / Keterangan Tambahan (Opsional)</span>
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="Contoh: Petugas kasir shift 1, penanggung jawab kas laci kasir..."
                />
              </div>
            </div>
          )}

          {/* TAB 2: HAK AKSES & WEWENANG DETAIL */}
          {activeTab === 'PERMISSIONS' && (
            <div className="space-y-3">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl flex items-start gap-2.5">
                <Shield className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div className="text-xs text-blue-900 leading-relaxed">
                  <p className="font-bold">Konfigurasi Hak Akses Khusus: {name || user.name}</p>
                  <p className="text-blue-700 text-[11px] mt-0.5">
                    Aktifkan atau nonaktifkan wewenang individual untuk karyawan ini. Pengaturan ini menentukan apakah karyawan dapat mengeksekusi fitur atau membutuhkan otorisasi Supervisor.
                  </p>
                </div>
              </div>

              <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-slate-50/50">
                {permissionList.map(item => {
                  const isChecked = permissions[item.key] ?? false;
                  return (
                    <label
                      key={item.key}
                      className="p-3 flex items-start justify-between gap-3 hover:bg-white transition cursor-pointer"
                    >
                      <div className="space-y-0.5">
                        <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{item.label}</span>
                          {isChecked && (
                            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                              Diizinkan
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500">{item.desc}</p>
                      </div>

                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => togglePermission(item.key)}
                        className="mt-1 w-4 h-4 text-red-600 rounded border-slate-300 focus:ring-red-500 cursor-pointer"
                      />
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* Footer Buttons */}
          <div className="pt-3 flex justify-between gap-2 border-t border-slate-200 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-md transition flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Simpan Perubahan Karyawan</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
