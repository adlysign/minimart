import React, { useState } from 'react';
import { X, Lock, KeyRound, Check } from 'lucide-react';
import { User } from '../../types/pos';

interface ResetPinModalProps {
  user: User;
  onClose: () => void;
  onSavePin: (userId: string, newPin: string) => void;
}

export const ResetPinModal: React.FC<ResetPinModalProps> = ({
  user,
  onClose,
  onSavePin,
}) => {
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPin || newPin.length < 4) {
      setErrorMsg('PIN baru minimal 4 digit angka');
      return;
    }
    if (newPin !== confirmPin) {
      setErrorMsg('Konfirmasi PIN baru tidak cocok');
      return;
    }

    onSavePin(user.id, newPin);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-amber-100 bg-amber-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-sm">Ganti / Reset PIN Kasir</h3>
              <p className="text-[11px] text-slate-500">{user.name} ({user.role})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-amber-100/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200">
            PIN saat ini: <span className="font-mono font-bold text-slate-900">{user.pin}</span>. Gunakan fitur ini jika kasir lupa PIN atau untuk rotasi keamanan berkala.
          </div>

          {errorMsg && (
            <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold">
              {errorMsg}
            </div>
          )}

          <div>
            <label className="text-xs text-slate-700 font-bold mb-1 block">
              Masukkan PIN Baru (4-6 Digit Angka)
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                maxLength={6}
                autoFocus
                required
                value={newPin}
                onChange={e => {
                  setNewPin(e.target.value.replace(/\D/g, ''));
                  setErrorMsg('');
                }}
                placeholder="Contoh: 5678"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2.5 text-sm text-slate-900 font-mono font-black tracking-widest focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-700 font-bold mb-1 block">
              Ketik Ulang PIN Baru untuk Konfirmasi
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                maxLength={6}
                required
                value={confirmPin}
                onChange={e => {
                  setConfirmPin(e.target.value.replace(/\D/g, ''));
                  setErrorMsg('');
                }}
                placeholder="Ketik ulang PIN..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2.5 text-sm text-slate-900 font-mono font-black tracking-widest focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Simpan PIN</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
