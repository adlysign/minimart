import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Users,
  Check,
  RotateCcw,
  Sparkles,
  Info,
  Sliders,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { User, UserRole } from '../../types/pos';

interface PembatasanAksesTabProps {
  users: User[];
  onUpdateUser: (user: User) => void;
  onUpdateMultipleUsers: (updatedUsers: User[]) => void;
  onShowNotification: (msg: string) => void;
}

interface PermissionDef {
  key: keyof User['permissions'];
  label: string;
  category: 'KASIR' | 'PRODUK_STOK' | 'KEUANGAN' | 'SISTEM';
  description: string;
}

const PERMISSION_DEFS: PermissionDef[] = [
  // Transaksi & Kasir
  {
    key: 'canVoid',
    label: 'Void Transaksi & Item [F5]',
    category: 'KASIR',
    description: 'Boleh membatalkan struk penjualan yang sudah selesai dibayar atau membatalkan item belanja.',
  },
  {
    key: 'canDiscount',
    label: 'Diskon Manual Transaksi [F7]',
    category: 'KASIR',
    description: 'Boleh memberikan potongan harga manual (persen atau rupiah) saat melayani pelanggan.',
  },

  // Produk & Stok
  {
    key: 'canEditProduct',
    label: 'Edit Master Produk & Harga Jual',
    category: 'PRODUK_STOK',
    description: 'Boleh menambah produk baru, mengubah barcode, atau menaikkan/menurunkan harga jual.',
  },
  {
    key: 'canOpname',
    label: 'Stok Opname & Koreksi Gudang',
    category: 'PRODUK_STOK',
    description: 'Boleh melakukan penghitungan fisik stok dan melakukan penyesuaian (adjust) stok barang.',
  },
  {
    key: 'canPurchases',
    label: 'Pembelian Barang Supplier (LPB)',
    category: 'PRODUK_STOK',
    description: 'Boleh menerima kiriman distributor dan menginput faktur pembelian barang masuk.',
  },

  // Keuangan & Laporan
  {
    key: 'canAccessReports',
    label: 'Akses Laporan Penjualan & Kasir',
    category: 'KEUANGAN',
    description: 'Boleh membuka menu Laporan untuk melihat omzet, grafik penjualan, dan riwayat shift kasir.',
  },
  {
    key: 'canViewProfit',
    label: 'Lihat Harga Pokok (HPP) & Margin Laba',
    category: 'KEUANGAN',
    description: 'Boleh melihat modal harga beli produk, total laba kotor, dan laba bersih toko.',
  },

  // Sistem & Keamanan
  {
    key: 'canManageStaff',
    label: 'Edit Data Karyawan & Reset PIN',
    category: 'SISTEM',
    description: 'Boleh menambah, mengedit profil karyawan, mengubah jabatan, atau mereset PIN staf.',
  },
  {
    key: 'canHardware',
    label: 'Pengaturan Hardware & Printer Struk',
    category: 'SISTEM',
    description: 'Boleh mengubah konfigurasi printer thermal, scanner barcode, dan laci uang kasir.',
  },
  {
    key: 'canManageLicense',
    label: 'Pengaturan Cloud DB & Lisensi Toko',
    category: 'SISTEM',
    description: 'Boleh mengatur koneksi Supabase Cloud, reset database toko, dan aktivasi lisensi POS.',
  },
];

export const PembatasanAksesTab: React.FC<PembatasanAksesTabProps> = ({
  users,
  onUpdateUser,
  onUpdateMultipleUsers,
  onShowNotification,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'PER_ROLE' | 'PER_USER'>('PER_ROLE');

  // Matrix State for Role Templates
  const [roleMatrix, setRoleMatrix] = useState<Record<UserRole, Record<string, boolean>>>(() => {
    return {
      OWNER: {
        canVoid: true,
        canDiscount: true,
        canEditProduct: true,
        canOpname: true,
        canPurchases: true,
        canAccessReports: true,
        canViewProfit: true,
        canManageStaff: true,
        canHardware: true,
        canManageLicense: true,
      },
      SUPERVISOR: {
        canVoid: true,
        canDiscount: true,
        canEditProduct: false,
        canOpname: true,
        canPurchases: true,
        canAccessReports: true,
        canViewProfit: false,
        canManageStaff: false,
        canHardware: true,
        canManageLicense: false,
      },
      ADMIN: {
        canVoid: true,
        canDiscount: true,
        canEditProduct: true,
        canOpname: true,
        canPurchases: true,
        canAccessReports: true,
        canViewProfit: true,
        canManageStaff: false,
        canHardware: true,
        canManageLicense: false,
      },
      KASIR: {
        canVoid: false,
        canDiscount: false,
        canEditProduct: false,
        canOpname: false,
        canPurchases: false,
        canAccessReports: false,
        canViewProfit: false,
        canManageStaff: false,
        canHardware: false,
        canManageLicense: false,
      },
    };
  });

  // Selected User for Per-User Permission Customization
  const [selectedUserId, setSelectedUserId] = useState<string>(users[0]?.id || '');
  const selectedUser = users.find(u => u.id === selectedUserId) || users[0];

  const handleToggleRolePermission = (role: UserRole, permKey: string) => {
    if (role === 'OWNER') {
      onShowNotification('Hak akses Akun Owner selalu penuh dan tidak dapat dibatasi.');
      return;
    }
    setRoleMatrix(prev => ({
      ...prev,
      [role]: {
        ...prev[role],
        [permKey]: !prev[role][permKey],
      },
    }));
  };

  const handleApplyRolePermissionsToUsers = (role: UserRole) => {
    const template = roleMatrix[role];
    const updatedUsers = users.map(u => {
      if (u.role === role) {
        return {
          ...u,
          permissions: {
            ...u.permissions,
            ...template,
          },
        };
      }
      return u;
    });

    onUpdateMultipleUsers(updatedUsers);
    onShowNotification(`Hak akses standar untuk semua karyawan dengan jabatan ${role} berhasil diperbarui.`);
  };

  const handleApplyAllRoleMatrix = () => {
    const updatedUsers = users.map(u => {
      const template = roleMatrix[u.role];
      if (template) {
        return {
          ...u,
          permissions: {
            ...u.permissions,
            ...template,
          },
        };
      }
      return u;
    });

    onUpdateMultipleUsers(updatedUsers);
    onShowNotification('Seluruh matriks pembatasan akses berhasil diterapkan ke semua karyawan toko!');
  };

  const handleToggleIndividualPermission = (permKey: keyof User['permissions']) => {
    if (!selectedUser) return;
    if (selectedUser.role === 'OWNER') {
      onShowNotification('Hak akses Owner tidak dapat dibatasi.');
      return;
    }

    const updatedUser: User = {
      ...selectedUser,
      permissions: {
        ...selectedUser.permissions,
        [permKey]: !selectedUser.permissions[permKey],
      },
    };

    onUpdateUser(updatedUser);
    onShowNotification(`Hak akses "${permKey}" untuk ${selectedUser.name} berhasil diubah.`);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-150">
      {/* Top Banner Notice */}
      <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-inner font-bold">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
              <span>Pengaturan Pembatasan Akses Karyawan</span>
              <span className="px-2 py-0.5 bg-yellow-400 text-slate-950 font-black text-[9px] rounded uppercase">
                Khusus Owner
              </span>
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Lindungi toko dari kecurangan transaksi, salah input harga, dan kebocoran data laba dengan membatasi wewenang setiap jabatan atau staf.
            </p>
          </div>
        </div>

        {/* Sub-Tabs Switcher */}
        <div className="flex bg-white p-1 rounded-xl border border-red-200 text-xs font-bold gap-1 shrink-0">
          <button
            type="button"
            onClick={() => setActiveSubTab('PER_ROLE')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'PER_ROLE'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Matriks Jabatan (Role)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('PER_USER')}
            className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'PER_USER'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Khusus Per Karyawan</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: MATRIKS JABATAN (ROLE MATRIX) */}
      {activeSubTab === 'PER_ROLE' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
            <div>
              <h4 className="font-black text-slate-900 text-sm">
                Matriks Hak Akses Standar Retail per Jabatan
              </h4>
              <p className="text-xs text-slate-500">
                Centang izin yang diperbolehkan untuk masing-masing tingkatan jabatan di toko Anda.
              </p>
            </div>

            <button
              type="button"
              onClick={handleApplyAllRoleMatrix}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Simpan & Terapkan ke Semua Karyawan</span>
            </button>
          </div>

          {/* Matrix Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-black border-b border-slate-200">
                  <th className="py-3 px-4 rounded-l-xl">Daftar Fitur / Hak Akses</th>
                  <th className="py-3 px-3 text-center w-28 text-emerald-800">
                    <div className="flex flex-col items-center">
                      <span>OWNER</span>
                      <span className="text-[10px] font-normal text-emerald-600">Pemilik</span>
                    </div>
                  </th>
                  <th className="py-3 px-3 text-center w-28 text-blue-800">
                    <div className="flex flex-col items-center">
                      <span>SUPERVISOR</span>
                      <span className="text-[10px] font-normal text-blue-600">Kepala Toko</span>
                    </div>
                  </th>
                  <th className="py-3 px-3 text-center w-28 text-purple-800">
                    <div className="flex flex-col items-center">
                      <span>ADMIN</span>
                      <span className="text-[10px] font-normal text-purple-600">Gudang/Input</span>
                    </div>
                  </th>
                  <th className="py-3 px-3 text-center w-28 rounded-r-xl text-amber-800">
                    <div className="flex flex-col items-center">
                      <span>KASIR</span>
                      <span className="text-[10px] font-normal text-amber-600">Kasir Depan</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {PERMISSION_DEFS.map((def, idx) => (
                  <tr
                    key={def.key}
                    className={`hover:bg-slate-50/80 transition ${
                      idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900 text-xs">{def.label}</p>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        {def.description}
                      </p>
                    </td>

                    {/* OWNER (Always Checked & Locked) */}
                    <td className="py-3 px-3 text-center">
                      <div className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 font-bold">
                        ✓
                      </div>
                    </td>

                    {/* SUPERVISOR */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleToggleRolePermission('SUPERVISOR', def.key)}
                        className={`w-7 h-7 rounded-lg border flex items-center justify-center mx-auto transition cursor-pointer active:scale-90 ${
                          roleMatrix.SUPERVISOR[def.key]
                            ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                            : 'bg-white border-slate-300 text-slate-300 hover:border-slate-400'
                        }`}
                        title="Klik untuk toggle izin Supervisor"
                      >
                        {roleMatrix.SUPERVISOR[def.key] ? '✓' : '✕'}
                      </button>
                    </td>

                    {/* ADMIN */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleToggleRolePermission('ADMIN', def.key)}
                        className={`w-7 h-7 rounded-lg border flex items-center justify-center mx-auto transition cursor-pointer active:scale-90 ${
                          roleMatrix.ADMIN[def.key]
                            ? 'bg-purple-600 border-purple-600 text-white shadow-xs'
                            : 'bg-white border-slate-300 text-slate-300 hover:border-slate-400'
                        }`}
                        title="Klik untuk toggle izin Admin"
                      >
                        {roleMatrix.ADMIN[def.key] ? '✓' : '✕'}
                      </button>
                    </td>

                    {/* KASIR */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleToggleRolePermission('KASIR', def.key)}
                        className={`w-7 h-7 rounded-lg border flex items-center justify-center mx-auto transition cursor-pointer active:scale-90 ${
                          roleMatrix.KASIR[def.key]
                            ? 'bg-amber-600 border-amber-600 text-white shadow-xs'
                            : 'bg-white border-slate-300 text-slate-300 hover:border-slate-400'
                        }`}
                        title="Klik untuk toggle izin Kasir"
                      >
                        {roleMatrix.KASIR[def.key] ? '✓' : '✕'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Quick Apply per Role Footer */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-600 font-semibold">Terapkan per-Jabatan Langsung:</span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleApplyRolePermissionsToUsers('SUPERVISOR')}
                className="px-3 py-1.5 bg-white border border-blue-300 text-blue-700 hover:bg-blue-50 font-bold rounded-lg transition cursor-pointer"
              >
                Sync Supervisor ({users.filter(u => u.role === 'SUPERVISOR').length})
              </button>
              <button
                type="button"
                onClick={() => handleApplyRolePermissionsToUsers('ADMIN')}
                className="px-3 py-1.5 bg-white border border-purple-300 text-purple-700 hover:bg-purple-50 font-bold rounded-lg transition cursor-pointer"
              >
                Sync Admin ({users.filter(u => u.role === 'ADMIN').length})
              </button>
              <button
                type="button"
                onClick={() => handleApplyRolePermissionsToUsers('KASIR')}
                className="px-3 py-1.5 bg-white border border-amber-300 text-amber-700 hover:bg-amber-50 font-bold rounded-lg transition cursor-pointer"
              >
                Sync Kasir ({users.filter(u => u.role === 'KASIR').length})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: PENGATURAN SPESIFIK PER KARYAWAN */}
      {activeSubTab === 'PER_USER' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
          {/* User Selector Dropdown */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <h4 className="font-black text-slate-900 text-sm">
                Pengaturan Pengecualian Hak Akses per Karyawan
              </h4>
              <p className="text-xs text-slate-500">
                Berikan hak akses khusus (custom) kepada karyawan tertentu tanpa mengubah jabatan resminya.
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <label className="text-xs font-bold text-slate-700 shrink-0">Pilih Staf:</label>
              <select
                value={selectedUserId}
                onChange={e => setSelectedUserId(e.target.value)}
                className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500 cursor-pointer"
              >
                {users.map(u => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role}) - @{u.username}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Selected Employee Card */}
          {selectedUser && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-red-100 border border-red-200 text-red-700 font-black flex items-center justify-center text-sm shadow-xs">
                  {selectedUser.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-bold text-slate-900 text-sm">{selectedUser.name}</h5>
                    <span className="px-2 py-0.5 bg-slate-200 text-slate-800 rounded-md text-[10px] font-black">
                      {selectedUser.role}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-black ${
                        selectedUser.isActive !== false
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {selectedUser.isActive !== false ? 'Aktif' : 'Non-Aktif'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    Username: @{selectedUser.username} • PIN: {selectedUser.pin}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] text-slate-500 block">Total Izin Aktif:</span>
                <span className="text-xs font-black text-slate-900 font-mono">
                  {Object.values(selectedUser.permissions || {}).filter(Boolean).length} dari{' '}
                  {PERMISSION_DEFS.length} Izin
                </span>
              </div>
            </div>
          )}

          {/* Granular Permissions Checklist */}
          {selectedUser && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              {PERMISSION_DEFS.map(def => {
                const isGranted = Boolean(selectedUser.permissions?.[def.key]);
                const isOwner = selectedUser.role === 'OWNER';

                return (
                  <div
                    key={def.key}
                    onClick={() => {
                      if (!isOwner) handleToggleIndividualPermission(def.key);
                    }}
                    className={`p-3.5 border rounded-2xl flex items-start justify-between gap-3 transition ${
                      isGranted
                        ? 'bg-emerald-50/40 border-emerald-200 hover:border-emerald-300'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                    } ${isOwner ? 'cursor-default opacity-80' : 'cursor-pointer'}`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs text-slate-900">{def.label}</span>
                        {isGranted ? (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                            Dibuka
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-400 bg-slate-200 px-1.5 py-0.2 rounded">
                            Dibatasi
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                        {def.description}
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={isOwner}
                      className={`w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 transition ${
                        isGranted
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : 'bg-white border-slate-300 text-slate-300'
                      }`}
                    >
                      {isGranted ? '✓' : '✕'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
