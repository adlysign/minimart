import React, { useState, useRef } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Printer,
  Download,
  Upload,
  Barcode as BarcodeIcon,
  Package,
  X,
  Check,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { Product } from '../../types/pos';
import { formatRupiah, exportToCSV, generateBarcodeSvg } from '../../utils/formatters';

export const ProdukView: React.FC = () => {
  const { products, categories, suppliers, addProduct, updateProduct, deleteProduct } = usePOS();

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Barcode Label Print Modal
  const [labelPrintProduct, setLabelPrintProduct] = useState<Product | null>(null);
  const [labelCopies, setLabelCopies] = useState<number>(6);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    barcode: '',
    sku: '',
    categoryId: categories[0]?.id || '',
    supplierId: suppliers[0]?.id || '',
    unit: 'Pcs',
    costPrice: 0,
    sellingPrice: 0,
    stock: 0,
    minStock: 5,
    isActive: true,
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const openAddModal = () => {
    setEditingProduct(null);
    const randomBarcode = '899' + Math.floor(1000000000 + Math.random() * 9000000000);
    const randomSku = 'PRD-' + Math.floor(100 + Math.random() * 900);
    setFormData({
      name: '',
      barcode: randomBarcode,
      sku: randomSku,
      categoryId: categories[0]?.id || '',
      supplierId: suppliers[0]?.id || '',
      unit: 'Pcs',
      costPrice: 0,
      sellingPrice: 0,
      stock: 10,
      minStock: 5,
      isActive: true,
    });
    setShowModal(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      barcode: product.barcode,
      sku: product.sku,
      categoryId: product.categoryId,
      supplierId: product.supplierId || suppliers[0]?.id || '',
      unit: product.unit,
      costPrice: product.costPrice,
      sellingPrice: product.sellingPrice,
      stock: product.stock,
      minStock: product.minStock,
      isActive: product.isActive,
    });
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cat = categories.find(c => c.id === formData.categoryId);
    const sup = suppliers.find(s => s.id === formData.supplierId);

    if (editingProduct) {
      updateProduct({
        ...editingProduct,
        ...formData,
        categoryName: cat?.name,
        supplierName: sup?.name,
      });
    } else {
      addProduct({
        ...formData,
        categoryName: cat?.name,
        supplierName: sup?.name,
      });
    }
    setShowModal(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Hapus produk "${name}"? Data penjualan historis tetap aman.`)) {
      deleteProduct(id);
    }
  };

  // Export products to CSV
  const handleExport = () => {
    const rows = products.map(p => ({
      Barcode: p.barcode,
      SKU: p.sku,
      NamaProduk: p.name,
      Kategori: p.categoryName || '',
      Satuan: p.unit,
      HargaBeli: p.costPrice,
      HargaJual: p.sellingPrice,
      Stok: p.stock,
      MinStok: p.minStock,
      Supplier: p.supplierName || '',
    }));
    exportToCSV(`produk_minimarket_${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  // Import products from CSV
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result as string;
      if (!text) return;

      const lines = text.split('\n').filter(l => (l || '').trim().length > 0);
      if (lines.length <= 1) {
        alert('File CSV kosong atau format tidak sesuai.');
        return;
      }

      let addedCount = 0;
      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',').map(c => (c || '').trim().replace(/^"|"$/g, ''));
        if (cols.length >= 3) {
          const barcode = cols[0] || '899' + Math.floor(1000000000 + Math.random() * 9000000000);
          const sku = cols[1] || 'SKU-' + (products.length + addedCount + 1);
          const name = cols[2];
          const costPrice = parseFloat(cols[5]) || 2000;
          const sellingPrice = parseFloat(cols[6]) || 3000;
          const stock = parseFloat(cols[7]) || 10;
          const unit = cols[4] || 'Pcs';

          addProduct({
            name,
            barcode,
            sku,
            categoryId: categories[0]?.id || '',
            categoryName: categories[0]?.name,
            unit,
            costPrice,
            sellingPrice,
            stock,
            minStock: 5,
            isActive: true,
          });
          addedCount++;
        }
      }
      alert(`Berhasil mengimpor ${addedCount} produk baru ke katalog!`);
    };
    reader.readAsText(file);
  };

  const filtered = products.filter(p => {
    const matchesCat = categoryFilter === 'ALL' || p.categoryId === categoryFilter;
    const matchesSearch =
      search === '' ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.barcode.includes(search) ||
      p.sku.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-6 sm:pb-8 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header & Actions Card */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Package className="w-6 h-6 text-red-600" />
              <span>Katalog Produk & Master Data</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola data barang, barcode EAN-13, SKU/PLU, harga beli (HPP), harga jual kasir, dan cetak label rak.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImportFile}
              accept=".csv,.txt"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-blue-600" />
              <span>Import CSV</span>
            </button>
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-amber-600" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={openAddModal}
              className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Tambah Produk</span>
            </button>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari berdasarkan nama produk, nomor barcode, atau SKU..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-4 py-2 text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          <div className="flex gap-2">
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="bg-white border border-slate-300 text-slate-800 text-xs rounded-xl px-3 py-2 font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              <option value="ALL">Semua Kategori ({products.length})</option>
              {categories.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Products Table */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto max-h-[550px]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 z-10 pos-table-header">
                <tr>
                  <th className="py-3 px-4">Nama Produk</th>
                  <th className="py-3 px-4">Barcode / SKU</th>
                  <th className="py-3 px-4">Kategori</th>
                  <th className="py-3 px-4 text-right">Harga Beli (HPP)</th>
                  <th className="py-3 px-4 text-right">Harga Jual</th>
                  <th className="py-3 px-4 text-center">Stok</th>
                  <th className="py-3 px-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      Tidak ada produk yang cocok dengan pencarian.
                    </td>
                  </tr>
                ) : (
                  filtered.map(product => {
                    const isLow = product.stock <= product.minStock;
                    const isOut = product.stock <= 0;
                    return (
                      <tr key={product.id} className="hover:bg-slate-50 transition">
                        <td className="py-3 px-4">
                          <span className="font-bold text-slate-900 block text-xs sm:text-sm">
                            {product.name}
                          </span>
                          <span className="text-[11px] text-slate-400">Satuan: {product.unit}</span>
                        </td>
                        <td className="py-3 px-4 font-mono">
                          <span className="text-blue-700 block font-bold">{product.barcode}</span>
                          <span className="text-[10px] text-slate-500">{product.sku}</span>
                        </td>
                        <td className="py-3 px-4 text-slate-600 font-medium">
                          {product.categoryName || '-'}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-slate-600 font-bold">
                          {formatRupiah(product.costPrice)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-black text-red-600 text-xs sm:text-sm">
                          {formatRupiah(product.sellingPrice)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-bold ${
                              isOut
                                ? 'bg-red-100 text-red-800'
                                : isLow
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {product.stock} {product.unit}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => setLabelPrintProduct(product)}
                              className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-blue-600 rounded-lg transition cursor-pointer"
                              title="Cetak Label Barcode Rak"
                            >
                              <BarcodeIcon className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => openEditModal(product)}
                              className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-emerald-600 rounded-lg transition cursor-pointer"
                              title="Edit Produk"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(product.id, product.name)}
                              className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-red-600 rounded-lg transition cursor-pointer"
                              title="Hapus Produk"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* MODAL: ADD / EDIT PRODUCT */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto no-print">
          <div className="bg-white border-2 border-red-500 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-red-600 to-red-700 text-white">
              <h3 className="font-black text-white text-base">
                {editingProduct ? 'Edit Informasi Produk' : 'Tambah Produk Baru'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-white hover:text-yellow-200 p-1 rounded-lg font-bold"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 overflow-y-auto flex-1 text-slate-800">
              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Nama Produk *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Indomie Goreng Spesial 85g"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Nomor Barcode (EAN-13)</label>
                  <input
                    type="text"
                    required
                    value={formData.barcode}
                    onChange={e => setFormData({ ...formData, barcode: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">SKU / PLU Toko</label>
                  <input
                    type="text"
                    required
                    value={formData.sku}
                    onChange={e => setFormData({ ...formData, sku: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Kategori</label>
                  <select
                    value={formData.categoryId}
                    onChange={e => setFormData({ ...formData, categoryId: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Satuan Barang</label>
                  <input
                    type="text"
                    value={formData.unit}
                    onChange={e => setFormData({ ...formData, unit: e.target.value })}
                    placeholder="Pcs, Dus, Botol, Sachet..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Harga Beli / HPP (Rp)</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.costPrice}
                    onChange={e => setFormData({ ...formData, costPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Harga Jual Kasir (Rp)</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.sellingPrice}
                    onChange={e => setFormData({ ...formData, sellingPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-yellow-50 border-2 border-yellow-400 rounded-xl px-3 py-2 text-xs font-mono font-black text-red-600 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Stok Saat Ini</label>
                  <input
                    type="number"
                    value={formData.stock}
                    onChange={e => setFormData({ ...formData, stock: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Batas Minimum Stok</label>
                  <input
                    type="number"
                    min={1}
                    value={formData.minStock}
                    onChange={e => setFormData({ ...formData, minStock: parseFloat(e.target.value) || 1 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Supplier Utama</label>
                <select
                  value={formData.supplierId}
                  onChange={e => setFormData({ ...formData, supplierId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.contactPerson})
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-4 bg-slate-50 border-t border-slate-200 -mx-6 -mb-6 mt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-white border border-slate-300 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs transition cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Simpan Produk</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: PRINT BARCODE LABELS */}
      {labelPrintProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto no-print">
          <div className="bg-white border border-slate-300 rounded-3xl w-full max-w-lg shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-black text-slate-900 text-base">Cetak Label Barcode Rak Produk</h3>
              <button onClick={() => setLabelPrintProduct(null)} className="text-slate-400 hover:text-slate-700 font-bold">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-600 font-bold">
              <span>Jumlah Lembar Label:</span>
              <div className="flex items-center gap-2">
                {[4, 6, 8, 12].map(n => (
                  <button
                    key={n}
                    onClick={() => setLabelCopies(n)}
                    className={`px-3 py-1 rounded-lg font-bold border transition cursor-pointer ${
                      labelCopies === n
                        ? 'bg-yellow-400 text-slate-950 border-yellow-400 font-black'
                        : 'bg-slate-100 text-slate-700 border-slate-300'
                    }`}
                  >
                    {n}x
                  </button>
                ))}
              </div>
            </div>

            {/* Label preview sheet */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl max-h-72 overflow-y-auto grid grid-cols-2 gap-3">
              {Array.from({ length: labelCopies }).map((_, idx) => (
                <div key={idx} className="border border-slate-300 rounded-xl p-2.5 text-center text-slate-900 bg-white shadow-xs">
                  <h5 className="font-bold text-[11px] truncate">{labelPrintProduct.name}</h5>
                  <div
                    className="w-32 mx-auto my-1"
                    dangerouslySetInnerHTML={{
                      __html: generateBarcodeSvg(labelPrintProduct.barcode, 130, 45),
                    }}
                  />
                  <div className="flex justify-between text-[11px] font-bold px-1 text-slate-900">
                    <span className="font-mono text-slate-500">{labelPrintProduct.sku}</span>
                    <span className="font-black text-red-600 font-mono">
                      {formatRupiah(labelPrintProduct.sellingPrice)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setLabelPrintProduct(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 text-xs rounded-xl font-bold border border-slate-300 cursor-pointer"
              >
                Tutup
              </button>
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Label (Print)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
