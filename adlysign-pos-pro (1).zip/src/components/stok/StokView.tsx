import React, { useState, useEffect } from 'react';
import {
  Boxes,
  ArrowUpRight,
  ClipboardList,
  Layers,
  History,
  CheckCircle2,
  Save,
  RotateCcw,
  AlertTriangle,
  FileCheck,
  ShieldAlert,
  Search,
  Check,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { InventoryLog } from '../../types/pos';
import { formatDateTime, formatRupiah } from '../../utils/formatters';
import { hasPermission } from '../../utils/permissions';

type StokTab = 'LOGS' | 'ADJUST' | 'OPNAME' | 'REPACK';

export const StokView: React.FC = () => {
  const {
    products,
    stockLogs,
    adjustStock,
    commitStockOpname,
    stockOpnameSessions,
    executeRepack,
    repackRecords,
    currentUser,
  } = usePOS();

  const [currentTab, setCurrentTab] = useState<StokTab>('LOGS');

  // Permission check
  const canOpname = hasPermission(currentUser, 'canOpname');

  // Adjustment Form State
  const [adjustData, setAdjustData] = useState({
    productId: products[0]?.id || '',
    type: 'STOK_MASUK' as InventoryLog['type'],
    quantity: 1,
    notes: '',
    refDoc: '',
  });

  // Stock Opname Draft Counts State with localStorage persistence
  const [opnameCounts, setOpnameCounts] = useState<Record<string, number>>(() => {
    try {
      const savedDraft = localStorage.getItem('pos_draft_opname_counts');
      if (savedDraft) {
        const parsed = JSON.parse(savedDraft);
        if (parsed && typeof parsed === 'object') {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse pos_draft_opname_counts', e);
    }
    const initial: Record<string, number> = {};
    products.forEach(p => {
      initial[p.id] = p.stock;
    });
    return initial;
  });

  const [opnameSearch, setOpnameSearch] = useState('');
  const [showConfirmSaveModal, setShowConfirmSaveModal] = useState(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);
  const [draftSavedToast, setDraftSavedToast] = useState(false);

  // Sync new products into opnameCounts if added
  useEffect(() => {
    setOpnameCounts(prev => {
      let changed = false;
      const next = { ...prev };
      products.forEach(p => {
        if (next[p.id] === undefined) {
          next[p.id] = p.stock;
          changed = true;
        }
      });
      return changed ? next : prev;
    });
  }, [products]);

  // Save to localStorage whenever opnameCounts changes
  const updatePhysicalCount = (productId: string, val: number) => {
    setOpnameCounts(prev => {
      const next = { ...prev, [productId]: Math.max(0, val) };
      try {
        localStorage.setItem('pos_draft_opname_counts', JSON.stringify(next));
      } catch (e) {
        console.warn('Failed to save draft opname counts', e);
      }
      return next;
    });
  };

  // Explicit Save Draft Handler
  const handleSaveDraft = () => {
    try {
      localStorage.setItem('pos_draft_opname_counts', JSON.stringify(opnameCounts));
      setDraftSavedToast(true);
      setTimeout(() => setDraftSavedToast(false), 3000);
    } catch (e) {
      alert('Gagal menyimpan draf ke penyimpanan lokal.');
    }
  };

  // Reset to current computer stock
  const handleResetToSystem = () => {
    if (confirm('Kembalikan semua angka hitungan fisik rak ke stok komputer saat ini? Draf hitungan yang belum disimpan akan dihapus.')) {
      const reset: Record<string, number> = {};
      products.forEach(p => {
        reset[p.id] = p.stock;
      });
      setOpnameCounts(reset);
      try {
        localStorage.removeItem('pos_draft_opname_counts');
      } catch (e) {}
      setDraftSavedToast(true);
      setTimeout(() => setDraftSavedToast(false), 2500);
    }
  };

  // Repacking Form State (Convert Dus -> Pcs, etc.)
  const [repackData, setRepackData] = useState({
    sourceProductId: products.find(p => p.unit === 'Dus')?.id || products[0]?.id || '',
    sourceQty: 1,
    targetProductId: products.find(p => p.unit === 'Pcs')?.id || products[1]?.id || '',
    targetQty: 24,
    notes: 'Bongkar dus ke eceran per bungkus',
  });

  const handleAdjustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canOpname) {
      alert('Akses Ditolak: Akun Anda tidak memiliki izin mutasi persediaan.');
      return;
    }
    const qty = parseFloat(adjustData.quantity as any) || 0;
    if (qty <= 0) {
      alert('Jumlah kuantitas harus lebih dari 0');
      return;
    }

    const prod = products.find(p => p.id === adjustData.productId);
    if (!prod) return;

    const isNegative = ['STOK_KELUAR', 'BARANG_RUSAK', 'BARANG_EXPIRED', 'MUTASI_STOK'].includes(
      adjustData.type
    );
    const finalChange = isNegative ? -qty : qty;

    if (isNegative && prod.stock < qty) {
      if (!confirm(`Peringatan: Stok tercatat (${prod.stock}) lebih sedikit dari yang akan dikeluarkan (${qty}). Tetap lanjutkan?`)) {
        return;
      }
    }

    adjustStock(prod.id, adjustData.type, finalChange, adjustData.notes, adjustData.refDoc);
    alert(`Penyesuaian persediaan ${prod.name} berhasil dicatat.`);
    setAdjustData({ ...adjustData, quantity: 1, notes: '', refDoc: '' });
    setCurrentTab('LOGS');
  };

  // Calculate Opname items
  const opnameItems = products.map(prod => {
    const physical = opnameCounts[prod.id] !== undefined ? opnameCounts[prod.id] : prod.stock;
    const diff = physical - prod.stock;
    return {
      productId: prod.id,
      productName: prod.name,
      barcode: prod.barcode,
      unit: prod.unit,
      costPrice: prod.costPrice,
      systemStock: prod.stock,
      physicalStock: physical,
      difference: diff,
      varianceValue: diff * (prod.costPrice || 0),
    };
  });

  const itemsWithDiff = opnameItems.filter(i => i.difference !== 0);
  const totalVarianceValue = opnameItems.reduce((sum, item) => sum + item.varianceValue, 0);

  // Filtered opname table items
  const filteredOpnameItems = opnameItems.filter(
    i =>
      i.productName.toLowerCase().includes(opnameSearch.toLowerCase()) ||
      i.barcode.includes(opnameSearch)
  );

  // Execute Commit Stock Opname
  const handleConfirmCommitOpname = () => {
    if (!canOpname) {
      alert('Akses Ditolak: Anda tidak memiliki wewenang untuk menyimpan Stock Opname.');
      return;
    }

    commitStockOpname({
      opnameNumber: `OPN-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString(),
      supervisorName: currentUser.name,
      items: opnameItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        barcode: item.barcode,
        systemStock: item.systemStock,
        physicalStock: item.physicalStock,
        difference: item.difference,
      })),
      status: 'COMMITTED',
      totalVarianceValue,
    });

    // Clear draft storage
    try {
      localStorage.removeItem('pos_draft_opname_counts');
    } catch (e) {}

    // Update state to match committed physical stock
    const fresh: Record<string, number> = {};
    opnameItems.forEach(i => {
      fresh[i.productId] = i.physicalStock;
    });
    setOpnameCounts(fresh);

    setShowConfirmSaveModal(false);
    setSaveSuccessMessage(
      `Hasil Stock Opname berhasil disimpan! ${itemsWithDiff.length} item telah disesuaikan dan disimpan permanen di database.`
    );
    setTimeout(() => setSaveSuccessMessage(null), 6000);
  };

  const handleRepackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canOpname) {
      alert('Akses Ditolak: Anda tidak memiliki wewenang untuk repacking.');
      return;
    }
    if (repackData.sourceProductId === repackData.targetProductId) {
      alert('Produk asal (Dus/Pak) dan produk tujuan (Pcs) tidak boleh sama!');
      return;
    }

    executeRepack(
      repackData.sourceProductId,
      repackData.sourceQty,
      repackData.targetProductId,
      repackData.targetQty,
      repackData.notes
    );
    alert('Proses repacking barang berhasil dilaksanakan.');
    setCurrentTab('LOGS');
  };

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-24">
      {/* Toast Notification: Draft Saved */}
      {draftSavedToast && (
        <div className="fixed top-20 right-4 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-2xl shadow-xl border border-yellow-400 flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>Draf hitungan fisik berhasil disimpan di memori browser.</span>
        </div>
      )}

      {/* Success Notification Banner */}
      {saveSuccessMessage && (
        <div className="max-w-7xl w-full mx-auto bg-emerald-600 text-white p-4 rounded-2xl shadow-md flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 shrink-0" />
            <div>
              <h4 className="font-black text-sm">Stock Opname Berhasil Disimpan!</h4>
              <p className="text-xs text-emerald-100">{saveSuccessMessage}</p>
            </div>
          </div>
          <button
            onClick={() => setSaveSuccessMessage(null)}
            className="text-white hover:text-emerald-200 font-black text-xs px-2 py-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* Permission Warning if unauthorized */}
      {!canOpname && (
        <div className="max-w-7xl w-full mx-auto bg-amber-50 border-2 border-amber-300 p-3.5 rounded-2xl text-amber-900 flex items-center gap-3 text-xs">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
          <div>
            <span className="font-bold">Mode Terbatas:</span> Akun kasir Anda (
            <strong>{currentUser.name}</strong>) tidak memiliki hak akses perubahan persediaan
            (canOpname). Penyesuaian atau penyimpanan Stock Opname hanya dapat dilakukan oleh
            Supervisor atau Owner.
          </div>
        </div>
      )}

      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header & Tab Switcher Card */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Boxes className="w-6 h-6 text-red-600" />
              <span>Persediaan & Stock Opname Toko</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Audit fisik rak toko [F6], mutasi stok masuk/keluar, retur rusak/expired, dan repacking grosir.
            </p>
          </div>

          {/* Tab switcher */}
          <div className="flex bg-slate-200 p-1 rounded-xl text-xs font-bold flex-wrap gap-1">
            <button
              onClick={() => setCurrentTab('LOGS')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'LOGS' ? 'bg-red-600 text-white font-black shadow-xs' : 'text-slate-700 hover:text-black'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Kartu Stok</span>
            </button>
            <button
              onClick={() => setCurrentTab('ADJUST')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'ADJUST' ? 'bg-red-600 text-white font-black shadow-xs' : 'text-slate-700 hover:text-black'
              }`}
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Mutasi Stok</span>
            </button>
            <button
              onClick={() => setCurrentTab('OPNAME')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'OPNAME' ? 'bg-red-600 text-white font-black shadow-xs' : 'text-slate-700 hover:text-black'
              }`}
            >
              <ClipboardList className="w-3.5 h-3.5" />
              <span>SO Toko [F6]</span>
            </button>
            <button
              onClick={() => setCurrentTab('REPACK')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'REPACK' ? 'bg-red-600 text-white font-black shadow-xs' : 'text-slate-700 hover:text-black'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Repack (Dus→Pcs)</span>
            </button>
          </div>
        </div>

        {/* TAB 1: STOCK AUDIT TRAIL LOGS (KARTU STOK) */}
        {currentTab === 'LOGS' && (
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="font-bold text-xs sm:text-sm text-slate-800">Riwayat Mutasi & Perubahan Stok Real-Time</h3>
              <span className="text-xs text-slate-500 font-mono font-bold">Total: {stockLogs.length} transaksi</span>
            </div>

            <div className="overflow-x-auto max-h-[550px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 z-10 pos-table-header">
                  <tr>
                    <th className="py-2.5 px-3">Waktu</th>
                    <th className="py-2.5 px-3">Produk</th>
                    <th className="py-2.5 px-3">Jenis Mutasi</th>
                    <th className="py-2.5 px-3 text-center">Perubahan</th>
                    <th className="py-2.5 px-3 text-center">Sebelum</th>
                    <th className="py-2.5 px-3 text-center">Sesudah</th>
                    <th className="py-2.5 px-3">No. Dokumen / Keterangan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {stockLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50 transition">
                      <td className="py-2.5 px-3 whitespace-nowrap text-slate-500">{formatDateTime(log.createdAt)}</td>
                      <td className="py-2.5 px-3 font-sans font-bold text-slate-900">{log.productName}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-black ${
                            log.type.includes('MASUK') || log.type.includes('RETUR')
                              ? 'bg-emerald-100 text-emerald-800'
                              : log.type.includes('RUSAK') || log.type.includes('EXPIRED')
                              ? 'bg-rose-100 text-rose-800'
                              : log.type === 'STOCK_OPNAME'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {log.type}
                        </span>
                      </td>
                      <td
                        className={`py-2.5 px-3 text-center font-bold ${
                          log.quantityChange > 0 ? 'text-emerald-600' : 'text-red-600'
                        }`}
                      >
                        {log.quantityChange > 0 ? `+${log.quantityChange}` : log.quantityChange}
                      </td>
                      <td className="py-2.5 px-3 text-center text-slate-500">{log.stockBefore}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-slate-800">{log.stockAfter}</td>
                      <td className="py-2.5 px-3 text-slate-600 font-sans">
                        {log.referenceDoc && <span className="font-bold text-blue-700 mr-1.5">[{log.referenceDoc}]</span>}
                        {log.notes || '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: FORM MUTASI STOK MANUAL */}
        {currentTab === 'ADJUST' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-6 max-w-xl mx-auto shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-black text-slate-900">Form Mutasi Persediaan Manual</h3>
              <p className="text-xs text-slate-500">
                Catat penerimaan internal, barang rusak di toko, barang kadaluarsa (expired), atau selisih fisik.
              </p>
            </div>

            <form onSubmit={handleAdjustSubmit} className="space-y-4">
              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Pilih Produk *</label>
                <select
                  value={adjustData.productId}
                  onChange={e => setAdjustData({ ...adjustData, productId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Stok Saat Ini: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Jenis Mutasi *</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { type: 'STOK_MASUK', label: 'Stok Masuk (+)', color: 'border-emerald-500 text-emerald-700 bg-emerald-50' },
                    { type: 'STOK_KELUAR', label: 'Stok Keluar (-)', color: 'border-amber-500 text-amber-800 bg-amber-50' },
                    { type: 'BARANG_RUSAK', label: 'Barang Rusak (-)', color: 'border-red-500 text-red-700 bg-red-50' },
                    { type: 'BARANG_EXPIRED', label: 'Barang Expired (-)', color: 'border-rose-500 text-rose-700 bg-rose-50' },
                    { type: 'MUTASI_STOK', label: 'Mutasi Cabang / Rak', color: 'border-blue-500 text-blue-700 bg-blue-50' },
                  ].map(opt => (
                    <button
                      key={opt.type}
                      type="button"
                      onClick={() => setAdjustData({ ...adjustData, type: opt.type as any })}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border text-center transition cursor-pointer ${
                        adjustData.type === opt.type
                          ? `${opt.color} ring-2 ring-red-500 font-black`
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Jumlah Kuantitas (Qty) *</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={adjustData.quantity}
                    onChange={e => setAdjustData({ ...adjustData, quantity: parseInt(e.target.value) || 1 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Nomor Dokumen / BA</label>
                  <input
                    type="text"
                    value={adjustData.refDoc}
                    onChange={e => setAdjustData({ ...adjustData, refDoc: e.target.value })}
                    placeholder="Contoh: BA-RUSAK-001"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Keterangan / Alasan</label>
                <textarea
                  value={adjustData.notes}
                  onChange={e => setAdjustData({ ...adjustData, notes: e.target.value })}
                  rows={2}
                  placeholder="Contoh: Kemasan bocor saat penataan di rak minuman..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <button
                type="submit"
                disabled={!canOpname}
                className={`w-full py-3 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer ${
                  canOpname
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-slate-400 cursor-not-allowed opacity-60'
                }`}
              >
                Simpan Mutasi Persediaan
              </button>
            </form>
          </div>
        )}

        {/* TAB 3: STOCK OPNAME FISIK DENGAN TOMBOL SIMPAN & PERSISTENCE */}
        {currentTab === 'OPNAME' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xs">
            {/* Top Action Bar */}
            <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-3 border-b border-slate-200 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-slate-900">
                    Lembar Kerja Stock Opname (SO) Fisik Toko
                  </h3>
                  <span className="px-2 py-0.5 bg-purple-100 text-purple-800 text-[10px] font-black rounded-full">
                    Audit Rak Fisik
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Input hitungan fisik barang di rak. Nilai tersimpan otomatis di perangkat dan tidak akan hilang saat halaman di-refresh.
                </p>
              </div>

              {/* Action Buttons: Clear Save, Save Draft, Reset */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetToSystem}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  title="Kembalikan semua angka ke stok sistem komputer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                  <span>Reset Hitungan</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  className="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  title="Simpan draf hitungan sementara ke memori"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Draf</span>
                </button>

                <button
                  type="button"
                  disabled={!canOpname}
                  onClick={() => setShowConfirmSaveModal(true)}
                  className={`px-4 py-2 text-white text-xs font-black rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer ${
                    canOpname
                      ? 'bg-emerald-600 hover:bg-emerald-700 ring-2 ring-emerald-400/50'
                      : 'bg-slate-400 cursor-not-allowed opacity-60'
                  }`}
                  title="Simpan dan terapkan hasil penyesuaian stok ke database"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-100" />
                  <span>Simpan Hasil Stock Opname (SO)</span>
                </button>
              </div>
            </div>

            {/* Filter Search Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari barcode / nama barang..."
                  value={opnameSearch}
                  onChange={e => setOpnameSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="text-xs text-slate-600 font-semibold flex items-center gap-2">
                <span>
                  Menampilkan <strong>{filteredOpnameItems.length}</strong> dari {products.length} produk
                </span>
                {itemsWithDiff.length > 0 && (
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full font-bold text-[11px]">
                    {itemsWithDiff.length} Item Berselisih
                  </span>
                )}
              </div>
            </div>

            {/* Table of Physical Counts */}
            <div className="overflow-x-auto max-h-[480px] border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 z-10 pos-table-header">
                  <tr>
                    <th className="py-2.5 px-3">PLU / Barcode</th>
                    <th className="py-2.5 px-3">Nama Produk</th>
                    <th className="py-2.5 px-3 text-center">Stok Komputer</th>
                    <th className="py-2.5 px-3 text-center w-36">Hitungan Fisik Rak</th>
                    <th className="py-2.5 px-3 text-center">Selisih Unit</th>
                    <th className="py-2.5 px-3 text-right">Nilai Selisih (HPP)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {filteredOpnameItems.map(item => {
                    return (
                      <tr
                        key={item.productId}
                        className={`hover:bg-slate-50 transition ${
                          item.difference !== 0 ? 'bg-yellow-50/50' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 font-bold text-blue-700">{item.barcode}</td>
                        <td className="py-2.5 px-3 font-sans font-bold text-slate-900">
                          {item.productName}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-700">
                          {item.systemStock} {item.unit}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <input
                            type="number"
                            min={0}
                            disabled={!canOpname}
                            value={item.physicalStock}
                            onChange={e =>
                              updatePhysicalCount(item.productId, parseInt(e.target.value) || 0)
                            }
                            className="w-24 text-center font-bold font-mono py-1.5 bg-yellow-50 border-2 border-yellow-400 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span
                            className={`px-2.5 py-1 rounded-full text-xs font-black inline-block ${
                              item.difference === 0
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.difference > 0
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {item.difference > 0 ? `+${item.difference}` : item.difference} {item.unit}
                          </span>
                        </td>
                        <td
                          className={`py-2.5 px-3 text-right font-bold ${
                            item.varianceValue === 0
                              ? 'text-slate-400'
                              : item.varianceValue > 0
                              ? 'text-blue-700'
                              : 'text-red-600'
                          }`}
                        >
                          {formatRupiah(item.varianceValue)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Bottom Summary & Sticky Action Bar */}
            <div className="bg-slate-900 text-white rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg border border-slate-700">
              <div className="flex flex-wrap items-center gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Total Produk:</span>
                  <span className="font-mono font-bold text-base text-white">
                    {products.length} Item
                  </span>
                </div>
                <div className="h-8 w-px bg-slate-700 hidden sm:block" />
                <div>
                  <span className="text-slate-400 block text-[11px]">Produk Berselisih:</span>
                  <span
                    className={`font-mono font-black text-base ${
                      itemsWithDiff.length > 0 ? 'text-yellow-400' : 'text-emerald-400'
                    }`}
                  >
                    {itemsWithDiff.length} Item
                  </span>
                </div>
                <div className="h-8 w-px bg-slate-700 hidden sm:block" />
                <div>
                  <span className="text-slate-400 block text-[11px]">Total Nilai Selisih HPP:</span>
                  <span
                    className={`font-mono font-black text-base ${
                      totalVarianceValue === 0
                        ? 'text-slate-300'
                        : totalVarianceValue > 0
                        ? 'text-blue-400'
                        : 'text-red-400'
                    }`}
                  >
                    {formatRupiah(totalVarianceValue)}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto">
                <button
                  type="button"
                  onClick={handleSaveDraft}
                  className="flex-1 md:flex-initial px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-600 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4 text-yellow-400" />
                  <span>Simpan Draf</span>
                </button>

                <button
                  type="button"
                  disabled={!canOpname}
                  onClick={() => setShowConfirmSaveModal(true)}
                  className={`flex-1 md:flex-initial px-5 py-2.5 text-white font-black text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer ${
                    canOpname
                      ? 'bg-emerald-500 hover:bg-emerald-600 ring-2 ring-emerald-300/40'
                      : 'bg-slate-600 cursor-not-allowed opacity-60'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simpan & Terapkan Hasil SO Sekarang</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: REPACKING GROSIR */}
        {currentTab === 'REPACK' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-6 max-w-xl mx-auto shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-black text-slate-900">Konversi & Repacking Barang (Dus → Pcs)</h3>
              <p className="text-xs text-slate-500">
                Pecah kemasan besar (Dus/Karton/Lusin) menjadi barang eceran satuan (Pcs/Bungkus) otomatis.
              </p>
            </div>

            <form onSubmit={handleRepackSubmit} className="space-y-4">
              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Produk Induk (Dus / Karton) *</label>
                <select
                  value={repackData.sourceProductId}
                  onChange={e => setRepackData({ ...repackData, sourceProductId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Stok: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Jumlah Dus Dikurangi *</label>
                  <input
                    type="number"
                    min={1}
                    value={repackData.sourceQty}
                    onChange={e => setRepackData({ ...repackData, sourceQty: parseInt(e.target.value) || 1 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-700 font-bold mb-1 block">Hasil Satuan Eceran (Pcs) *</label>
                  <input
                    type="number"
                    min={1}
                    value={repackData.targetQty}
                    onChange={e => setRepackData({ ...repackData, targetQty: parseInt(e.target.value) || 1 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-700 font-bold mb-1 block">Produk Eceran Tujuan *</label>
                <select
                  value={repackData.targetProductId}
                  onChange={e => setRepackData({ ...repackData, targetProductId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Stok: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={!canOpname}
                className={`w-full py-3 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer ${
                  canOpname
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-slate-400 cursor-not-allowed opacity-60'
                }`}
              >
                Konfirmasi Pembongkaran Dus (Repack)
              </button>
            </form>
          </div>
        )}
      </div>

      {/* MODAL KONFIRMASI SIMPAN STOCK OPNAME */}
      {showConfirmSaveModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-4 bg-emerald-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-emerald-200" />
                <h3 className="font-black text-sm">Konfirmasi Simpan Stock Opname</h3>
              </div>
              <button
                onClick={() => setShowConfirmSaveModal(false)}
                className="text-white hover:text-slate-200 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto text-xs">
              <p className="text-slate-600 leading-relaxed">
                Anda akan menyimpan dan menerapkan hasil perhitungan fisik Stock Opname ke sistem.
                Stok komputer akan <strong>langsung disesuaikan secara permanen</strong> dengan data fisik berikut:
              </p>

              {/* Discrepancy Summary Box */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-slate-600">Total Item Dihitung:</span>
                  <span className="text-slate-900 font-mono">{products.length} Produk</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span className="text-slate-600">Produk Berselisih:</span>
                  <span
                    className={`font-mono ${
                      itemsWithDiff.length > 0 ? 'text-amber-600' : 'text-emerald-600'
                    }`}
                  >
                    {itemsWithDiff.length} Produk
                  </span>
                </div>
                <div className="flex justify-between font-bold">
                  <span className="text-slate-600">Total Nilai Finansial Selisih:</span>
                  <span
                    className={`font-mono ${
                      totalVarianceValue < 0 ? 'text-red-600' : 'text-slate-900'
                    }`}
                  >
                    {formatRupiah(totalVarianceValue)}
                  </span>
                </div>
              </div>

              {/* Items List with Discrepancies */}
              {itemsWithDiff.length > 0 ? (
                <div>
                  <h4 className="font-bold text-slate-800 mb-2">Daftar Barang Berselisih:</h4>
                  <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100">
                    {itemsWithDiff.map(item => (
                      <div
                        key={item.productId}
                        className="p-2.5 flex items-center justify-between text-[11px]"
                      >
                        <div>
                          <p className="font-bold text-slate-900">{item.productName}</p>
                          <p className="text-slate-500 font-mono">
                            Komputer: {item.systemStock} → Fisik: {item.physicalStock} {item.unit}
                          </p>
                        </div>
                        <span
                          className={`font-mono font-black px-2 py-0.5 rounded text-xs ${
                            item.difference > 0
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {item.difference > 0 ? `+${item.difference}` : item.difference} {item.unit}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 font-bold text-center">
                  ✓ Tidak ada selisih stok. Semua angka fisik sama persis dengan komputer.
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowConfirmSaveModal(false)}
                className="px-4 py-2.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmCommitOpname}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-md transition flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Ya, Simpan & Perbarui Stok Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
