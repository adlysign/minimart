import React, { useState, useEffect } from 'react';
import {
  ShoppingCart,
  Package,
  Boxes,
  Truck,
  ShoppingBag,
  TrendingUp,
  Users,
  Cpu,
  Cloud,
  Key,
  Lock,
  LogOut,
  ShieldAlert,
  BookOpen,
  CreditCard,
  Settings,
  Wifi,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { canAccessModule } from '../../utils/permissions';

export type ActiveModule =
  | 'KASIR'
  | 'PRODUK'
  | 'STOK'
  | 'PEMBELIAN'
  | 'PENJUALAN'
  | 'PIUTANG'
  | 'SETTING_PEMBAYARAN'
  | 'LAPORAN'
  | 'KARYAWAN'
  | 'HARDWARE'
  | 'CLOUD'
  | 'LAN_SYNC'
  | 'LISENSI';

interface HeaderNavProps {
  activeModule: ActiveModule;
  onSelectModule: (module: ActiveModule) => void;
  onLockScreen?: () => void;
  onLogout?: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeModule,
  onSelectModule,
  onLockScreen,
  onLogout,
}) => {
  const {
    storeProfile,
    currentUser,
    activeShift,
    cloudSyncStatus,
    triggerSync,
    piutangList,
    lanSyncStatus,
  } = usePOS();

  const unpaidPiutangCount = piutangList ? piutangList.filter(p => p.status === 'BELUM_LUNAS').length : 0;

  // Digital Live Clock
  const [time, setTime] = useState(new Date());
  const [accessDeniedMsg, setAccessDeniedMsg] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const fullMonths = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];

  // Format: Hari, Tanggal Bulan Tahun (contoh: Jumat, 18 September 2026)
  const dateFormatted = `${days[time.getDay()]}, ${time.getDate()} ${fullMonths[time.getMonth()]} ${time.getFullYear()}`;
  const clockFormatted = time.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const handleModuleClick = (moduleId: ActiveModule) => {
    const access = canAccessModule(currentUser, moduleId);
    if (!access.allowed) {
      setAccessDeniedMsg(access.reason || 'Akses Ditolak: Anda tidak memiliki wewenang untuk membuka modul ini.');
      setTimeout(() => setAccessDeniedMsg(null), 4000);
      return;
    }
    onSelectModule(moduleId);
  };

  const navItems: Array<{ id: ActiveModule; label: string; shortcut?: string; badge?: number; icon: React.FC<{ className?: string }> }> = [
    { id: 'KASIR', label: 'Kasir', shortcut: 'F2', icon: ShoppingCart },
    { id: 'PRODUK', label: 'Produk', icon: Package },
    { id: 'STOK', label: 'Persediaan & Opname', icon: Boxes },
    { id: 'PEMBELIAN', label: 'Pembelian (LPB)', icon: Truck },
    { id: 'PENJUALAN', label: 'Penjualan & Retur', icon: ShoppingBag },
    { id: 'PIUTANG', label: 'Piutang & Kasbon', badge: unpaidPiutangCount, icon: BookOpen },
    { id: 'SETTING_PEMBAYARAN', label: 'Setting', icon: Settings },
    { id: 'LAPORAN', label: 'Laporan', icon: TrendingUp },
    { id: 'KARYAWAN', label: 'Karyawan', icon: Users },
    { id: 'HARDWARE', label: 'Hardware', icon: Cpu },
    { id: 'CLOUD', label: 'Cloud & DB', icon: Cloud },
    { id: 'LAN_SYNC', label: 'Jaringan LAN', icon: Wifi },
    { id: 'LISENSI', label: 'Lisensi', icon: Key },
  ];

  return (
    <header className="modern-blue-header sticky top-0 z-30 shadow-md no-print shrink-0 select-none bg-gradient-to-r from-sky-600 via-sky-700 to-blue-700 text-white border-b border-sky-400/30">
      {/* Toast Akses Ditolak */}
      {accessDeniedMsg && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-red-700 text-white px-5 py-3 rounded-2xl shadow-2xl border-2 border-sky-200 flex items-center gap-3 text-xs font-bold animate-in fade-in slide-in-from-top-3 max-w-lg text-center">
          <ShieldAlert className="w-5 h-5 text-yellow-300 shrink-0" />
          <span>{accessDeniedMsg}</span>
          <button
            type="button"
            onClick={() => setAccessDeniedMsg(null)}
            className="text-white hover:text-sky-200 ml-2 font-black cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Top Header Row (Logo, Identitas Toko, User/Kasir, Status Cloud, dan Jam Minimalis Modern) */}
      <div className="px-2.5 sm:px-4 py-2">
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* KIRI: LOGO & IDENTITAS KASIR TOKO */}
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-white text-sky-700 flex items-center justify-center font-black text-base sm:text-lg shadow-sm border border-sky-200 shrink-0">
              🏪
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h1 className="font-black text-xs sm:text-sm lg:text-base tracking-wide text-white truncate">
                  {storeProfile.name || 'MINIMARKET MODERN'}
                </h1>
                <span className="px-1.5 py-0.2 rounded-md bg-white/20 text-sky-100 text-[9px] font-black uppercase tracking-wider shrink-0 border border-white/20">
                  POS
                </span>
              </div>

              <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                <span className="px-1.5 py-0.2 rounded-md bg-sky-300/30 text-white font-black text-[9px] uppercase tracking-wider shrink-0 border border-white/20">
                  {currentUser.role === 'KASIR' ? 'CREW' : currentUser.role}
                </span>
                <span className="text-[11px] text-sky-100 font-medium truncate">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-sky-300/60 hidden sm:inline">•</span>
                <span className="text-[10px] text-sky-100 hidden sm:inline">
                  {activeShift?.shiftName || 'Shift 1'}
                </span>

                <button
                  type="button"
                  onClick={() => {
                    if (onLockScreen) onLockScreen();
                    else handleModuleClick('KARYAWAN');
                  }}
                  className="ml-1 px-1.5 py-0.5 bg-black/20 hover:bg-black/40 text-white rounded-md text-[9px] font-bold transition flex items-center gap-0.5 shrink-0 cursor-pointer border border-white/10"
                  title="Kunci Kasir (Lock Screen)"
                >
                  <Lock className="w-2.5 h-2.5" />
                  <span>Kunci</span>
                </button>

                {onLogout && (
                  <button
                    type="button"
                    onClick={onLogout}
                    className="ml-0.5 px-1.5 py-0.5 bg-red-600/70 hover:bg-red-600 text-white rounded-md text-[9px] font-bold transition flex items-center gap-0.5 shrink-0 cursor-pointer border border-red-400/30"
                    title="Keluar / Logout Kasir"
                  >
                    <LogOut className="w-2.5 h-2.5" />
                    <span>Keluar</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* KANAN: STATUS LAN & CLOUD & JAM MINIMALIS MODERN */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Indikator LAN Realtime Multi-Kasir */}
            <button
              onClick={() => handleModuleClick('LAN_SYNC')}
              className={`px-2 py-1 rounded-lg text-[10px] sm:text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer ${
                lanSyncStatus?.isConnected
                  ? 'bg-sky-950/60 border-sky-300/50 text-sky-200 hover:bg-sky-900/80'
                  : 'bg-rose-950/50 border-rose-400/40 text-rose-200 hover:bg-rose-900/70'
              }`}
              title="Status Jaringan Lokal (LAN) Multi-Kasir. Klik untuk buka modul LAN."
            >
              <Wifi className={`w-3 h-3 ${lanSyncStatus?.isConnected ? 'text-sky-300 animate-pulse' : 'text-rose-300'}`} />
              <span className="font-mono">
                {lanSyncStatus?.isConnected ? `LAN (${(lanSyncStatus.connectedClients || []).length})` : 'LAN OFF'}
              </span>
            </button>

            {/* Indikator Cloud Supabase */}
            <button
              onClick={() => triggerSync()}
              disabled={cloudSyncStatus.isSyncing}
              className={`px-2 py-1 rounded-lg text-[10px] sm:text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer ${
                cloudSyncStatus.supabaseConnected
                  ? 'bg-emerald-950/50 border-emerald-400/40 text-emerald-300'
                  : 'bg-black/20 border-white/15 text-sky-200'
              }`}
              title="Klik untuk sinkronisasi manual ke Supabase"
            >
              <span className={`w-2 h-2 rounded-full ${cloudSyncStatus.supabaseConnected ? 'bg-emerald-400 animate-pulse' : 'bg-sky-300'}`} />
              <span className="hidden sm:inline font-mono">
                {cloudSyncStatus.isSyncing ? 'SYNC...' : cloudSyncStatus.supabaseConnected ? 'ONLINE' : 'OFFLINE'}
              </span>
            </button>

            {/* Jam Digital Minimalis Modern: Hari, Tanggal Bulan Tahun & Jam di Bawah */}
            <div className="flex flex-col items-end justify-center bg-white/10 hover:bg-white/15 backdrop-blur-xs border border-white/20 rounded-xl px-2.5 sm:px-3 py-1 shadow-xs text-right shrink-0 transition-all">
              <span className="text-[10px] sm:text-[11px] font-medium text-sky-100 whitespace-nowrap leading-tight tracking-wide">
                {dateFormatted}
              </span>
              <span className="text-xs sm:text-sm font-black font-mono text-white tracking-wider leading-tight pt-0.5">
                {clockFormatted}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Row Tab Navigasi Bebas Tumpang Tindih di Semua Resolusi (Phone, Tablet, PC, Fullscreen) */}
      <div className="bg-sky-900/30 border-t border-sky-400/20 px-2 sm:px-3 py-1 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1 min-w-max">
          {navItems.map(item => {
            const isActive = activeModule === item.id;
            const access = canAccessModule(currentUser, item.id);
            const isLocked = !access.allowed;
            const Icon = item.icon;

            return (
              <button
                key={item.id}
                onClick={() => handleModuleClick(item.id)}
                title={isLocked ? `${item.label} (Akses Terbatas: ${access.reason})` : item.label}
                className={`px-2.5 sm:px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-white text-sky-800 font-extrabold shadow-sm'
                    : isLocked
                    ? 'text-white/50 hover:text-white hover:bg-white/10 opacity-70'
                    : 'text-sky-100 hover:bg-white/15 hover:text-white'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-sky-700' : 'text-sky-200'}`} />
                <span>{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                      isActive
                        ? 'bg-red-600 text-white'
                        : 'bg-sky-400 text-slate-950 shadow-xs'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {isLocked && <Lock className="w-3 h-3 text-sky-300 shrink-0" />}
                {item.shortcut && (
                  <span
                    className={`text-[9px] font-mono px-1 py-0.2 rounded ${
                      isActive ? 'bg-sky-100 text-sky-800' : 'bg-white/15 text-sky-200'
                    }`}
                  >
                    [{item.shortcut}]
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
