import React from 'react';
import { ActiveModule } from './HeaderNav';
import { usePOS } from '../../context/POSContext';
import { canAccessModule } from '../../utils/permissions';

interface BottomShortcutBarProps {
  activeModule: ActiveModule;
  onSelectModule: (module: ActiveModule) => void;
  onOpenQuickFind?: () => void;
  onOpenScanCamera?: () => void;
  onTriggerCheckout?: () => void;
  onTriggerVoid?: () => void;
  onTriggerPending?: () => void;
}

export const BottomShortcutBar: React.FC<BottomShortcutBarProps> = ({
  activeModule,
  onSelectModule,
  onOpenQuickFind,
  onOpenScanCamera,
  onTriggerCheckout,
  onTriggerVoid,
  onTriggerPending,
}) => {
  const { cart, pendingCarts, currentUser } = usePOS();

  const handleSelectModuleSafe = (mod: ActiveModule) => {
    const access = canAccessModule(currentUser, mod);
    if (!access.allowed) {
      alert(`Akses Ditolak: ${access.reason || 'Anda tidak memiliki hak akses untuk modul ini.'}`);
      return;
    }
    onSelectModule(mod);
  };

  return (
    <>
      {/* DESKTOP / TABLET: F-KEY BUTTONS BAR */}
      <footer className="hidden md:block fixed bottom-0 left-0 right-0 bg-slate-900 border-t-2 border-yellow-400 p-2 z-40 shadow-2xl no-print">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-1.5 overflow-x-auto no-scrollbar">
          {/* F1: Cari Produk */}
          <button
            onClick={() => {
              if (onOpenQuickFind) onOpenQuickFind();
              else handleSelectModuleSafe('PRODUK');
            }}
            className="f-key-btn btn-f-blue"
            title="Pencarian Cepat Produk [F1]"
          >
            <span className="f-tag">F1</span>
            <span>Cari Produk</span>
          </button>

          {/* 📷: Scanner Kamera */}
          <button
            onClick={() => {
              if (onOpenScanCamera) {
                onOpenScanCamera();
              } else {
                handleSelectModuleSafe('KASIR');
              }
            }}
            className="f-key-btn btn-f-green"
            title="Buka Scanner Barcode Kamera HP / Webcam"
          >
            <span className="f-tag">📷</span>
            <span>Kamera</span>
          </button>

          {/* F2: Scan PLU / Kasir */}
          <button
            onClick={() => {
              handleSelectModuleSafe('KASIR');
              const el = document.getElementById('pos-barcode-search');
              el?.focus();
            }}
            className="f-key-btn btn-f-red"
            title="Fokus Scanner Barcode Kasir [F2]"
          >
            <span className="f-tag">F2</span>
            <span>Scan PLU</span>
          </button>

          {/* F3: Retur Struk */}
          <button
            onClick={() => handleSelectModuleSafe('PENJUALAN')}
            className="f-key-btn btn-f-amber"
            title="Retur Barang dengan No. Struk [F3]"
          >
            <span className="f-tag">F3</span>
            <span>Retur Struk</span>
          </button>

          {/* F4: Pending Transaksi */}
          <button
            onClick={() => {
              if (onTriggerPending) {
                onTriggerPending();
              } else {
                if (activeModule !== 'KASIR') {
                  handleSelectModuleSafe('KASIR');
                }
                setTimeout(() => {
                  window.dispatchEvent(new CustomEvent('pos-trigger-pending'));
                }, 50);
              }
            }}
            className="f-key-btn btn-f-slate"
            title="Tunda Transaksi Aktif / Pulihkan [F4]"
          >
            <span className="f-tag">F4</span>
            <span>
              Pending {pendingCarts.length > 0 ? `(${pendingCarts.length})` : ''}
            </span>
          </button>

          {/* F5: Void Item */}
          <button
            onClick={() => {
              if (onTriggerVoid) onTriggerVoid();
            }}
            className="f-key-btn btn-f-red"
            title="Void / Pembatalan Barang [F5]"
          >
            <span className="f-tag">F5</span>
            <span>Void Item</span>
          </button>

          {/* F6: Stock Opname */}
          <button
            onClick={() => handleSelectModuleSafe('STOK')}
            className="f-key-btn btn-f-purple"
            title="Stock Opname Audit Rak Fisik [F6]"
          >
            <span className="f-tag">F6</span>
            <span>SO Toko</span>
          </button>

          {/* F7: Penerimaan LPB Supplier */}
          <button
            onClick={() => handleSelectModuleSafe('PEMBELIAN')}
            className="f-key-btn btn-f-green"
            title="Penerimaan Barang Supplier [F7]"
          >
            <span className="f-tag">F7</span>
            <span>Mutasi LPB</span>
          </button>

          {/* F8: Klerk / Closing Shift */}
          <button
            onClick={() => handleSelectModuleSafe('KARYAWAN')}
            className="f-key-btn btn-f-amber"
            title="Klerk / Closing Shift Kasir [F8]"
          >
            <span className="f-tag">F8</span>
            <span>Klerk Kasir</span>
          </button>

          {/* F9: Laporan Penjualan */}
          <button
            onClick={() => handleSelectModuleSafe('LAPORAN')}
            className="f-key-btn btn-f-indigo"
            title="Laporan Omzet & Keuangan [F9]"
          >
            <span className="f-tag">F9</span>
            <span>Laporan</span>
          </button>

          {/* F12: Bayar Sekarang */}
          <button
            onClick={() => {
              if (cart.length > 0 && onTriggerCheckout) {
                onTriggerCheckout();
              } else {
                handleSelectModuleSafe('KASIR');
              }
            }}
            className="f-key-btn btn-f-emerald ring-2 ring-yellow-400"
            title="Buka Jendela Pembayaran Kasir [F12 / Spasi]"
          >
            <span className="f-tag">F12</span>
            <span>Bayar (Rp)</span>
          </button>
        </div>
      </footer>
    </>
  );
};
