import React, { useState } from 'react';
import {
  Printer,
  Barcode,
  Tv,
  Coins,
  CheckCircle2,
  Play,
  Smartphone,
  Usb,
  Cpu,
} from 'lucide-react';
import { usePOS } from '../../context/POSContext';
import { formatRupiah } from '../../utils/formatters';

export const HardwareView: React.FC = () => {
  const { hardwareSettings, updateHardwareSettings, cartTotal, storeProfile } = usePOS();
  const [testResult, setTestResult] = useState<string | null>(null);

  const handleToggleAutoCut = () => {
    updateHardwareSettings({
      ...hardwareSettings,
      autoCut: !hardwareSettings.autoCut,
    });
  };

  const handleToggleOpenDrawer = () => {
    updateHardwareSettings({
      ...hardwareSettings,
      openDrawerOnCash: !hardwareSettings.openDrawerOnCash,
    });
  };

  const handlePrinterTypeChange = (type: 'THERMAL_58' | 'THERMAL_80') => {
    updateHardwareSettings({
      ...hardwareSettings,
      printerType: type,
      paperWidthMm: type === 'THERMAL_58' ? 58 : 80,
    });
  };

  const handleScannerModeChange = (mode: 'USB_KEYBOARD' | 'CAMERA_HP') => {
    updateHardwareSettings({
      ...hardwareSettings,
      barcodeScannerMode: mode,
    });
  };

  const handleTestPrint = () => {
    setTestResult('Mengirimkan byte ESC/POS ke printer thermal...');
    window.print();
    setTimeout(() => {
      setTestResult('Cetak struk test thermal berhasil dikirim ke dialog printer.');
    }, 1000);
  };

  const handleTestKickDrawer = () => {
    setTestResult('Mengirim sinyal pulse RJ11 (ESC p 0 25 250) ke Cash Drawer...');
    setTimeout(() => {
      setTestResult('Sinyal pulse RJ11 berhasil dikirim: Laci kasir terbuka!');
    }, 800);
  };

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-4 lg:p-6 overflow-y-auto bg-slate-100 text-slate-900 space-y-4 pb-28 md:pb-20">
      <div className="max-w-7xl w-full mx-auto space-y-4">
        {/* Header */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
              <Cpu className="w-6 h-6 text-red-600" />
              <span>Integrasi Perangkat Keras Kasir (Hardware)</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Konfigurasi printer struk thermal (58mm/80mm), barcode scanner laser USB, laci uang (cash drawer RJ11), dan customer display.
            </p>
          </div>
        </div>

        {testResult && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-800 flex items-center gap-2 font-bold shadow-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{testResult}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* 1. PRINTER THERMAL */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <Printer className="w-4 h-4 text-red-600" />
                <span>1. Printer Struk Thermal (ESC/POS)</span>
              </h3>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-bold">
                Siap Digunakan
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-bold mb-1.5 block">Ukuran Kertas Thermal</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handlePrinterTypeChange('THERMAL_58')}
                    className={`py-2.5 px-3 rounded-xl border font-bold text-center transition cursor-pointer ${
                      hardwareSettings.printerType === 'THERMAL_58'
                        ? 'bg-red-600 text-white border-red-600 shadow-xs'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Thermal 58 mm (Standar)
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePrinterTypeChange('THERMAL_80')}
                    className={`py-2.5 px-3 rounded-xl border font-bold text-center transition cursor-pointer ${
                      hardwareSettings.printerType === 'THERMAL_80'
                        ? 'bg-red-600 text-white border-red-600 shadow-xs'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Thermal 80 mm (Lebar)
                  </button>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-800 block">Auto Cut Kertas Thermal</span>
                    <span className="text-[11px] text-slate-500">
                      Kirim perintah pemotong kertas otomatis (GS V 66 0) setelah struk selesai dicetak
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={hardwareSettings.autoCut}
                    onChange={handleToggleAutoCut}
                    className="w-4 h-4 accent-red-600 rounded cursor-pointer"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold mb-1 block">
                  Paket Android Print Driver (RawBT Intent)
                </label>
                <input
                  type="text"
                  value={hardwareSettings.rawbtPackage}
                  onChange={e => updateHardwareSettings({ ...hardwareSettings, rawbtPackage: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Gunakan <code className="text-blue-700 font-bold">ru.a402d.rawbtprinter</code> untuk koneksi Bluetooth HP/Tablet Android.
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleTestPrint}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-xs rounded-xl border border-slate-300 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 text-red-600" />
                  <span>Test Print Struk 58/80mm</span>
                </button>
              </div>
            </div>
          </div>

          {/* 2. BARCODE SCANNER */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <Barcode className="w-4 h-4 text-blue-700" />
                <span>2. Barcode Scanner (1D & 2D QR Code)</span>
              </h3>
              <span className="text-[10px] px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full font-bold">
                Terhubung USB
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-bold mb-1.5 block">Mode Pemindaian Barcode Utama</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleScannerModeChange('USB_KEYBOARD')}
                    className={`py-2.5 px-3 rounded-xl border font-bold text-center transition flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      hardwareSettings.barcodeScannerMode === 'USB_KEYBOARD'
                        ? 'bg-blue-700 text-white border-blue-700 shadow-xs'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Usb className="w-4 h-4" />
                    <span>Scanner USB / Laser Gun</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleScannerModeChange('CAMERA_HP')}
                    className={`py-2.5 px-3 rounded-xl border font-bold text-center transition flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      hardwareSettings.barcodeScannerMode === 'CAMERA_HP'
                        ? 'bg-blue-700 text-white border-blue-700 shadow-xs'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Kamera HP / Webcam</span>
                  </button>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-slate-700">
                <p className="font-bold text-slate-900">Panduan Scanner Barcode USB:</p>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Scanner pistol USB bekerja dengan mode <strong>Keyboard Wedge (HID)</strong> secara instan tanpa driver. Setiap produk yang di-scan langsung otomatis mengisi input kasir dan menekan Enter.
                </p>
              </div>
            </div>
          </div>

          {/* 3. LACI UANG KASIR (CASH DRAWER) */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-600" />
                <span>3. Laci Uang Kasir (Cash Drawer RJ11)</span>
              </h3>
              <span className="text-[10px] px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full font-bold">
                RJ-11 Port
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-800 block">Buka Laci Otomatis Saat Bayar Tunai</span>
                    <span className="text-[11px] text-slate-500">
                      Mengirim pulsa ke kabel RJ11 printer thermal agar laci membuka secara otomatis saat transaksi selesai
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={hardwareSettings.openDrawerOnCash}
                    onChange={handleToggleOpenDrawer}
                    className="w-4 h-4 accent-amber-600 rounded cursor-pointer"
                  />
                </div>
              </div>

              <button
                onClick={handleTestKickDrawer}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-xs rounded-xl border border-slate-300 flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 text-amber-600" />
                <span>Test Buka Laci Kasir (Kick Drawer)</span>
              </button>
            </div>
          </div>

          {/* 4. CUSTOMER DISPLAY (POLE DISPLAY / DUAL MONITOR) */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                <Tv className="w-4 h-4 text-purple-700" />
                <span>4. Customer Display / Layar Pembeli</span>
              </h3>
              <span className="text-[10px] px-2 py-0.5 bg-purple-100 text-purple-800 rounded-full font-bold">
                Dual Monitor
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600">
                Pratinjau tampilan layar kedua (pole display atau monitor kedua menghadap pelanggan):
              </p>

              {/* Simulated Customer Screen */}
              <div className="bg-slate-900 border-2 border-slate-800 rounded-2xl p-5 text-center space-y-2 shadow-inner">
                <span className="text-[10px] text-yellow-400 uppercase tracking-widest block font-black">
                  {storeProfile.name} • LAYAR PELANGGAN
                </span>
                <p className="text-xs text-slate-300 font-medium">TOTAL BELANJA ANDA:</p>
                <div className="text-3xl font-black font-mono text-yellow-400 tracking-tight">
                  {formatRupiah(cartTotal)}
                </div>
                <p className="text-[11px] text-slate-400 italic">Terima kasih telah berbelanja di minimarket kami!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
