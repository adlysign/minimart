import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  CartItem,
  CashierShift,
  Category,
  CustomerMember,
  HardwareSettings,
  InventoryLog,
  LicenseInfo,
  PendingCart,
  Product,
  PurchaseOrder,
  RepackingRecord,
  SaleTransaction,
  SalesReturn,
  StockOpnameSession,
  StoreProfile,
  Supplier,
  User,
  PiutangRecord,
  BankAccount,
  PaymentSettings,
  QRISSettings,
  MemberPointSettings,
  LanDeviceRole,
  LanSyncStatus,
  LanSyncLog,
  LanEventType,
  LanConnectedClient,
} from '../types/pos';
import {
  INITIAL_CATEGORIES,
  INITIAL_CUSTOMERS,
  INITIAL_HARDWARE_SETTINGS,
  INITIAL_LICENSE,
  INITIAL_PRODUCTS,
  INITIAL_STORE_PROFILE,
  INITIAL_SUPPLIERS,
  INITIAL_USERS,
  INITIAL_PIUTANG,
  INITIAL_PAYMENT_SETTINGS,
  INITIAL_MEMBER_POINT_SETTINGS,
} from '../data/initialData';

interface POSContextType {
  // Authentication & Users
  isAuthenticated: boolean;
  currentUser: User;
  users: User[];
  setCurrentUser: (user: User) => void;
  login: (userIdOrUsername: string, pin: string) => { success: boolean; user?: User; message?: string };
  logout: () => void;
  verifyPin: (pin: string, requiredRoleOrPermission?: User['role'] | keyof User['permissions']) => { success: boolean; user?: User; message?: string };
  addUser: (user: User) => void;
  updateUser: (user: User) => void;
  updateMultipleUsers: (updatedUsers: User[]) => void;
  deleteUser: (id: string) => void;
  deleteAllStaff: (keepOwner?: boolean) => void;

  // Shift Management
  activeShift: CashierShift | null;
  startShift: (initialCash: number, shiftName: string) => void;
  closeShift: (actualDrawerCash: number, notes?: string) => CashierShift;
  shiftHistory: CashierShift[];

  // Master Data
  products: Product[];
  categories: Category[];
  suppliers: Supplier[];
  customers: CustomerMember[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  addCategory: (name: string) => void;
  addSupplier: (supplier: Omit<Supplier, 'id'>) => void;
  addCustomer: (customer: Omit<CustomerMember, 'id' | 'points' | 'totalSpent'>) => void;
  updateCustomer: (customer: CustomerMember) => void;
  deleteCustomer: (id: string) => void;

  // Cart & POS Cashier
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQty: (productId: string, delta: number) => void;
  setCartQtyDirect: (productId: string, quantity: number) => void;
  setCartItemDiscount: (productId: string, type: 'PERCENT' | 'NOMINAL', value: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  selectedCustomer: CustomerMember | null;
  setSelectedCustomer: (cust: CustomerMember | null) => void;
  transactionDiscount: number;
  setTransactionDiscount: (amount: number) => void;
  cartSubtotal: number;
  cartTotal: number;

  // Hold / Pending Transactions
  pendingCarts: PendingCart[];
  holdCurrentCart: (name?: string, notes?: string) => void;
  autoHoldCart: (reasonName: string, detailNotes: string) => void;
  resumePendingCart: (id: string) => void;
  removePendingCart: (id: string) => void;

  // Checkout & Transactions
  sales: SaleTransaction[];
  completeCheckout: (paymentMethod: SaleTransaction['paymentMethod'], cashReceived: number, details?: SaleTransaction['paymentDetails']) => SaleTransaction;
  voidTransaction: (invoiceNumber: string, reason: string, supervisorPin: string) => { success: boolean; message: string };
  reprintTransaction: SaleTransaction | null;
  setReprintTransaction: (tx: SaleTransaction | null) => void;

  // Returns & Refunds
  returns: SalesReturn[];
  processSalesReturn: (saleInvoice: string, items: { productId: string; quantity: number; refundPrice: number }[], reason: string, supervisorPin: string) => { success: boolean; message: string };

  // Piutang (Accounts Receivable)
  piutangList: PiutangRecord[];
  addPiutangPayment: (piutangId: string, amount: number, method: 'TUNAI' | 'TRANSFER', notes?: string) => { success: boolean; message: string };
  createDirectPiutang: (params: {
    customerId?: string;
    customerName: string;
    customerPhone?: string;
    totalAmount: number;
    downPayment?: number;
    dueDate: string;
    notes?: string;
  }) => PiutangRecord;
  updatePiutangStatus: (piutangId: string, status: PiutangRecord['status']) => void;

  // Inventory Management
  stockLogs: InventoryLog[];
  adjustStock: (productId: string, type: InventoryLog['type'], qtyChange: number, notes?: string, refDoc?: string) => void;
  purchases: PurchaseOrder[];
  addPurchaseOrder: (po: Omit<PurchaseOrder, 'id' | 'createdAt'>) => void;
  stockOpnameSessions: StockOpnameSession[];
  commitStockOpname: (opname: Omit<StockOpnameSession, 'id'>) => void;
  repackRecords: RepackingRecord[];
  executeRepack: (sourceProductId: string, sourceQty: number, targetProductId: string, targetQty: number, notes?: string) => void;

  // Settings, Hardware & License
  storeProfile: StoreProfile;
  updateStoreProfile: (profile: StoreProfile) => void;
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: PaymentSettings) => void;
  updateQRISSettings: (qris: Partial<QRISSettings>) => void;
  addBankAccount: (account: Omit<BankAccount, 'id'>) => void;
  updateBankAccount: (account: BankAccount) => void;
  deleteBankAccount: (id: string) => void;
  memberPointSettings: MemberPointSettings;
  updateMemberPointSettings: (settings: Partial<MemberPointSettings>) => void;
  hardwareSettings: HardwareSettings;
  updateHardwareSettings: (settings: HardwareSettings) => void;
  license: LicenseInfo;
  activateLicenseKey: (key: string) => { success: boolean; message: string };
  generateCustomLicense: (storeName: string, plan: LicenseInfo['plan'], maxDevices: number) => string;

  // Cloud Sync & Backup/Restore
  cloudSyncStatus: { lastSynced: string | null; isSyncing: boolean; supabaseConnected: boolean };
  triggerSync: () => Promise<void>;
  exportDatabaseJson: () => void;
  importDatabaseJson: (jsonData: string) => boolean;
  resetToSampleData: () => void;

  // Jaringan Lokal (LAN) Auto-Sync Realtime
  lanSyncStatus: LanSyncStatus;
  updateLanSettings: (settings: { role?: LanDeviceRole; terminalName?: string; serverUrl?: string; autoSync?: boolean }) => void;
  triggerLanSyncNow: () => Promise<void>;
  broadcastLanTestSignal: (message?: string) => void;
  pushFullDbToLan: () => Promise<void>;
  pullFullDbFromLan: () => Promise<void>;
  clearLanLogs: () => void;
  lanRecentEventNotification: string | null;
  dismissLanNotification: () => void;
}

const POSContext = createContext<POSContextType | undefined>(undefined);

export const POSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state with LocalStorage persistence fallback
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('pos_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('pos_is_authenticated') === 'true';
    } catch {
      return false;
    }
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const savedUserId =
        sessionStorage.getItem('pos_current_user_id') ||
        localStorage.getItem('pos_current_user_id');
      if (savedUserId) {
        const found = users.find(u => u.id === savedUserId);
        if (found) return found;
      }
    } catch {
      // fallback
    }
    return users.find(u => u.role === 'KASIR') || users[0];
  });

  const [shiftHistory, setShiftHistory] = useState<CashierShift[]>(() => {
    const saved = localStorage.getItem('pos_shifts');
    return saved ? JSON.parse(saved) : [];
  });

  const [activeShift, setActiveShift] = useState<CashierShift | null>(() => {
    try {
      const saved = localStorage.getItem('pos_active_shift');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    // Wajib buka shift kasir sebelum bertransaksi
    return null;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('pos_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('pos_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem('pos_suppliers');
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIERS;
  });

  const [customers, setCustomers] = useState<CustomerMember[]>(() => {
    const saved = localStorage.getItem('pos_customers');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('pos_active_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerMember | null>(() => {
    try {
      const saved = localStorage.getItem('pos_selected_customer');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [transactionDiscount, setTransactionDiscount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('pos_transaction_discount');
      return saved ? Number(saved) : 0;
    } catch {
      return 0;
    }
  });
  const [pendingCarts, setPendingCarts] = useState<PendingCart[]>(() => {
    const saved = localStorage.getItem('pos_pending_carts');
    return saved ? JSON.parse(saved) : [];
  });

  const [sales, setSales] = useState<SaleTransaction[]>(() => {
    const saved = localStorage.getItem('pos_sales');
    if (saved) return JSON.parse(saved);
    // Seed 2 realistic previous transactions for instant analytics & reports
    return [
      {
        id: 'sale-1',
        invoiceNumber: 'INV-20260917-0001',
        cashierId: 'usr-kasir-1',
        cashierName: 'Ayu Kartika (Kasir 1)',
        shiftId: 'shift-prev',
        customerId: 'cust-1',
        customerName: 'Ibu Ratna Sari',
        items: [
          {
            id: 'ci-1',
            productId: 'prod-1',
            barcode: '8998866200225',
            sku: 'SNK-001',
            name: 'Indomie Goreng Spesial 85g',
            unit: 'Pcs',
            costPrice: 2800,
            sellingPrice: 3500,
            quantity: 5,
            discountType: 'NOMINAL',
            discountValue: 0,
            subtotal: 17500,
          },
          {
            id: 'ci-2',
            productId: 'prod-3',
            barcode: '8999999014562',
            sku: 'BEV-001',
            name: 'Le Minerale Air Mineral 600ml',
            unit: 'Botol',
            costPrice: 2400,
            sellingPrice: 3500,
            quantity: 2,
            discountType: 'NOMINAL',
            discountValue: 0,
            subtotal: 7000,
          },
        ],
        subtotal: 24500,
        transactionDiscount: 1225, // 5% member
        totalAmount: 23275,
        totalCost: 18800,
        grossProfit: 4475,
        paymentMethod: 'TUNAI',
        cashReceived: 50000,
        changeDue: 26725,
        status: 'COMPLETED',
        createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
      },
      {
        id: 'sale-2',
        invoiceNumber: 'INV-20260917-0002',
        cashierId: 'usr-kasir-1',
        cashierName: 'Ayu Kartika (Kasir 1)',
        shiftId: 'shift-prev',
        items: [
          {
            id: 'ci-3',
            productId: 'prod-6',
            barcode: '8992388110291',
            sku: 'SMB-001',
            name: 'Bimoli Minyak Goreng Pouch 2 Liter',
            unit: 'Pouch',
            costPrice: 34000,
            sellingPrice: 38500,
            quantity: 2,
            discountType: 'NOMINAL',
            discountValue: 0,
            subtotal: 77000,
          },
        ],
        subtotal: 77000,
        transactionDiscount: 0,
        totalAmount: 77000,
        totalCost: 68000,
        grossProfit: 9000,
        paymentMethod: 'QRIS',
        cashReceived: 77000,
        changeDue: 0,
        status: 'COMPLETED',
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      },
    ];
  });

  const [returns, setReturns] = useState<SalesReturn[]>(() => {
    const saved = localStorage.getItem('pos_returns');
    return saved ? JSON.parse(saved) : [];
  });

  const [stockLogs, setStockLogs] = useState<InventoryLog[]>(() => {
    const saved = localStorage.getItem('pos_stock_logs');
    return saved ? JSON.parse(saved) : [];
  });

  const [purchases, setPurchases] = useState<PurchaseOrder[]>(() => {
    const saved = localStorage.getItem('pos_purchases');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'po-1',
        invoiceNumber: 'FAK-IDF-9921',
        supplierId: 'sup-1',
        supplierName: 'PT Indofood Sukses Makmur',
        purchaseDate: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
        paymentStatus: 'LUNAS',
        items: [
          { productId: 'prod-1', productName: 'Indomie Goreng Spesial 85g', quantity: 100, unitCost: 2800, subtotal: 280000 },
          { productId: 'prod-2', productName: 'Indomie Kuah Ayam Bawang 69g', quantity: 80, unitCost: 2750, subtotal: 220000 },
        ],
        totalAmount: 500000,
        receivedBy: 'Siti Rahma (Admin)',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      },
    ];
  });

  const [stockOpnameSessions, setStockOpnameSessions] = useState<StockOpnameSession[]>(() => {
    const saved = localStorage.getItem('pos_opnames');
    return saved ? JSON.parse(saved) : [];
  });

  const [repackRecords, setRepackRecords] = useState<RepackingRecord[]>(() => {
    const saved = localStorage.getItem('pos_repacks');
    return saved ? JSON.parse(saved) : [];
  });

  const [storeProfile, setStoreProfile] = useState<StoreProfile>(() => {
    const saved = localStorage.getItem('pos_store_profile');
    return saved ? JSON.parse(saved) : INITIAL_STORE_PROFILE;
  });

  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    try {
      const saved = localStorage.getItem('pos_payment_settings');
      return saved ? JSON.parse(saved) : INITIAL_PAYMENT_SETTINGS;
    } catch {
      return INITIAL_PAYMENT_SETTINGS;
    }
  });

  const [memberPointSettings, setMemberPointSettings] = useState<MemberPointSettings>(() => {
    try {
      const saved = localStorage.getItem('pos_member_point_settings');
      return saved ? { ...INITIAL_MEMBER_POINT_SETTINGS, ...JSON.parse(saved) } : INITIAL_MEMBER_POINT_SETTINGS;
    } catch {
      return INITIAL_MEMBER_POINT_SETTINGS;
    }
  });

  const [hardwareSettings, setHardwareSettings] = useState<HardwareSettings>(() => {
    const saved = localStorage.getItem('pos_hardware');
    return saved ? JSON.parse(saved) : INITIAL_HARDWARE_SETTINGS;
  });

  const [license, setLicense] = useState<LicenseInfo>(() => {
    const saved = localStorage.getItem('pos_license');
    return saved ? JSON.parse(saved) : INITIAL_LICENSE;
  });

  const [piutangList, setPiutangList] = useState<PiutangRecord[]>(() => {
    try {
      const saved = localStorage.getItem('pos_piutang_records');
      return saved ? JSON.parse(saved) : INITIAL_PIUTANG;
    } catch {
      return INITIAL_PIUTANG;
    }
  });

  const [reprintTransaction, setReprintTransaction] = useState<SaleTransaction | null>(null);

  const [cloudSyncStatus, setCloudSyncStatus] = useState({
    lastSynced: new Date().toLocaleTimeString('id-ID'),
    isSyncing: false,
    supabaseConnected: true,
  });

  // Persistent storage sync
  useEffect(() => {
    localStorage.setItem('pos_users', JSON.stringify(users));
  }, [users]);
  useEffect(() => {
    localStorage.setItem('pos_products', JSON.stringify(products));
  }, [products]);
  useEffect(() => {
    localStorage.setItem('pos_categories', JSON.stringify(categories));
  }, [categories]);
  useEffect(() => {
    localStorage.setItem('pos_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);
  useEffect(() => {
    localStorage.setItem('pos_customers', JSON.stringify(customers));
  }, [customers]);
  useEffect(() => {
    localStorage.setItem('pos_sales', JSON.stringify(sales));
  }, [sales]);
  useEffect(() => {
    localStorage.setItem('pos_returns', JSON.stringify(returns));
  }, [returns]);
  useEffect(() => {
    localStorage.setItem('pos_piutang_records', JSON.stringify(piutangList));
  }, [piutangList]);
  useEffect(() => {
    localStorage.setItem('pos_stock_logs', JSON.stringify(stockLogs));
  }, [stockLogs]);
  useEffect(() => {
    localStorage.setItem('pos_purchases', JSON.stringify(purchases));
  }, [purchases]);
  useEffect(() => {
    localStorage.setItem('pos_opnames', JSON.stringify(stockOpnameSessions));
  }, [stockOpnameSessions]);
  useEffect(() => {
    localStorage.setItem('pos_repacks', JSON.stringify(repackRecords));
  }, [repackRecords]);
  useEffect(() => {
    localStorage.setItem('pos_shifts', JSON.stringify(shiftHistory));
  }, [shiftHistory]);
  useEffect(() => {
    if (activeShift) {
      localStorage.setItem('pos_active_shift', JSON.stringify(activeShift));
    } else {
      localStorage.removeItem('pos_active_shift');
    }
  }, [activeShift]);
  useEffect(() => {
    localStorage.setItem('pos_pending_carts', JSON.stringify(pendingCarts));
  }, [pendingCarts]);
  useEffect(() => {
    localStorage.setItem('pos_store_profile', JSON.stringify(storeProfile));
  }, [storeProfile]);
  useEffect(() => {
    localStorage.setItem('pos_payment_settings', JSON.stringify(paymentSettings));
  }, [paymentSettings]);
  useEffect(() => {
    localStorage.setItem('pos_member_point_settings', JSON.stringify(memberPointSettings));
  }, [memberPointSettings]);
  useEffect(() => {
    localStorage.setItem('pos_hardware', JSON.stringify(hardwareSettings));
  }, [hardwareSettings]);
  useEffect(() => {
    localStorage.setItem('pos_license', JSON.stringify(license));
  }, [license]);
  useEffect(() => {
    try {
      localStorage.setItem('pos_active_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Failed to save cart to localStorage', e);
    }
  }, [cart]);
  useEffect(() => {
    try {
      if (selectedCustomer) {
        localStorage.setItem('pos_selected_customer', JSON.stringify(selectedCustomer));
      } else {
        localStorage.removeItem('pos_selected_customer');
      }
    } catch (e) {
      console.warn('Failed to save selectedCustomer to localStorage', e);
    }
  }, [selectedCustomer]);
  useEffect(() => {
    try {
      localStorage.setItem('pos_transaction_discount', String(transactionDiscount));
    } catch (e) {
      console.warn('Failed to save transactionDiscount to localStorage', e);
    }
  }, [transactionDiscount]);

  useEffect(() => {
    try {
      localStorage.setItem('pos_pending_carts', JSON.stringify(pendingCarts));
    } catch (e) {
      console.warn('Failed to save pendingCarts to localStorage', e);
    }
  }, [pendingCarts]);

  useEffect(() => {
    try {
      if (currentUser?.id) {
        sessionStorage.setItem('pos_current_user_id', currentUser.id);
        localStorage.setItem('pos_current_user_id', currentUser.id);
      }
    } catch (e) {
      console.warn('Failed to save currentUser id', e);
    }
  }, [currentUser]);

  // ================= LAN REALTIME AUTO-SYNC STATE =================
  const [lanDeviceId] = useState<string>(() => {
    try {
      let id = localStorage.getItem('pos_lan_device_id');
      if (!id) {
        id = `TERM-${Math.floor(100 + Math.random() * 900)}`;
        localStorage.setItem('pos_lan_device_id', id);
      }
      return id;
    } catch {
      return 'TERM-001';
    }
  });

  const [lanTerminalName, setLanTerminalName] = useState<string>(() => {
    try {
      return localStorage.getItem('pos_lan_terminal_name') || 'Kasir 01 (Utama)';
    } catch {
      return 'Kasir 01 (Utama)';
    }
  });

  const [lanRole, setLanRole] = useState<LanDeviceRole>(() => {
    try {
      return (localStorage.getItem('pos_lan_role') as LanDeviceRole) || 'SERVER_MASTER';
    } catch {
      return 'SERVER_MASTER';
    }
  });

  const [lanAutoSync, setLanAutoSync] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pos_lan_auto_sync');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [lanServerUrl, setLanServerUrl] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('pos_lan_server_url');
      if (saved) return saved;
    } catch {}
    const protocol = typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = typeof window !== 'undefined' ? window.location.host : 'localhost:3000';
    return `${protocol}//${host}/api/ws/lan-sync`;
  });

  const [lanConnected, setLanConnected] = useState(false);
  const [lanIsSyncing, setLanIsSyncing] = useState(false);
  const [lanLastSyncTime, setLanLastSyncTime] = useState<string | null>(null);
  const [lanDetectedIps, setLanDetectedIps] = useState<string[]>([]);
  const [lanConnectedClients, setLanConnectedClients] = useState<LanConnectedClient[]>([]);
  const [lanActivityLogs, setLanActivityLogs] = useState<LanSyncLog[]>([]);
  const [lanRecentEventNotification, setLanRecentEventNotification] = useState<string | null>(null);
  const [lanLocalVersion, setLanLocalVersion] = useState<number>(1);

  const lanSocketRef = useRef<WebSocket | null>(null);
  const processedEventIds = useRef<Set<string>>(new Set());

  const addLanLog = (
    type: LanSyncLog['type'],
    eventTitle: string,
    sourceTerminal: string,
    status: LanSyncLog['status'],
    details?: string
  ) => {
    const newLog: LanSyncLog = {
      id: `lanlog-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toLocaleTimeString('id-ID'),
      type,
      eventTitle,
      sourceTerminal,
      status,
      details,
    };
    setLanActivityLogs(prev => [newLog, ...prev.slice(0, 49)]);
  };

  const broadcastLanEvent = (eventType: LanEventType, payload: any) => {
    if (!lanAutoSync && eventType !== 'TEST_SIGNAL') return;
    const eventId = `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    processedEventIds.current.add(eventId);

    const msg = {
      type: 'BROADCAST_EVENT',
      eventId,
      eventType,
      payload,
      sourceDeviceId: lanDeviceId,
      sourceTerminalName: lanTerminalName,
      timestamp: new Date().toISOString(),
    };

    if (lanSocketRef.current && lanSocketRef.current.readyState === WebSocket.OPEN) {
      lanSocketRef.current.send(JSON.stringify(msg));
      addLanLog('EVENT_OUT', `Broadcast ${eventType}`, lanTerminalName, 'SUCCESS', 'Terkirim ke server LAN');
    } else {
      fetch('/api/lan/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventType,
          payload,
          sourceDeviceId: lanDeviceId,
          sourceTerminalName: lanTerminalName,
        }),
      }).catch(e => console.warn('LAN HTTP broadcast failed:', e));
    }
  };

  const handleIncomingLanMessage = (data: any) => {
    switch (data.type) {
      case 'REGISTER_SUCCESS':
        setLanLocalVersion(data.serverVersion || 1);
        if (Array.isArray(data.localIps)) {
          setLanDetectedIps(data.localIps);
        }
        setLanLastSyncTime(new Date().toISOString());
        break;

      case 'CLIENT_LIST_UPDATE':
        if (Array.isArray(data.clients)) {
          setLanConnectedClients(data.clients);
        }
        break;

      case 'HEARTBEAT_ACK':
        break;

      case 'REALTIME_EVENT': {
        const { eventId, eventType, payload, sourceDeviceId, sourceTerminalName, version } = data;
        if (sourceDeviceId === lanDeviceId) return;
        if (processedEventIds.current.has(eventId)) return;
        processedEventIds.current.add(eventId);

        if (version) {
          setLanLocalVersion(version);
        } else {
          setLanLocalVersion(v => v + 1);
        }
        setLanLastSyncTime(new Date().toISOString());

        if (eventType === 'TRANSACTION_CREATED' && payload?.sale) {
          const incomingSale: SaleTransaction = payload.sale;
          setSales(prev => {
            if (prev.some(s => s.id === incomingSale.id || s.invoiceNumber === incomingSale.invoiceNumber)) {
              return prev;
            }
            return [incomingSale, ...prev];
          });

          if (Array.isArray(incomingSale.items)) {
            setProducts(prev => {
              const map = new Map(prev.map(p => [p.id, p]));
              incomingSale.items.forEach(item => {
                const existing = map.get(item.productId);
                if (existing) {
                  const newStock = Math.max(0, existing.stock - item.quantity);
                  map.set(item.productId, { ...existing, stock: newStock });
                }
              });
              return Array.from(map.values());
            });
          }

          const msg = `🛒 Transaksi baru dari [${sourceTerminalName}]: ${incomingSale.invoiceNumber} (Rp ${incomingSale.totalAmount.toLocaleString('id-ID')})`;
          setLanRecentEventNotification(msg);
          addLanLog('EVENT_IN', 'Penjualan Baru Masuk', sourceTerminalName, 'SUCCESS', `${incomingSale.invoiceNumber} - Rp ${incomingSale.totalAmount.toLocaleString('id-ID')}`);
        } else if (eventType === 'PRODUCT_UPDATED' && payload?.product) {
          const p = payload.product;
          setProducts(prev => {
            const idx = prev.findIndex(item => item.id === p.id);
            if (idx >= 0) {
              const copy = [...prev];
              copy[idx] = p;
              return copy;
            } else {
              return [p, ...prev];
            }
          });
          const msg = `📦 Produk diperbarui dari [${sourceTerminalName}]: ${p.name}`;
          setLanRecentEventNotification(msg);
          addLanLog('EVENT_IN', 'Pembaruan Produk', sourceTerminalName, 'INFO', `${p.name} - Stok: ${p.stock}`);
        } else if (eventType === 'STOCK_ADJUSTED' && payload) {
          if (payload.productId && typeof payload.qtyChange === 'number') {
            setProducts(prev =>
              prev.map(prod =>
                prod.id === payload.productId ? { ...prod, stock: Math.max(0, prod.stock + payload.qtyChange) } : prod
              )
            );
          }
          addLanLog('EVENT_IN', 'Penyesuaian Stok', sourceTerminalName, 'INFO', `Qty: ${payload.qtyChange}`);
        } else if (eventType === 'PIUTANG_UPDATED' && payload?.updatedPiutang) {
          setPiutangList(prev => prev.map(pi => (pi.id === payload.updatedPiutang.id ? payload.updatedPiutang : pi)));
          addLanLog('EVENT_IN', 'Sinkronisasi Piutang', sourceTerminalName, 'INFO', `Invoice: ${payload.updatedPiutang.invoiceNumber}`);
        } else if (eventType === 'CUSTOMER_UPDATED' && payload?.customer) {
          setCustomers(prev => prev.map(c => (c.id === payload.customer.id ? payload.customer : c)));
          addLanLog('EVENT_IN', 'Sinkronisasi Pelanggan', sourceTerminalName, 'INFO', payload.customer.name);
        } else if (eventType === 'TEST_SIGNAL') {
          const msg = `🔔 Uji Sinyal LAN dari [${sourceTerminalName}]: ${payload?.message || 'Koneksi Stabil'}`;
          setLanRecentEventNotification(msg);
          addLanLog('EVENT_IN', 'Uji Sinyal Kasir', sourceTerminalName, 'INFO', payload?.message || 'Ping Sukses');
        }
        break;
      }

      case 'FULL_STATE_UPDATED': {
        const payload = data.payload;
        if (payload) {
          if (Array.isArray(payload.products)) setProducts(payload.products);
          if (Array.isArray(payload.sales)) setSales(payload.sales);
          if (Array.isArray(payload.customers)) setCustomers(payload.customers);
          if (Array.isArray(payload.categories)) setCategories(payload.categories);
          if (Array.isArray(payload.suppliers)) setSuppliers(payload.suppliers);
          if (Array.isArray(payload.piutangList)) setPiutangList(payload.piutangList);
          if (Array.isArray(payload.stockLogs)) setStockLogs(payload.stockLogs);
          if (payload.storeProfile) setStoreProfile(payload.storeProfile);
        }
        setLanLocalVersion(data.version || 1);
        setLanLastSyncTime(new Date().toISOString());
        const msg = `🔄 Database lengkap disinkronkan dari [${data.updatedBy || 'Server Master'}]`;
        setLanRecentEventNotification(msg);
        addLanLog('FULL_SYNC', 'Sinkronisasi Database Penuh', data.updatedBy || 'Server', 'SUCCESS', 'Data produk, stok, dan transaksi diperbarui');
        break;
      }

      default:
        break;
    }
  };

  useEffect(() => {
    if (!lanAutoSync) {
      if (lanSocketRef.current) {
        lanSocketRef.current.close();
        lanSocketRef.current = null;
      }
      setLanConnected(false);
      return;
    }

    let ws: WebSocket | null = null;
    let reconnectTimer: any = null;
    let heartbeatTimer: any = null;
    let isUnmounted = false;

    const connect = () => {
      if (isUnmounted) return;
      try {
        let targetUrl = lanServerUrl;
        if (!targetUrl.startsWith('ws://') && !targetUrl.startsWith('wss://')) {
          const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
          targetUrl = `${protocol}//${targetUrl}`;
        }

        ws = new WebSocket(targetUrl);
        lanSocketRef.current = ws;

        ws.onopen = () => {
          if (isUnmounted) return;
          setLanConnected(true);
          addLanLog('CONNECT', 'Terhubung ke Jaringan LAN', lanTerminalName, 'SUCCESS', `Server: ${targetUrl}`);

          ws?.send(
            JSON.stringify({
              type: 'REGISTER_TERMINAL',
              deviceId: lanDeviceId,
              terminalName: lanTerminalName,
              role: lanRole,
            })
          );

          heartbeatTimer = setInterval(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'HEARTBEAT' }));
            }
          }, 15000);
        };

        ws.onmessage = event => {
          if (isUnmounted) return;
          try {
            const data = JSON.parse(event.data);
            handleIncomingLanMessage(data);
          } catch (e) {
            console.error('Error parsing LAN WS message:', e);
          }
        };

        ws.onclose = () => {
          if (isUnmounted) return;
          setLanConnected(false);
          clearInterval(heartbeatTimer);
          reconnectTimer = setTimeout(connect, 3000);
        };

        ws.onerror = () => {
          if (isUnmounted) return;
          setLanConnected(false);
        };
      } catch (err) {
        console.warn('Failed to establish LAN WebSocket connection:', err);
        reconnectTimer = setTimeout(connect, 4000);
      }
    };

    connect();

    return () => {
      isUnmounted = true;
      clearTimeout(reconnectTimer);
      clearInterval(heartbeatTimer);
      if (ws) {
        ws.close();
      }
      lanSocketRef.current = null;
    };
  }, [lanAutoSync, lanServerUrl, lanDeviceId, lanTerminalName, lanRole]);


  // Synchronous references for auto-pending safety during unmount / logout / switch
  const cartRef = useRef(cart);
  const selectedCustRef = useRef(selectedCustomer);
  const currentUserRef = useRef(currentUser);

  useEffect(() => {
    cartRef.current = cart;
  }, [cart]);
  useEffect(() => {
    selectedCustRef.current = selectedCustomer;
  }, [selectedCustomer]);
  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);

  // Auto-pending when application closes abruptly / refreshed / tab closed
  useEffect(() => {
    const handleBeforeUnload = () => {
      const activeItems = cartRef.current;
      if (activeItems && activeItems.length > 0) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
        const cashierName = currentUserRef.current?.name || 'Kasir';
        const pendingItem: PendingCart = {
          id: 'pending-crash-' + Date.now(),
          name: `[Auto-Pending] Aplikasi Berhenti (${cashierName})`,
          label: `Aplikasi Berhenti (${cashierName})`,
          items: [...activeItems],
          customer: selectedCustRef.current || undefined,
          createdAt: now.toISOString(),
          notes: `Otomatis disimpan sistem: Aplikasi browser ditutup, refresh, atau berhenti tiba-tiba saat kasir ${cashierName} aktif pada pukul ${timeStr}.`,
          createdByCashier: cashierName,
        };

        try {
          const raw = localStorage.getItem('pos_pending_carts');
          const existingPending: PendingCart[] = raw ? JSON.parse(raw) : [];
          const updated = [pendingItem, ...existingPending];
          localStorage.setItem('pos_pending_carts', JSON.stringify(updated));
          localStorage.removeItem('pos_active_cart');
          localStorage.removeItem('pos_selected_customer');
          localStorage.removeItem('pos_transaction_discount');
        } catch (e) {
          console.error('Failed to auto-pending on beforeunload', e);
        }
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // Keep currentUser data and permissions in continuous sync with users array
  useEffect(() => {
    const freshUser = users.find(u => u.id === currentUser.id);
    if (freshUser) {
      const permsChanged =
        JSON.stringify(freshUser.permissions) !== JSON.stringify(currentUser.permissions);
      const roleChanged = freshUser.role !== currentUser.role;
      const statusChanged = freshUser.isActive !== currentUser.isActive;
      const nameChanged = freshUser.name !== currentUser.name;
      if (permsChanged || roleChanged || statusChanged || nameChanged) {
        setCurrentUser(freshUser);
      }
    }
  }, [users, currentUser]);

  // Auth & Pin
  const verifyPin = (
    pin: string,
    requiredRoleOrPermission?: User['role'] | keyof User['permissions']
  ) => {
    const user = users.find(u => u.pin === pin && u.isActive !== false);
    if (!user) {
      return { success: false, message: 'PIN salah atau pengguna tidak aktif' };
    }
    if (requiredRoleOrPermission) {
      // Owner always has full access
      if (user.role === 'OWNER') {
        return { success: true, user };
      }

      // Check if requiredRoleOrPermission is a specific permission key
      const isPermKey =
        user.permissions &&
        typeof user.permissions === 'object' &&
        requiredRoleOrPermission in user.permissions;

      if (isPermKey) {
        if ((user.permissions as any)[requiredRoleOrPermission] === true) {
          return { success: true, user };
        } else {
          return {
            success: false,
            message: `Wewenang ditolak: Pengguna ${user.name} (${user.role}) tidak memiliki hak akses "${String(
              requiredRoleOrPermission
            )}"`,
          };
        }
      }

      // Fallback: check role hierarchy only if it is a role check
      const roleHierarchy: Record<User['role'], number> = {
        KASIR: 1,
        SUPERVISOR: 2,
        ADMIN: 3,
        OWNER: 4,
      };

      if (requiredRoleOrPermission in roleHierarchy) {
        if (roleHierarchy[user.role] < roleHierarchy[requiredRoleOrPermission as User['role']]) {
          return {
            success: false,
            message: `Dibutuhkan otorisasi minimal role ${requiredRoleOrPermission}`,
          };
        }
      } else {
        return {
          success: false,
          message: `Pengguna tidak memiliki wewenang "${String(requiredRoleOrPermission)}"`,
        };
      }
    }
    return { success: true, user };
  };

  const login = (userIdOrUsername: string, pin: string) => {
    const trimmedInput = (userIdOrUsername || '').trim();
    const trimmedPin = (pin || '').trim();
    const user = users.find(
      u => u.id === trimmedInput || (u.username || '').toLowerCase() === trimmedInput.toLowerCase()
    );
    if (!user) {
      return { success: false, message: 'Kasir / Pengguna tidak ditemukan' };
    }
    if (user.isActive === false) {
      return { success: false, message: 'Akun kasir ini dinonaktifkan oleh administrator' };
    }
    if (user.pin !== trimmedPin) {
      return { success: false, message: 'PIN / Password salah! Silakan coba lagi.' };
    }

    // Auto-pending cart if there are active items and cashier is switching
    if (cartRef.current && cartRef.current.length > 0 && user.id !== currentUserRef.current?.id) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
      const prevName = currentUserRef.current?.name || 'Kasir Sebelumnya';
      autoHoldCart(
        `[Auto-Pending] Ganti Kasir (${prevName} ➔ ${user.name})`,
        `Otomatis masuk antrean pending karena pergantian kasir dari "${prevName}" ke "${user.name}" pada pukul ${timeStr}.`
      );
    }

    setCurrentUser(user);
    setIsAuthenticated(true);
    try {
      sessionStorage.setItem('pos_is_authenticated', 'true');
      sessionStorage.setItem('pos_current_user_id', user.id);
      localStorage.setItem('pos_current_user_id', user.id);
    } catch (e) {
      console.warn('Failed to save session to sessionStorage', e);
    }
    return { success: true, user };
  };

  const logout = () => {
    // Auto-pending active cart if cashier logs out while items are in cart
    if (cartRef.current && cartRef.current.length > 0) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
      const cashierName = currentUserRef.current?.name || 'Kasir';
      autoHoldCart(
        `[Auto-Pending] Kasir ${cashierName} Logout`,
        `Otomatis disimpan ke antrean pending karena Kasir ${cashierName} melakukan logout dari kasir pada pukul ${timeStr}.`
      );
    }

    setIsAuthenticated(false);
    try {
      sessionStorage.removeItem('pos_is_authenticated');
      sessionStorage.removeItem('pos_current_user_id');
      localStorage.removeItem('pos_current_user_id');
    } catch (e) {
      console.warn('Failed to clear session from sessionStorage', e);
    }
  };

  const addUser = (user: User) => {
    setUsers(prev => {
      const next = [...prev, user];
      try {
        localStorage.setItem('pos_users', JSON.stringify(next));
      } catch (e) {}
      return next;
    });
  };

  const updateUser = (updated: User) => {
    setUsers(prev => {
      const next = prev.map(u => (u.id === updated.id ? updated : u));
      try {
        localStorage.setItem('pos_users', JSON.stringify(next));
      } catch (e) {}
      return next;
    });
    if (currentUser.id === updated.id) {
      setCurrentUser(updated);
      try {
        localStorage.setItem('pos_current_user', JSON.stringify(updated));
      } catch (e) {}
    }
  };

  const updateMultipleUsers = (updatedList: User[]) => {
    setUsers(updatedList);
    try {
      localStorage.setItem('pos_users', JSON.stringify(updatedList));
    } catch (e) {}
    const updatedCurrent = updatedList.find(u => u.id === currentUser.id);
    if (updatedCurrent) {
      setCurrentUser(updatedCurrent);
      try {
        localStorage.setItem('pos_current_user', JSON.stringify(updatedCurrent));
      } catch (e) {}
    }
  };

  const deleteUser = (id: string) => {
    setUsers(prev => {
      const filtered = prev.filter(u => u.id !== id);
      return filtered.length > 0 ? filtered : prev;
    });
    if (currentUser.id === id) {
      const remaining = users.filter(u => u.id !== id);
      if (remaining.length > 0) {
        setCurrentUser(remaining[0]);
      }
    }
  };

  const deleteAllStaff = (keepOwner: boolean = true) => {
    if (keepOwner) {
      const owners = users.filter(u => u.role === 'OWNER');
      const remaining = owners.length > 0 ? owners : [users[0]];
      setUsers(remaining);
      if (!remaining.some(u => u.id === currentUser.id)) {
        setCurrentUser(remaining[0]);
      }
    } else {
      const defaultOwner: User = {
        id: 'usr-owner-main',
        username: 'owner',
        name: 'Pemilik Toko (Owner)',
        role: 'OWNER',
        pin: '1234',
        isActive: true,
        permissions: {
          canVoid: true,
          canDiscount: true,
          canEditProduct: true,
          canViewProfit: true,
          canManageStaff: true,
          canAccessReports: true,
          canManageLicense: true,
          canOpname: true,
          canPurchases: true,
          canHardware: true,
        },
      };
      setUsers([defaultOwner]);
      setCurrentUser(defaultOwner);
    }
  };

  // Shift Management
  const startShift = (initialCash: number, shiftName: string) => {
    const newShift: CashierShift = {
      id: 'shift-' + Date.now(),
      cashierId: currentUser.id,
      cashierName: currentUser.name,
      shiftName,
      startTime: new Date().toISOString(),
      initialCash,
      cashSales: 0,
      nonCashSales: 0,
      systemExpectedCash: initialCash,
      status: 'OPEN',
    };
    setActiveShift(newShift);
  };

  const closeShift = (actualDrawerCash: number, notes?: string) => {
    if (!activeShift) throw new Error('Tidak ada shift aktif');
    if (pendingCarts.length > 0) {
      throw new Error(
        `Tidak bisa closing kasir! Masih ada ${pendingCarts.length} transaksi berstatus tertunda (pending). Selesaikan atau batalkan pending item terlebih dahulu.`
      );
    }
    const systemCash = activeShift.initialCash + activeShift.cashSales;
    const diff = actualDrawerCash - systemCash;
    const closed: CashierShift = {
      ...activeShift,
      endTime: new Date().toISOString(),
      systemExpectedCash: systemCash,
      actualDrawerCash,
      difference: diff,
      status: 'CLOSED',
      notes,
    };
    setShiftHistory(prev => [closed, ...prev]);
    setActiveShift(null);
    return closed;
  };

  // Master Data CRUD
  const addProduct = (productData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...productData,
      id: 'prod-' + Date.now(),
    };
    setProducts(prev => [newProduct, ...prev]);

    // Log initial stock creation
    if (productData.stock > 0) {
      logStockMovement({
        productId: newProduct.id,
        productName: newProduct.name,
        barcode: newProduct.barcode,
        type: 'STOK_MASUK',
        quantityChange: productData.stock,
        stockBefore: 0,
        stockAfter: productData.stock,
        notes: 'Stok awal produk baru',
      });
    }

    broadcastLanEvent('PRODUCT_UPDATED', { product: newProduct });
  };

  const updateProduct = (updated: Product) => {
    setProducts(prev => prev.map(p => (p.id === updated.id ? updated : p)));
    broadcastLanEvent('PRODUCT_UPDATED', { product: updated });
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addCategory = (name: string) => {
    const newCat: Category = {
      id: 'cat-' + Date.now(),
      name,
    };
    setCategories(prev => [...prev, newCat]);
  };

  const addSupplier = (supData: Omit<Supplier, 'id'>) => {
    const newSup: Supplier = {
      ...supData,
      id: 'sup-' + Date.now(),
    };
    setSuppliers(prev => [...prev, newSup]);
  };

  const addCustomer = (custData: Omit<CustomerMember, 'id' | 'points' | 'totalSpent'>) => {
    const newCust: CustomerMember = {
      ...custData,
      id: 'cust-' + Date.now(),
      points: 0,
      totalSpent: 0,
      createdAt: new Date().toISOString(),
    };
    setCustomers(prev => [...prev, newCust]);
  };

  const updateCustomer = (updated: CustomerMember) => {
    setCustomers(prev => prev.map(c => (c.id === updated.id ? updated : c)));
    if (selectedCustomer?.id === updated.id) {
      setSelectedCustomer(updated);
    }
  };

  const deleteCustomer = (id: string) => {
    setCustomers(prev => prev.filter(c => c.id !== id));
    if (selectedCustomer?.id === id) {
      setSelectedCustomer(null);
    }
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    if (product.stock <= 0) {
      alert(`Peringatan: Stok ${product.name} telah habis (0).`);
    }

    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.productId === product.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        const currentItem = updated[existingIndex];
        const newQty = currentItem.quantity + quantity;
        const subtotal = calculateItemSubtotal(currentItem.sellingPrice, newQty, currentItem.discountType, currentItem.discountValue);
        updated[existingIndex] = {
          ...currentItem,
          quantity: newQty,
          subtotal,
        };
        return updated;
      } else {
        const subtotal = calculateItemSubtotal(product.sellingPrice, quantity, 'NOMINAL', 0);
        const newItem: CartItem = {
          id: 'ci-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
          productId: product.id,
          barcode: product.barcode,
          sku: product.sku,
          name: product.name,
          unit: product.unit,
          costPrice: product.costPrice,
          sellingPrice: product.sellingPrice,
          quantity,
          discountType: 'NOMINAL',
          discountValue: 0,
          subtotal,
        };
        return [...prev, newItem];
      }
    });
  };

  const updateCartQty = (productId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.productId === productId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            const subtotal = calculateItemSubtotal(item.sellingPrice, newQty, item.discountType, item.discountValue);
            return { ...item, quantity: newQty, subtotal };
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const setCartQtyDirect = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item => {
        if (item.productId === productId) {
          const subtotal = calculateItemSubtotal(item.sellingPrice, quantity, item.discountType, item.discountValue);
          return { ...item, quantity, subtotal };
        }
        return item;
      })
    );
  };

  const setCartItemDiscount = (productId: string, type: 'PERCENT' | 'NOMINAL', value: number) => {
    setCart(prev =>
      prev.map(item => {
        if (item.productId === productId) {
          const subtotal = calculateItemSubtotal(item.sellingPrice, item.quantity, type, value);
          return { ...item, discountType: type, discountValue: value, subtotal };
        }
        return item;
      })
    );
  };

  const removeFromCart = (idOrProductId: string) => {
    setCart(prev => prev.filter(item => item.productId !== idOrProductId && item.id !== idOrProductId));
  };

  const clearCart = () => {
    setCart([]);
    setSelectedCustomer(null);
    setTransactionDiscount(0);
  };

  const calculateItemSubtotal = (price: number, qty: number, discType: 'PERCENT' | 'NOMINAL', discVal: number) => {
    const raw = price * qty;
    if (discType === 'PERCENT') {
      const discountAmount = raw * (discVal / 100);
      return Math.max(0, raw - discountAmount);
    } else {
      return Math.max(0, raw - discVal);
    }
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + item.subtotal, 0);

  // Apply member discount if member selected
  const memberDiscountAmount = selectedCustomer && selectedCustomer.discountRate > 0
    ? (cartSubtotal * selectedCustomer.discountRate) / 100
    : 0;

  const cartTotal = Math.max(0, cartSubtotal - transactionDiscount - memberDiscountAmount);

  // Hold / Pending Transactions
  const autoHoldCart = (reasonName: string, detailNotes: string) => {
    const activeItems = cartRef.current;
    if (!activeItems || activeItems.length === 0) return;
    const now = new Date();
    const cashierName = currentUserRef.current?.name || 'Kasir';
    const pendingItem: PendingCart = {
      id: 'pending-auto-' + Date.now(),
      name: reasonName,
      label: reasonName,
      items: [...activeItems],
      customer: selectedCustRef.current || undefined,
      createdAt: now.toISOString(),
      notes: detailNotes,
      createdByCashier: cashierName,
    };
    setPendingCarts(prev => {
      const updated = [pendingItem, ...prev];
      try {
        localStorage.setItem('pos_pending_carts', JSON.stringify(updated));
        localStorage.removeItem('pos_active_cart');
        localStorage.removeItem('pos_selected_customer');
        localStorage.removeItem('pos_transaction_discount');
      } catch (e) {}
      return updated;
    });
    setCart([]);
    setSelectedCustomer(null);
    setTransactionDiscount(0);
  };

  const holdCurrentCart = (name?: string, notes?: string) => {
    if (cart.length === 0) return;
    const defaultLabel = `Antrean #${pendingCarts.length + 1} (${new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })})`;
    const finalName = (name || '').trim() || defaultLabel;
    const pendingItem: PendingCart = {
      id: 'pending-' + Date.now(),
      name: finalName,
      label: finalName,
      items: [...cart],
      customer: selectedCustomer || undefined,
      createdAt: new Date().toISOString(),
      notes: (notes || '').trim() || undefined,
      createdByCashier: currentUser?.name || 'Kasir',
    };
    setPendingCarts(prev => {
      const updated = [pendingItem, ...prev];
      try {
        localStorage.setItem('pos_pending_carts', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    clearCart();
  };

  const resumePendingCart = (id: string) => {
    const found = pendingCarts.find(p => p.id === id);
    if (!found) return;
    // Overwrite or append
    setCart(found.items);
    if (found.customer) setSelectedCustomer(found.customer);
    setPendingCarts(prev => {
      const updated = prev.filter(p => p.id !== id);
      try {
        localStorage.setItem('pos_pending_carts', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const removePendingCart = (id: string) => {
    setPendingCarts(prev => {
      const updated = prev.filter(p => p.id !== id);
      try {
        localStorage.setItem('pos_pending_carts', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  // Stock Logging Helper
  const logStockMovement = (params: {
    productId: string;
    productName: string;
    barcode: string;
    type: InventoryLog['type'];
    quantityChange: number;
    stockBefore: number;
    stockAfter: number;
    notes?: string;
    refDoc?: string;
  }) => {
    const log: InventoryLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substr(2, 3),
      ...params,
      userName: currentUser.name,
      createdAt: new Date().toISOString(),
    };
    setStockLogs(prev => [log, ...prev]);
  };

  // Checkout Execution
  const completeCheckout = (
    paymentMethod: SaleTransaction['paymentMethod'],
    cashReceived: number,
    details?: SaleTransaction['paymentDetails']
  ): SaleTransaction => {
    if (cart.length === 0) throw new Error('Keranjang belanja kosong');

    const pointsRedeemed = details?.pointsRedeemed || 0;
    const pointsDiscountAmount = details?.pointsDiscountAmount || 0;
    const finalTotalAmount = Math.max(0, cartTotal - pointsDiscountAmount);
    const totalCost = cart.reduce((sum, item) => sum + item.costPrice * item.quantity, 0);
    const grossProfit = finalTotalAmount - totalCost;
    const changeDue = Math.max(0, cashReceived - finalTotalAmount);

    // Hitung perolehan poin baru dari belanja yang dibayarkan
    let pointsEarned = 0;
    if (selectedCustomer && memberPointSettings.isEnabled && memberPointSettings.earnSpendAmount > 0) {
      pointsEarned = Math.floor(finalTotalAmount / memberPointSettings.earnSpendAmount) * (memberPointSettings.earnPoints || 1);
    }

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const invoiceNumber = `INV-${dateStr}-${randomSuffix}`;

    const newSale: SaleTransaction = {
      id: 'sale-' + Date.now(),
      invoiceNumber,
      cashierId: currentUser.id,
      cashierName: currentUser.name,
      shiftId: activeShift?.id || 'shift-general',
      customerId: selectedCustomer?.id,
      customerName: selectedCustomer?.name,
      customerPhone: selectedCustomer?.phone,
      items: [...cart],
      subtotal: cartSubtotal,
      transactionDiscount: transactionDiscount + memberDiscountAmount + pointsDiscountAmount,
      pointsRedeemed,
      pointsDiscountAmount,
      pointsEarned,
      totalAmount: finalTotalAmount,
      totalCost,
      grossProfit,
      paymentMethod,
      paymentDetails: details,
      cashReceived,
      changeDue,
      status: 'COMPLETED',
      createdAt: now.toISOString(),
    };

    // Deduct stock for all items
    setProducts(prevProducts => {
      const productMap = new Map(prevProducts.map(p => [p.id, p]));
      cart.forEach(item => {
        const prod = productMap.get(item.productId);
        if (prod) {
          const oldStock = prod.stock;
          const newStock = Math.max(0, oldStock - item.quantity);
          productMap.set(item.productId, { ...prod, stock: newStock });

          logStockMovement({
            productId: prod.id,
            productName: prod.name,
            barcode: prod.barcode,
            type: 'PENJUALAN',
            quantityChange: -item.quantity,
            stockBefore: oldStock,
            stockAfter: newStock,
            refDoc: invoiceNumber,
            notes: `Penjualan kasir ke ${selectedCustomer?.name || 'Umum'}`,
          });
        }
      });
      return Array.from(productMap.values());
    });

    // Update member points & total spent
    if (selectedCustomer) {
      setCustomers(prev =>
        prev.map(c =>
          c.id === selectedCustomer.id
            ? {
                ...c,
                points: Math.max(0, (c.points || 0) - pointsRedeemed) + pointsEarned,
                totalSpent: (c.totalSpent || 0) + finalTotalAmount,
              }
            : c
        )
      );
      setSelectedCustomer(prev =>
        prev && prev.id === selectedCustomer.id
          ? {
              ...prev,
              points: Math.max(0, (prev.points || 0) - pointsRedeemed) + pointsEarned,
              totalSpent: (prev.totalSpent || 0) + finalTotalAmount,
            }
          : prev
      );
    }

    // Handle PIUTANG creation
    if (paymentMethod === 'PIUTANG') {
      const downPayment = Math.max(0, details?.downPayment || 0);
      const remainingAmount = Math.max(0, finalTotalAmount - downPayment);
      const dueDate = details?.dueDate || new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10);

      const piutangRecord: PiutangRecord = {
        id: 'piutang-' + Date.now(),
        invoiceNumber,
        saleId: newSale.id,
        customerId: selectedCustomer?.id || ('cust-umum-' + Date.now()),
        customerName: selectedCustomer?.name || details?.bankName || 'Pelanggan Kasbon',
        customerPhone: selectedCustomer?.phone,
        totalAmount: finalTotalAmount,
        paidAmount: downPayment,
        remainingAmount,
        dueDate,
        status: remainingAmount <= 0 ? 'LUNAS' : 'BELUM_LUNAS',
        notes: details?.approvalCode || 'Piutang transaksi kasir',
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
        payments: downPayment > 0 ? [
          {
            id: 'pay-' + Date.now(),
            amount: downPayment,
            paidAt: now.toISOString(),
            cashierName: currentUser?.name || 'Kasir',
            paymentMethod: 'TUNAI',
            notes: 'Uang Muka (DP) saat transaksi kasir',
          }
        ] : [],
      };

      setPiutangList(prev => [piutangRecord, ...prev]);

      if (selectedCustomer) {
        setCustomers(prev =>
          prev.map(c =>
            c.id === selectedCustomer.id
              ? { ...c, totalDebt: (c.totalDebt || 0) + remainingAmount }
              : c
          )
        );
      }
    }

    // Update active shift financial totals
    if (activeShift) {
      if (paymentMethod === 'TUNAI') {
        setActiveShift(prev =>
          prev
            ? {
                ...prev,
                cashSales: prev.cashSales + cartTotal,
                systemExpectedCash: prev.initialCash + prev.cashSales + cartTotal,
              }
            : null
        );
      } else if (paymentMethod === 'PIUTANG') {
        const dp = Math.max(0, details?.downPayment || 0);
        if (dp > 0) {
          setActiveShift(prev =>
            prev
              ? {
                  ...prev,
                  cashSales: prev.cashSales + dp,
                  systemExpectedCash: prev.initialCash + prev.cashSales + dp,
                }
              : null
          );
        }
      } else {
        setActiveShift(prev =>
          prev ? { ...prev, nonCashSales: prev.nonCashSales + cartTotal } : null
        );
      }
    }

    setSales(prev => [newSale, ...prev]);
    clearCart();
    setReprintTransaction(newSale);
    broadcastLanEvent('TRANSACTION_CREATED', { sale: newSale });
    return newSale;
  };

  // Void Transaction
  const voidTransaction = (invoiceNumber: string, reason: string, supervisorPin: string) => {
    const auth = verifyPin(supervisorPin, 'SUPERVISOR');
    if (!auth.success) {
      return { success: false, message: auth.message || 'Otorisasi Supervisor gagal' };
    }

    const sale = sales.find(s => s.invoiceNumber === invoiceNumber);
    if (!sale) return { success: false, message: 'Transaksi tidak ditemukan' };
    if (sale.status === 'VOID') return { success: false, message: 'Transaksi sudah dibatalkan sebelumnya' };

    // Restore stock
    setProducts(prevProducts => {
      const productMap = new Map(prevProducts.map(p => [p.id, p]));
      sale.items.forEach(item => {
        const prod = productMap.get(item.productId);
        if (prod) {
          const oldStock = prod.stock;
          const newStock = oldStock + item.quantity;
          productMap.set(item.productId, { ...prod, stock: newStock });

          logStockMovement({
            productId: prod.id,
            productName: prod.name,
            barcode: prod.barcode,
            type: 'RETUR_PENJUALAN',
            quantityChange: item.quantity,
            stockBefore: oldStock,
            stockAfter: newStock,
            refDoc: sale.invoiceNumber,
            notes: `VOID oleh ${auth.user?.name}. Alasan: ${reason}`,
          });
        }
      });
      return Array.from(productMap.values());
    });

    // Mark sale as VOID
    setSales(prev =>
      prev.map(s =>
        s.invoiceNumber === invoiceNumber
          ? {
              ...s,
              status: 'VOID',
              voidReason: reason,
              voidBySupervisor: auth.user?.name,
            }
          : s
      )
    );

    // Revert shift financial total if in active shift
    if (activeShift && sale.shiftId === activeShift.id) {
      if (sale.paymentMethod === 'TUNAI') {
        setActiveShift(prev =>
          prev
            ? {
                ...prev,
                cashSales: Math.max(0, prev.cashSales - sale.totalAmount),
                systemExpectedCash: Math.max(0, prev.systemExpectedCash - sale.totalAmount),
              }
            : null
        );
      } else {
        setActiveShift(prev =>
          prev ? { ...prev, nonCashSales: Math.max(0, prev.nonCashSales - sale.totalAmount) } : null
        );
      }
    }

    return { success: true, message: `Transaksi ${invoiceNumber} berhasil di-VOID` };
  };

  // Sales Return & Refund
  const processSalesReturn = (
    saleInvoice: string,
    returnedItems: { productId: string; quantity: number; refundPrice: number }[],
    reason: string,
    supervisorPin: string
  ) => {
    const auth = verifyPin(supervisorPin, 'SUPERVISOR');
    if (!auth.success) {
      return { success: false, message: auth.message || 'Otorisasi Supervisor diperlukan untuk retur' };
    }

    const sale = sales.find(s => s.invoiceNumber === saleInvoice);
    if (!sale) return { success: false, message: 'Nomor faktur tidak valid' };

    const totalRefund = returnedItems.reduce((sum, item) => sum + item.quantity * item.refundPrice, 0);

    const returnRecord: SalesReturn = {
      id: 'ret-' + Date.now(),
      returnInvoice: `RET-${Date.now().toString().slice(-6)}`,
      originalInvoiceNumber: saleInvoice,
      saleId: sale.id,
      refundAmount: totalRefund,
      supervisorId: auth.user!.id,
      supervisorName: auth.user!.name,
      reason,
      returnedItems: returnedItems.map(ri => {
        const prod = products.find(p => p.id === ri.productId);
        return {
          productId: ri.productId,
          productName: prod?.name || 'Produk',
          quantity: ri.quantity,
          refundPrice: ri.refundPrice,
        };
      }),
      createdAt: new Date().toISOString(),
    };

    // Restore stock
    setProducts(prevProducts => {
      const map = new Map(prevProducts.map(p => [p.id, p]));
      returnedItems.forEach(ri => {
        const prod = map.get(ri.productId);
        if (prod) {
          const oldStock = prod.stock;
          const newStock = oldStock + ri.quantity;
          map.set(ri.productId, { ...prod, stock: newStock });

          logStockMovement({
            productId: prod.id,
            productName: prod.name,
            barcode: prod.barcode,
            type: 'RETUR_PENJUALAN',
            quantityChange: ri.quantity,
            stockBefore: oldStock,
            stockAfter: newStock,
            refDoc: returnRecord.returnInvoice,
            notes: `Retur & Pengembalian Dana: ${reason}`,
          });
        }
      });
      return Array.from(map.values());
    });

    setReturns(prev => [returnRecord, ...prev]);
    return { success: true, message: `Retur berhasil diproses. Dana dikembalikan: Rp ${totalRefund.toLocaleString('id-ID')}` };
  };

  // ================= PIUTANG MANAGEMENT =================
  const addPiutangPayment = (
    piutangId: string,
    amount: number,
    method: 'TUNAI' | 'TRANSFER',
    notes?: string
  ): { success: boolean; message: string } => {
    if (amount <= 0) {
      return { success: false, message: 'Nominal pembayaran harus lebih besar dari Rp 0' };
    }

    const piutang = piutangList.find(p => p.id === piutangId);
    if (!piutang) {
      return { success: false, message: 'Data piutang tidak ditemukan' };
    }

    if (piutang.remainingAmount <= 0) {
      return { success: false, message: 'Piutang ini sudah lunas sebelumnya' };
    }

    const actualPay = Math.min(amount, piutang.remainingAmount);
    const newPaid = piutang.paidAmount + actualPay;
    const newRemaining = Math.max(0, piutang.totalAmount - newPaid);
    const newStatus: PiutangRecord['status'] = newRemaining <= 0 ? 'LUNAS' : 'BELUM_LUNAS';

    const paymentEntry = {
      id: 'pay-' + Date.now(),
      amount: actualPay,
      paidAt: new Date().toISOString(),
      cashierName: currentUser?.name || 'Kasir',
      paymentMethod: method,
      notes: notes?.trim() || undefined,
    };

    setPiutangList(prev =>
      prev.map(p =>
        p.id === piutangId
          ? {
              ...p,
              paidAmount: newPaid,
              remainingAmount: newRemaining,
              status: newStatus,
              updatedAt: new Date().toISOString(),
              payments: [...p.payments, paymentEntry],
            }
          : p
      )
    );

    // Update customer debt
    setCustomers(prev =>
      prev.map(c =>
        c.id === piutang.customerId || (piutang.customerName && c.name.toLowerCase() === piutang.customerName.toLowerCase())
          ? {
              ...c,
              totalDebt: Math.max(0, (c.totalDebt || 0) - actualPay),
            }
          : c
      )
    );

    // If payment was cash and shift is active, add to cash drawer
    if (method === 'TUNAI' && activeShift) {
      setActiveShift(prev =>
        prev
          ? {
              ...prev,
              cashSales: prev.cashSales + actualPay,
              systemExpectedCash: prev.initialCash + prev.cashSales + actualPay,
            }
          : null
      );
    }

    return {
      success: true,
      message: `Pembayaran piutang berhasil dicatat sebesar Rp ${actualPay.toLocaleString('id-ID')}.${
        newRemaining <= 0 ? ' Piutang LUNAS!' : ` Sisa: Rp ${newRemaining.toLocaleString('id-ID')}.`
      }`,
    };
  };

  const createDirectPiutang = (params: {
    customerId?: string;
    customerName: string;
    customerPhone?: string;
    totalAmount: number;
    downPayment?: number;
    dueDate: string;
    notes?: string;
  }): PiutangRecord => {
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const invoiceNumber = `BON-${dateStr}-${randomSuffix}`;
    const dp = Math.max(0, params.downPayment || 0);
    const remainingAmount = Math.max(0, params.totalAmount - dp);

    const newRecord: PiutangRecord = {
      id: 'piutang-' + Date.now(),
      invoiceNumber,
      customerId: params.customerId || ('cust-manual-' + Date.now()),
      customerName: params.customerName.trim(),
      customerPhone: params.customerPhone?.trim() || undefined,
      totalAmount: params.totalAmount,
      paidAmount: dp,
      remainingAmount,
      dueDate: params.dueDate,
      status: remainingAmount <= 0 ? 'LUNAS' : 'BELUM_LUNAS',
      notes: params.notes?.trim() || undefined,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
      payments: dp > 0 ? [
        {
          id: 'pay-' + Date.now(),
          amount: dp,
          paidAt: now.toISOString(),
          cashierName: currentUser?.name || 'Kasir',
          paymentMethod: 'TUNAI',
          notes: 'DP Awal Kasbon Manual',
        }
      ] : [],
    };

    setPiutangList(prev => [newRecord, ...prev]);

    if (params.customerId) {
      setCustomers(prev =>
        prev.map(c =>
          c.id === params.customerId
            ? { ...c, totalDebt: (c.totalDebt || 0) + remainingAmount }
            : c
        )
      );
    }

    if (dp > 0 && activeShift) {
      setActiveShift(prev =>
        prev
          ? {
              ...prev,
              cashSales: prev.cashSales + dp,
              systemExpectedCash: prev.initialCash + prev.cashSales + dp,
            }
          : null
      );
    }

    return newRecord;
  };

  const updatePiutangStatus = (piutangId: string, status: PiutangRecord['status']) => {
    setPiutangList(prev =>
      prev.map(p => (p.id === piutangId ? { ...p, status, updatedAt: new Date().toISOString() } : p))
    );
  };

  // Inventory adjustment
  const adjustStock = (productId: string, type: InventoryLog['type'], qtyChange: number, notes?: string, refDoc?: string) => {
    setProducts(prev => {
      const updated = prev.map(p => {
        if (p.id === productId) {
          const oldStock = p.stock;
          const newStock = Math.max(0, oldStock + qtyChange);
          logStockMovement({
            productId: p.id,
            productName: p.name,
            barcode: p.barcode,
            type,
            quantityChange: qtyChange,
            stockBefore: oldStock,
            stockAfter: newStock,
            notes,
            refDoc,
          });
          return { ...p, stock: newStock };
        }
        return p;
      });
      try {
        localStorage.setItem('pos_products', JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to save pos_products', e);
      }
      return updated;
    });
    broadcastLanEvent('STOCK_ADJUSTED', { productId, qtyChange });
  };

  const addPurchaseOrder = (poData: Omit<PurchaseOrder, 'id' | 'createdAt'>) => {
    const po: PurchaseOrder = {
      ...poData,
      id: 'po-' + Date.now(),
      createdAt: new Date().toISOString(),
    };

    // Increase product stock & update cost price HPP
    setProducts(prev => {
      const map = new Map(prev.map(p => [p.id, p]));
      po.items.forEach(item => {
        const prod = map.get(item.productId);
        if (prod) {
          const oldStock = prod.stock;
          const newStock = oldStock + item.quantity;
          map.set(item.productId, {
            ...prod,
            stock: newStock,
            costPrice: item.unitCost, // update HPP terbaru
          });
          logStockMovement({
            productId: prod.id,
            productName: prod.name,
            barcode: prod.barcode,
            type: 'STOK_MASUK',
            quantityChange: item.quantity,
            stockBefore: oldStock,
            stockAfter: newStock,
            refDoc: po.invoiceNumber,
            notes: `Penerimaan barang dari supplier ${po.supplierName}`,
          });
        }
      });
      const updated = Array.from(map.values());
      try {
        localStorage.setItem('pos_products', JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to save pos_products', e);
      }
      return updated;
    });

    setPurchases(prev => [po, ...prev]);
  };

  const commitStockOpname = (opnameData: Omit<StockOpnameSession, 'id'>) => {
    const session: StockOpnameSession = {
      ...opnameData,
      id: 'opn-' + Date.now(),
      status: 'COMMITTED',
    };

    // Update stocks to physical count
    setProducts(prev => {
      const map = new Map(prev.map(p => [p.id, p]));
      session.items.forEach(item => {
        const prod = map.get(item.productId);
        if (prod) {
          const oldStock = prod.stock;
          const newStock = item.physicalStock;
          const diff = item.difference;
          map.set(item.productId, { ...prod, stock: newStock });
          logStockMovement({
            productId: prod.id,
            productName: prod.name,
            barcode: prod.barcode,
            type: 'STOCK_OPNAME',
            quantityChange: diff,
            stockBefore: oldStock,
            stockAfter: newStock,
            refDoc: session.opnameNumber,
            notes: `Stock Opname selisih: ${diff > 0 ? '+' : ''}${diff} ${prod.unit}`,
          });
        }
      });
      const updated = Array.from(map.values());
      try {
        localStorage.setItem('pos_products', JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to save pos_products to localStorage', e);
      }
      return updated;
    });

    setStockOpnameSessions(prev => {
      const next = [session, ...prev];
      try {
        localStorage.setItem('pos_opnames', JSON.stringify(next));
      } catch (e) {
        console.warn('Failed to save pos_opnames to localStorage', e);
      }
      return next;
    });
  };

  const executeRepack = (
    sourceProductId: string,
    sourceQty: number,
    targetProductId: string,
    targetQty: number,
    notes?: string
  ) => {
    const source = products.find(p => p.id === sourceProductId);
    const target = products.find(p => p.id === targetProductId);
    if (!source || !target) return;

    if (source.stock < sourceQty) {
      alert(`Stok ${source.name} tidak cukup untuk direpack!`);
      return;
    }

    // Deduct source
    adjustStock(sourceProductId, 'REPACKING', -sourceQty, `Repack ke ${target.name} (${targetQty} ${target.unit})`, 'REPACK');
    // Add target
    adjustStock(targetProductId, 'REPACKING', targetQty, `Repack dari ${source.name} (${sourceQty} ${source.unit})`, 'REPACK');

    const record: RepackingRecord = {
      id: 'rpk-' + Date.now(),
      date: new Date().toISOString(),
      sourceProductId,
      sourceProductName: source.name,
      sourceQtyDeducted: sourceQty,
      targetProductId,
      targetProductName: target.name,
      targetQtyAdded: targetQty,
      operatorName: currentUser.name,
      notes,
    };
    setRepackRecords(prev => [record, ...prev]);
  };

  // Payment Settings & Bank Accounts
  const updatePaymentSettings = (settings: PaymentSettings) => setPaymentSettings(settings);

  const updateMemberPointSettings = (newSettings: Partial<MemberPointSettings>) => {
    setMemberPointSettings(prev => ({ ...prev, ...newSettings }));
  };

  const updateQRISSettings = (qrisData: Partial<QRISSettings>) => {
    setPaymentSettings(prev => ({
      ...prev,
      qris: {
        ...prev.qris,
        ...qrisData,
      },
    }));
  };

  const addBankAccount = (accData: Omit<BankAccount, 'id'>) => {
    const newAcc: BankAccount = {
      ...accData,
      id: 'bank-' + Date.now(),
    };
    setPaymentSettings(prev => ({
      ...prev,
      bankAccounts: [...prev.bankAccounts, newAcc],
    }));
  };

  const updateBankAccount = (updated: BankAccount) => {
    setPaymentSettings(prev => ({
      ...prev,
      bankAccounts: prev.bankAccounts.map(b => (b.id === updated.id ? updated : b)),
    }));
  };

  const deleteBankAccount = (id: string) => {
    setPaymentSettings(prev => ({
      ...prev,
      bankAccounts: prev.bankAccounts.filter(b => b.id !== id),
    }));
  };

  // Hardware & License
  const updateStoreProfile = (profile: StoreProfile) => setStoreProfile(profile);
  const updateHardwareSettings = (settings: HardwareSettings) => setHardwareSettings(settings);

  const activateLicenseKey = (key: string) => {
    const trimmed = (key || '').trim().toUpperCase();
    if (trimmed.includes('LIFETIME')) {
      const updated: LicenseInfo = {
        ...license,
        licenseKey: trimmed,
        plan: 'LIFETIME',
        status: 'ACTIVE',
        maxDevices: 10,
        validUntil: 'Selamanya (Lifetime)',
        activatedAt: new Date().toISOString(),
      };
      setLicense(updated);
      return { success: true, message: 'Lisensi Paket Lifetime berhasil diaktifkan!' };
    } else if (trimmed.includes('BULANAN') || trimmed.includes('MONTHLY')) {
      const expiry = new Date(Date.now() + 30 * 86400000).toLocaleDateString('id-ID');
      const updated: LicenseInfo = {
        ...license,
        licenseKey: trimmed,
        plan: 'BULANAN',
        status: 'ACTIVE',
        maxDevices: 3,
        validUntil: `${expiry} (30 Hari)`,
        activatedAt: new Date().toISOString(),
      };
      setLicense(updated);
      return { success: true, message: 'Lisensi Paket Bulanan berhasil diaktifkan!' };
    } else if (trimmed.startsWith('POSM-')) {
      const updated: LicenseInfo = {
        ...license,
        licenseKey: trimmed,
        status: 'ACTIVE',
        validUntil: 'Aktif Terverifikasi',
        activatedAt: new Date().toISOString(),
      };
      setLicense(updated);
      return { success: true, message: 'Kode Lisensi Minimarket Pro berhasil diaktifkan!' };
    } else {
      return { success: false, message: 'Kode lisensi tidak valid atau format salah.' };
    }
  };

  const generateCustomLicense = (storeName: string, plan: LicenseInfo['plan'], maxDevices: number) => {
    const year = new Date().getFullYear();
    const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `POSM-${plan}-${year}-${rand}-${maxDevices}DEV`;
  };

  // Cloud Sync simulation
  const triggerSync = async () => {
    setCloudSyncStatus(prev => ({ ...prev, isSyncing: true }));
    await new Promise(r => setTimeout(r, 1200));
    setCloudSyncStatus({
      isSyncing: false,
      lastSynced: new Date().toLocaleTimeString('id-ID'),
      supabaseConnected: true,
    });
  };

  const exportDatabaseJson = () => {
    const fullDb = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      storeProfile,
      paymentSettings,
      memberPointSettings,
      users,
      products,
      categories,
      suppliers,
      customers,
      sales,
      returns,
      piutangList,
      stockLogs,
      purchases,
      stockOpnameSessions,
      repackRecords,
      shiftHistory,
      hardwareSettings,
      license,
    };
    const blob = new Blob([JSON.stringify(fullDb, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_pos_minimarket_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importDatabaseJson = (jsonData: string): boolean => {
    try {
      const db = JSON.parse(jsonData);
      if (db.products) setProducts(db.products);
      if (db.categories) setCategories(db.categories);
      if (db.suppliers) setSuppliers(db.suppliers);
      if (db.customers) setCustomers(db.customers);
      if (db.sales) setSales(db.sales);
      if (db.users) setUsers(db.users);
      if (db.piutangList) setPiutangList(db.piutangList);
      if (db.storeProfile) setStoreProfile(db.storeProfile);
      if (db.paymentSettings) setPaymentSettings(db.paymentSettings);
      if (db.memberPointSettings) setMemberPointSettings(db.memberPointSettings);
      return true;
    } catch {
      return false;
    }
  };

  const updateLanSettings = (settings: {
    role?: LanDeviceRole;
    terminalName?: string;
    serverUrl?: string;
    autoSync?: boolean;
  }) => {
    if (settings.role) {
      setLanRole(settings.role);
      localStorage.setItem('pos_lan_role', settings.role);
    }
    if (settings.terminalName) {
      setLanTerminalName(settings.terminalName);
      localStorage.setItem('pos_lan_terminal_name', settings.terminalName);
    }
    if (settings.serverUrl !== undefined) {
      setLanServerUrl(settings.serverUrl);
      localStorage.setItem('pos_lan_server_url', settings.serverUrl);
    }
    if (settings.autoSync !== undefined) {
      setLanAutoSync(settings.autoSync);
      localStorage.setItem('pos_lan_auto_sync', String(settings.autoSync));
    }
  };

  const triggerLanSyncNow = async () => {
    setLanIsSyncing(true);
    try {
      const res = await fetch('/api/lan/status');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.localIps)) setLanDetectedIps(data.localIps);
        if (Array.isArray(data.connectedClients)) setLanConnectedClients(data.connectedClients);
        setLanLocalVersion(data.version || 1);
        setLanLastSyncTime(new Date().toISOString());
        addLanLog('CONNECT', 'Status Sinkronisasi Diperbarui', lanTerminalName, 'SUCCESS', `Versi server v${data.version || 1}`);
      }
    } catch (e: any) {
      addLanLog('ERROR', 'Gagal Sinkronisasi LAN', lanTerminalName, 'ERROR', e.message || 'Jaringan tidak merespons');
    } finally {
      setTimeout(() => setLanIsSyncing(false), 600);
    }
  };

  const broadcastLanTestSignal = (message?: string) => {
    broadcastLanEvent('TEST_SIGNAL', { message: message || 'Uji Sinyal Kasir Toko OK' });
    setLanRecentEventNotification(`🔔 Sinyal uji terkirim ke seluruh terminal: "${message || 'Uji Sinyal Kasir Toko OK'}"`);
  };

  const pushFullDbToLan = async () => {
    setLanIsSyncing(true);
    try {
      const statePayload = {
        products,
        sales,
        customers,
        categories,
        suppliers,
        piutangList,
        stockLogs,
        storeProfile,
      };

      if (lanSocketRef.current && lanSocketRef.current.readyState === WebSocket.OPEN) {
        lanSocketRef.current.send(
          JSON.stringify({
            type: 'PUSH_FULL_STATE',
            payload: statePayload,
            deviceId: lanDeviceId,
            terminalName: lanTerminalName,
          })
        );
      }

      const res = await fetch('/api/lan/sync-push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          state: statePayload,
          deviceId: lanDeviceId,
          terminalName: lanTerminalName,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLanLocalVersion(data.version || (v => v + 1));
        setLanLastSyncTime(new Date().toISOString());
        addLanLog('FULL_SYNC', 'Push Database Berhasil', lanTerminalName, 'SUCCESS', `Disinkronkan ke seluruh kasir toko (v${data.version || 1})`);
        setLanRecentEventNotification('✅ Database toko berhasil disebarkan ke seluruh terminal kasir');
      }
    } catch (e: any) {
      addLanLog('ERROR', 'Push Database Gagal', lanTerminalName, 'ERROR', e.message);
    } finally {
      setLanIsSyncing(false);
    }
  };

  const pullFullDbFromLan = async () => {
    setLanIsSyncing(true);
    try {
      const res = await fetch('/api/lan/sync-pull');
      if (res.ok) {
        const data = await res.json();
        if (data.state) {
          if (Array.isArray(data.state.products)) setProducts(data.state.products);
          if (Array.isArray(data.state.sales)) setSales(data.state.sales);
          if (Array.isArray(data.state.customers)) setCustomers(data.state.customers);
          if (Array.isArray(data.state.categories)) setCategories(data.state.categories);
          if (Array.isArray(data.state.suppliers)) setSuppliers(data.state.suppliers);
          if (Array.isArray(data.state.piutangList)) setPiutangList(data.state.piutangList);
          if (Array.isArray(data.state.stockLogs)) setStockLogs(data.state.stockLogs);
          if (data.state.storeProfile) setStoreProfile(data.state.storeProfile);
        }
        setLanLocalVersion(data.version || 1);
        setLanLastSyncTime(new Date().toISOString());
        addLanLog('FULL_SYNC', 'Tarik Database Sukses', lanTerminalName, 'SUCCESS', `Data dimuat dari master (v${data.version || 1})`);
        setLanRecentEventNotification('✅ Data produk, stok, dan transaksi toko berhasil dimuat dari server');
      }
    } catch (e: any) {
      addLanLog('ERROR', 'Tarik Database Gagal', lanTerminalName, 'ERROR', e.message);
    } finally {
      setLanIsSyncing(false);
    }
  };

  const clearLanLogs = () => {
    setLanActivityLogs([]);
  };

  const dismissLanNotification = () => {
    setLanRecentEventNotification(null);
  };

  const lanSyncStatus: LanSyncStatus = {
    role: lanRole,
    terminalName: lanTerminalName,
    serverUrl: lanServerUrl,
    isConnected: lanConnected,
    isSyncing: lanIsSyncing,
    lastSyncTime: lanLastSyncTime,
    autoSync: lanAutoSync,
    detectedIps: lanDetectedIps,
    serverPort: 3000,
    serverHostname: 'LAN Host',
    connectedClients: lanConnectedClients,
    error: null,
    localVersion: lanLocalVersion,
    activityLogs: lanActivityLogs,
  };

  const resetToSampleData = () => {
    if (confirm('Kembalikan database ke data bawaan minimarket? Data baru akan ditimpa.')) {
      localStorage.clear();
      setProducts(INITIAL_PRODUCTS);
      setCategories(INITIAL_CATEGORIES);
      setSuppliers(INITIAL_SUPPLIERS);
      setCustomers(INITIAL_CUSTOMERS);
      setUsers(INITIAL_USERS);
      setStoreProfile(INITIAL_STORE_PROFILE);
      setPaymentSettings(INITIAL_PAYMENT_SETTINGS);
      setMemberPointSettings(INITIAL_MEMBER_POINT_SETTINGS);
      setHardwareSettings(INITIAL_HARDWARE_SETTINGS);
      setLicense(INITIAL_LICENSE);
      setPiutangList(INITIAL_PIUTANG);
      setSales([]);
      setStockLogs([]);
      setPurchases([]);
      setPendingCarts([]);
      setCart([]);
      setSelectedCustomer(null);
      setTransactionDiscount(0);
    }
  };

  return (
    <POSContext.Provider
      value={{
        isAuthenticated,
        login,
        logout,
        currentUser,
        users,
        setCurrentUser,
        verifyPin,
        addUser,
        updateUser,
        updateMultipleUsers,
        deleteUser,
        deleteAllStaff,
        activeShift,
        startShift,
        closeShift,
        shiftHistory,
        products,
        categories,
        suppliers,
        customers,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,
        addSupplier,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        cart,
        addToCart,
        updateCartQty,
        setCartQtyDirect,
        setCartItemDiscount,
        removeFromCart,
        clearCart,
        selectedCustomer,
        setSelectedCustomer,
        transactionDiscount,
        setTransactionDiscount,
        cartSubtotal,
        cartTotal,
        pendingCarts,
        holdCurrentCart,
        autoHoldCart,
        resumePendingCart,
        removePendingCart,
        sales,
        completeCheckout,
        voidTransaction,
        reprintTransaction,
        setReprintTransaction,
        returns,
        processSalesReturn,
        piutangList,
        addPiutangPayment,
        createDirectPiutang,
        updatePiutangStatus,
        stockLogs,
        adjustStock,
        purchases,
        addPurchaseOrder,
        stockOpnameSessions,
        commitStockOpname,
        repackRecords,
        executeRepack,
        storeProfile,
        updateStoreProfile,
        paymentSettings,
        updatePaymentSettings,
        updateQRISSettings,
        addBankAccount,
        updateBankAccount,
        deleteBankAccount,
        memberPointSettings,
        updateMemberPointSettings,
        hardwareSettings,
        updateHardwareSettings,
        license,
        activateLicenseKey,
        generateCustomLicense,
        cloudSyncStatus,
        triggerSync,
        exportDatabaseJson,
        importDatabaseJson,
        resetToSampleData,
        lanSyncStatus,
        updateLanSettings,
        triggerLanSyncNow,
        broadcastLanTestSignal,
        pushFullDbToLan,
        pullFullDbFromLan,
        clearLanLogs,
        lanRecentEventNotification,
        dismissLanNotification,
      }}
    >
      {children}
    </POSContext.Provider>
  );
};

export const usePOS = () => {
  const context = useContext(POSContext);
  if (!context) {
    throw new Error('usePOS must be used within a POSProvider');
  }
  return context;
};
