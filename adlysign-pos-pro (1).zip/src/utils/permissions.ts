import { User, UserRole } from '../types/pos';
import { ActiveModule } from '../components/layout/HeaderNav';

/**
 * Validates whether a user has a specific granular permission.
 * Owner always has all permissions.
 */
export function hasPermission(
  user: User | null | undefined,
  permissionKey: keyof User['permissions']
): boolean {
  if (!user) return false;
  if (user.role === 'OWNER') return true;
  if (!user.isActive) return false;

  // Granular permission check
  if (user.permissions && user.permissions[permissionKey] !== undefined) {
    return Boolean(user.permissions[permissionKey]);
  }

  // Fallback based on standard role capabilities if permission is not set
  switch (permissionKey) {
    case 'canVoid':
    case 'canDiscount':
      return user.role === 'SUPERVISOR' || user.role === 'ADMIN';
    case 'canEditProduct':
      return user.role === 'ADMIN';
    case 'canOpname':
      return user.role === 'SUPERVISOR' || user.role === 'ADMIN';
    case 'canPurchases':
      return user.role === 'SUPERVISOR' || user.role === 'ADMIN';
    case 'canAccessReports':
      return user.role === 'SUPERVISOR' || user.role === 'ADMIN';
    case 'canViewProfit':
      return user.role === 'ADMIN';
    case 'canManageStaff':
      return false; // Only Owner or explicitly granted
    case 'canHardware':
      return user.role === 'SUPERVISOR' || user.role === 'ADMIN';
    case 'canManageLicense':
      return false;
    default:
      return false;
  }
}

/**
 * Validates whether a user is allowed to navigate to / view an entire module.
 */
export function canAccessModule(
  user: User | null | undefined,
  module: ActiveModule
): { allowed: boolean; reason?: string; requiredPermission?: keyof User['permissions'] } {
  if (!user) {
    return { allowed: false, reason: 'Pengguna belum login' };
  }

  if (user.role === 'OWNER') {
    return { allowed: true };
  }

  if (!user.isActive) {
    return { allowed: false, reason: 'Akun kasir/staf ini telah dinonaktifkan' };
  }

  switch (module) {
    case 'KASIR':
      // Core cashier view is always available to active staff
      return { allowed: true };

    case 'PRODUK':
      // Products catalog is viewable, but modifying products requires canEditProduct
      return { allowed: true };

    case 'STOK':
      if (!hasPermission(user, 'canOpname')) {
        return {
          allowed: false,
          reason: 'Akses Ditolak: Anda tidak memiliki wewenang untuk membuka modul Persediaan & Stock Opname.',
          requiredPermission: 'canOpname',
        };
      }
      return { allowed: true };

    case 'PEMBELIAN':
      if (!hasPermission(user, 'canPurchases')) {
        return {
          allowed: false,
          reason: 'Akses Ditolak: Anda tidak memiliki wewenang untuk membuka modul Pembelian (LPB Supplier).',
          requiredPermission: 'canPurchases',
        };
      }
      return { allowed: true };

    case 'PENJUALAN':
      // Sales transaction log is accessible to view, void and refund are gated with PIN
      return { allowed: true };

    case 'PIUTANG':
      // Accounts receivable / customer kasbon is accessible to staff and managers
      return { allowed: true };

    case 'SETTING_PEMBAYARAN':
      // Setting sistem, pembayaran & toko: Khusus Owner toko
      return {
        allowed: false,
        reason: 'Akses Ditolak: Menu Setting hanya dapat diakses oleh Owner toko.',
        requiredPermission: 'canManageLicense',
      };

    case 'LAPORAN':
      if (!hasPermission(user, 'canAccessReports')) {
        return {
          allowed: false,
          reason: 'Akses Ditolak: Anda tidak memiliki wewenang untuk melihat Laporan Penjualan & Keuangan Toko.',
          requiredPermission: 'canAccessReports',
        };
      }
      return { allowed: true };

    case 'KARYAWAN':
      // Cashiers can only access closing/shifts tab, but cannot manage staff or permissions unless permitted
      return { allowed: true };

    case 'HARDWARE':
      if (!hasPermission(user, 'canHardware')) {
        return {
          allowed: false,
          reason: 'Akses Ditolak: Anda tidak memiliki wewenang untuk mengubah pengaturan Hardware & Printer.',
          requiredPermission: 'canHardware',
        };
      }
      return { allowed: true };

    case 'CLOUD':
      if (!hasPermission(user, 'canManageLicense')) {
        return {
          allowed: false,
          reason: 'Akses Ditolak: Pengaturan Sinkronisasi Cloud & Database hanya dapat diakses oleh Owner.',
          requiredPermission: 'canManageLicense',
        };
      }
      return { allowed: true };

    case 'LISENSI':
      if (!hasPermission(user, 'canManageLicense')) {
        return {
          allowed: false,
          reason: 'Akses Ditolak: Aktivasi Lisensi & Toko hanya dapat diakses oleh Owner.',
          requiredPermission: 'canManageLicense',
        };
      }
      return { allowed: true };

    default:
      return { allowed: true };
  }
}
