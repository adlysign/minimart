export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount || 0);
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('id-ID').format(num || 0);
}

export function formatDateTime(isoString: string): string {
  if (!isoString) return '-';
  const d = new Date(isoString);
  return d.toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(isoString: string): string {
  if (!isoString) return '-';
  const d = new Date(isoString);
  return d.toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

/**
 * Generate a clean Code128-like vector SVG barcode without any heavy 3rd-party dependencies
 */
export function generateBarcodeSvg(barcode?: string, width = 200, height = 65): string {
  const code = (barcode || '').trim() || '000000000000';
  let hash = 0;
  for (let i = 0; i < code.length; i++) {
    hash = (hash << 5) - hash + code.charCodeAt(i);
    hash |= 0;
  }
  
  // Deterministic bar widths based on char codes
  const bars: { x: number; w: number }[] = [];
  let currentX = 10;
  const barUnit = (width - 20) / (code.length * 7 + 10);
  
  // Quiet zone and start guard
  bars.push({ x: currentX, w: barUnit * 2 });
  currentX += barUnit * 3;
  bars.push({ x: currentX, w: barUnit });
  currentX += barUnit * 2;

  for (let i = 0; i < code.length; i++) {
    const charCode = code.charCodeAt(i);
    const pattern = [(charCode % 3) + 1, ((charCode >> 2) % 3) + 1, ((charCode >> 4) % 2) + 1];
    pattern.forEach((p, idx) => {
      if (idx % 2 === 0) {
        bars.push({ x: currentX, w: p * barUnit });
      }
      currentX += p * barUnit + barUnit;
    });
  }

  // Stop guard
  bars.push({ x: currentX, w: barUnit * 2 });
  currentX += barUnit * 3;
  bars.push({ x: currentX, w: barUnit * 2 });

  const rects = bars
    .map(b => `<rect x="${b.x.toFixed(1)}" y="4" width="${b.w.toFixed(1)}" height="${height - 22}" fill="#000" />`)
    .join('');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" class="w-full h-auto">
    <rect width="${width}" height="${height}" fill="#ffffff" />
    ${rects}
    <text x="${width / 2}" y="${height - 4}" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle" fill="#111827">${code}</text>
  </svg>`;
}

/**
 * Procedural clean vector QR-code SVG for QRIS payment
 */
export function generateQRISSvg(content: string, size = 200): string {
  const gridSize = 25;
  const cellSize = (size - 20) / gridSize;
  const offset = 10;
  
  // Helper to hash string for reproducible dot matrix
  const isFilled = (r: number, c: number): boolean => {
    // Top-left finder pattern
    if (r <= 6 && c <= 6) {
      if (r === 0 || r === 6 || c === 0 || c === 6) return true;
      if (r >= 2 && r <= 4 && c >= 2 && c <= 4) return true;
      return false;
    }
    // Top-right finder pattern
    if (r <= 6 && c >= gridSize - 7) {
      const col = c - (gridSize - 7);
      if (r === 0 || r === 6 || col === 0 || col === 6) return true;
      if (r >= 2 && r <= 4 && col >= 2 && col <= 4) return true;
      return false;
    }
    // Bottom-left finder pattern
    if (r >= gridSize - 7 && c <= 6) {
      const row = r - (gridSize - 7);
      if (row === 0 || row === 6 || c === 0 || c === 6) return true;
      if (row >= 2 && row <= 4 && c >= 2 && c <= 4) return true;
      return false;
    }
    // Timing patterns
    if (r === 6 && c % 2 === 0) return true;
    if (c === 6 && r % 2 === 0) return true;

    // Data matrix pseudo-random distribution seeded by content
    let val = 0;
    for (let i = 0; i < content.length; i++) {
      val += content.charCodeAt(i) * (i + 1);
    }
    return ((r * 17 + c * 31 + val) % 100) > 48;
  };

  const rects: string[] = [];
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      if (isFilled(r, c)) {
        rects.push(`<rect x="${(offset + c * cellSize).toFixed(1)}" y="${(offset + r * cellSize).toFixed(1)}" width="${cellSize.toFixed(1)}" height="${cellSize.toFixed(1)}" fill="#0f172a" />`);
      }
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" class="w-full h-auto">
    <rect width="${size}" height="${size}" fill="#ffffff" rx="8" />
    ${rects.join('')}
    <!-- QRIS Center Emblem Badge -->
    <rect x="${size / 2 - 16}" y="${size / 2 - 16}" width="32" height="32" rx="4" fill="#ffffff" stroke="#ef4444" stroke-width="2" />
    <text x="${size / 2}" y="${size / 2 + 5}" font-family="sans-serif" font-size="9" font-weight="900" fill="#dc2626" text-anchor="middle">QRIS</text>
  </svg>`;
}

export function exportToCSV(filename: string, rows: Record<string, unknown>[]): void {
  if (!rows || !rows.length) return;
  const separator = ',';
  const keys = Object.keys(rows[0]);
  const csvContent =
    keys.join(separator) +
    '\n' +
    rows
      .map(row => {
        return keys
          .map(k => {
            const raw = row[k] === null || row[k] === undefined ? '' : row[k];
            let cellStr = raw instanceof Date ? raw.toLocaleString() : String(raw);
            cellStr = cellStr.replace(/"/g, '""');
            if (cellStr.search(/("|,|\n)/g) >= 0) cellStr = `"${cellStr}"`;
            return cellStr;
          })
          .join(separator);
      })
      .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
