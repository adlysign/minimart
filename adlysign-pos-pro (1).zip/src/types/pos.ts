export type UserRole = 'OWNER' | 'ADMIN' | 'SUPERVISOR' | 'KASIR';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  pin: string; // 4-digit PIN
  phone?: string;
  notes?: string;
  avatar?: string;
  isActive: boolean;
  permissions: {
    canVoid: boolean;
    canDiscount: boolean;
    canEditProduct: boolean;
    canViewProfit: boolean;
    canManageStaff: boolean;
    canAccessReports: boolean;
    canManageLicense: boolean;
    canOpname: boolean;
    canPurchases?: boolean;
    canHardware?: boolean;
  };
}

export interface CashierShift {
  id: string;
  cashierId: string;
  cashierName: string;
  shiftName: string; // Shift Pagi, Shift Siang, Shift Malam
  startTime: string;
  endTime?: string;
  initialCash: number; // Modal awal laci kasir
  cashSales: number;
  nonCashSales: number;
  systemExpectedCash: number; // initialCash + cashSales
  actualDrawerCash?: number;
  difference?: number;
  status: 'OPEN' | 'CLOSED';
  notes?: string;
}

export interface Category {
  id: string;
  name: string;
  color?: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  address: string;
}

export interface MemberPointSettings {
  isEnabled: boolean;
  earnSpendAmount: number; // Tiap belanja berapa rupiah (e.g. 10.000)
  earnPoints: number; // Mendapatkan berapa poin (e.g. 1)
  pointValueInRupiah: number; // 1 Poin = Rp ... (e.g. 100)
  redeemMode: 'FULL' | 'PERCENT_LIMIT'; // 'FULL' = bisa digunakan sepenuhnya, 'PERCENT_LIMIT' = dibatasi % belanja
  maxRedeemPercentage: number; // Maks. potongan dalam persen dari total belanja (e.g. 50%)
  minPointsToRedeem: number; // Minimal poin untuk bisa ditukar (e.g. 10)
}

export interface CustomerMember {
  id: string;
  memberCode: string;
  name: string;
  phone: string;
  points: number;
  discountRate: number; // in percentage e.g. 5%
  totalSpent: number;
  totalDebt?: number;
  creditLimit?: number;
  address?: string;
  notes?: string;
  createdAt?: string;
}

export interface Product {
  id: string;
  barcode: string;
  sku: string;
  name: string;
  categoryId: string;
  categoryName?: string;
  supplierId?: string;
  supplierName?: string;
  unit: string; // Pcs, Dus, Pak, Kg, Botol, Sachet
  costPrice: number; // Harga Beli (HPP)
  sellingPrice: number; // Harga Jual
  stock: number;
  minStock: number;
  expiryDate?: string;
  isActive: boolean;
  imageUrl?: string;
}

export interface CartItem {
  id: string; // unique item line id
  productId: string;
  barcode: string;
  sku: string;
  name: string;
  unit: string;
  costPrice: number;
  sellingPrice: number;
  quantity: number;
  discountType: 'PERCENT' | 'NOMINAL';
  discountValue: number;
  subtotal: number;
  notes?: string;
}

export type PaymentMethod = 'TUNAI' | 'QRIS' | 'BCA' | 'BRI' | 'MANDIRI' | 'BNI' | 'EDC' | 'PIUTANG' | 'TRANSFER';

export interface PiutangPayment {
  id: string;
  amount: number;
  paidAt: string;
  cashierName: string;
  paymentMethod: 'TUNAI' | 'TRANSFER';
  notes?: string;
}

export interface PiutangRecord {
  id: string;
  invoiceNumber: string;
  saleId?: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  dueDate: string; // YYYY-MM-DD
  status: 'BELUM_LUNAS' | 'LUNAS' | 'JATUH_TEMPO';
  notes?: string;
  createdAt: string;
  updatedAt: string;
  payments: PiutangPayment[];
}

export interface SaleTransaction {
  id: string;
  invoiceNumber: string;
  cashierId: string;
  cashierName: string;
  shiftId: string;
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  items: CartItem[];
  subtotal: number;
  transactionDiscount: number; // global discount
  totalAmount: number;
  totalCost: number; // total HPP
  grossProfit: number;
  paymentMethod: PaymentMethod;
  paymentDetails?: {
    bankName?: string;
    cardLast4?: string;
    approvalCode?: string;
    qrisRrn?: string;
    downPayment?: number;
    dueDate?: string;
    piutangId?: string;
    pointsRedeemed?: number;
    pointsDiscountAmount?: number;
  };
  pointsRedeemed?: number;
  pointsDiscountAmount?: number;
  pointsEarned?: number;
  cashReceived: number;
  changeDue: number;
  status: 'COMPLETED' | 'VOID' | 'RETURNED';
  voidReason?: string;
  voidBySupervisor?: string;
  createdAt: string;
}

export interface PendingCart {
  id: string;
  name: string; // e.g. "Keranjang Bp. Anton" or "Pelanggan 1" (Label pengenal)
  label?: string;
  items: CartItem[];
  customer?: CustomerMember;
  createdAt: string;
  notes?: string;
  createdByCashier?: string;
}

export interface SalesReturn {
  id: string;
  returnInvoice: string;
  originalInvoiceNumber: string;
  saleId: string;
  refundAmount: number;
  supervisorId: string;
  supervisorName: string;
  reason: string;
  returnedItems: {
    productId: string;
    productName: string;
    quantity: number;
    refundPrice: number;
  }[];
  createdAt: string;
}

export type InventoryMovementType = 
  | 'STOK_MASUK'
  | 'STOK_KELUAR'
  | 'BARANG_RUSAK'
  | 'BARANG_EXPIRED'
  | 'STOCK_OPNAME'
  | 'MUTASI_STOK'
  | 'REPACKING'
  | 'PENJUALAN'
  | 'RETUR_PENJUALAN';

export interface InventoryLog {
  id: string;
  productId: string;
  productName: string;
  barcode: string;
  type: InventoryMovementType;
  quantityChange: number; // positive or negative
  stockBefore: number;
  stockAfter: number;
  referenceDoc?: string; // No Faktur, No Struk, No Opname
  userName: string;
  notes?: string;
  createdAt: string;
}

export interface PurchaseOrder {
  id: string;
  invoiceNumber: string; // No Faktur Supplier
  supplierId: string;
  supplierName: string;
  purchaseDate: string;
  dueDate?: string;
  paymentStatus: 'LUNAS' | 'HUTANG';
  items: {
    productId: string;
    productName: string;
    quantity: number;
    unitCost: number;
    subtotal: number;
  }[];
  totalAmount: number;
  notes?: string;
  receivedBy: string;
  createdAt: string;
}

export interface StockOpnameSession {
  id: string;
  opnameNumber: string;
  date: string;
  supervisorName: string;
  items: {
    productId: string;
    productName: string;
    barcode: string;
    systemStock: number;
    physicalStock: number;
    difference: number;
    notes?: string;
  }[];
  status: 'DRAFT' | 'COMMITTED';
  totalVarianceValue: number;
}

export interface RepackingRecord {
  id: string;
  date: string;
  sourceProductId: string;
  sourceProductName: string;
  sourceQtyDeducted: number; // e.g. 1 Dus
  targetProductId: string;
  targetProductName: string;
  targetQtyAdded: number; // e.g. 24 Pcs
  operatorName: string;
  notes?: string;
}

export interface HardwareSettings {
  printerType: 'THERMAL_58' | 'THERMAL_80';
  connectionType: 'BLUETOOTH' | 'USB' | 'RAWBT';
  paperWidthMm: 58 | 80;
  autoCut: boolean;
  openDrawerOnCash: boolean;
  printCopies: number;
  barcodeScannerMode: 'USB_KEYBOARD' | 'CAMERA_HP';
  rawbtPackage: string;
}

export interface StoreProfile {
  storeId: string;
  name: string;
  address: string;
  phone: string;
  receiptHeader: string;
  receiptFooter: string;
  taxRate: number; // default 0%
}

export interface BankAccount {
  id: string;
  bankName: string; // BCA, BRI, Mandiri, BNI, BSI, CIMB, Jago, Seabank, dll
  accountNumber: string;
  accountHolder: string; // a.n. Nama Pemilik Rekening
  isActive: boolean;
  notes?: string;
  color?: string;
}

export interface QRISSettings {
  imageUrl: string; // Data URL or Web URL of QRIS barcode image
  merchantName: string;
  nmid: string;
  notes: string;
  isActive: boolean;
}

export interface PaymentSettings {
  qris: QRISSettings;
  bankAccounts: BankAccount[];
}

export type LicensePlan = 'LIFETIME' | 'BULANAN' | 'TRIAL';

export interface LicenseInfo {
  storeId: string;
  deviceId: string;
  licenseKey: string;
  plan: LicensePlan;
  status: 'ACTIVE' | 'EXPIRED' | 'UNREGISTERED';
  maxDevices: number;
  activeDevicesCount: number;
  activatedAt: string;
  validUntil: string; // 'Selamanya' or ISO date
  registeredStoreName: string;
}

export type LanDeviceRole = 'STANDALONE' | 'SERVER_MASTER' | 'CLIENT';

export interface LanConnectedClient {
  deviceId: string;
  terminalName?: string;
  deviceName?: string;
  ipAddress: string;
  lastSeen: string;
  role: string;
}

export type LanEventType =
  | 'TRANSACTION_CREATED'
  | 'PRODUCT_UPDATED'
  | 'STOCK_ADJUSTED'
  | 'PIUTANG_UPDATED'
  | 'CUSTOMER_UPDATED'
  | 'TEST_SIGNAL'
  | 'FULL_STATE_UPDATED';

export interface LanSyncLog {
  id: string;
  timestamp: string;
  type: 'EVENT_IN' | 'EVENT_OUT' | 'CONNECT' | 'DISCONNECT' | 'FULL_SYNC' | 'ERROR';
  eventTitle: string;
  sourceTerminal: string;
  status: 'SUCCESS' | 'INFO' | 'WARNING' | 'ERROR';
  details?: string;
}

export interface LanSyncStatus {
  role: LanDeviceRole;
  terminalName: string;
  serverUrl: string;
  isConnected: boolean;
  isSyncing: boolean;
  lastSyncTime: string | null;
  autoSync: boolean;
  detectedIps: string[];
  serverPort: number;
  serverHostname: string;
  connectedClients: LanConnectedClient[];
  error: string | null;
  localVersion: number;
  activityLogs: LanSyncLog[];
}

