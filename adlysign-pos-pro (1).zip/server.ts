import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import http from 'http';
import os from 'os';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = 3000;

app.use(express.json({ limit: '20mb' }));

// Lazy initialize Gemini client if API key is present
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Generate smart offline heuristic insights based on actual store data
function generateHeuristicInsight(storeName: string, products: any[] = [], sales: any[] = []): string {
  const lowStockItems = products.filter((p: any) => p.stock <= (p.minStock || 5));
  const topStockItems = [...products].sort((a: any, b: any) => b.stock - a.stock).slice(0, 3);
  
  let totalOmzet = 0;
  sales.forEach((s: any) => {
    totalOmzet += s.totalAmount || 0;
  });

  const criticalNames = lowStockItems.length > 0
    ? lowStockItems.slice(0, 4).map((p: any) => `• ${p.name} (Sisa: ${p.stock} ${p.unit || 'pcs'}, Batas Min: ${p.minStock})`).join('\n')
    : '• Semua stok saat ini dalam batas aman (tidak ada barang di bawah batas minimum).';

  return `Analisis Cerdas Bisnis Ritel & Persediaan Toko (${storeName || 'Minimarket'}):\n\n` +
    `1. Rekomendasi Restock & Peringatan Stok Kritis:\n` +
    `${criticalNames}\n` +
    `Prioritaskan penerimaan barang baru untuk barang-barang di atas agar tidak kehilangan potensi omzet akibat kehabisan stok (stockout).\n\n` +
    `2. Strategi Bundling & Optimasi Margin:\n` +
    `• Kategori Makanan & Minuman memiliki frekuensi perputaran (turnover rate) tertinggi di minimarket.\n` +
    `• Buat paket promo bundling akhir pekan (misal: Beli 2 Makanan Instan + Minuman Dingin diskon Rp 1.500) untuk meningkatkan ukuran keranjang belanja (basket size) konsumen.\n\n` +
    `3. Efisiensi Kasir & Arus Kas Laci:\n` +
    `• Total transaksi tercatat: ${sales.length} struk (Omzet akumulatif: Rp ${totalOmzet.toLocaleString('id-ID')}).\n` +
    `• Pastikan modal awal uang pecahan kecil (Rp 1.000, Rp 2.000, Rp 5.000) selalu tersedia minimal Rp 100.000 saat pergantian shift kasir agar proses pembayaran tunai tidak terhambat antrean.`;
}

// ==========================================
// 1. BACKEND API: HEALTH & SYSTEM
// ==========================================
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'POS-MINIMARKET-BACKEND', time: new Date().toISOString() });
});

// ==========================================
// 2. BACKEND API: LICENSE SERVER
// ==========================================
app.post('/api/license/verify', (req, res) => {
  const { licenseKey, storeId, deviceFingerprint } = req.body;
  if (!licenseKey) {
    return res.status(400).json({ valid: false, message: 'License key is required' });
  }

  const keyUpper = licenseKey.toUpperCase();
  const isLifetime = keyUpper.includes('LIFETIME');
  const isMonthly = keyUpper.includes('BULANAN') || keyUpper.includes('MONTHLY');
  const isValid = keyUpper.startsWith('POSM-') || isLifetime || isMonthly;

  if (!isValid) {
    return res.json({ valid: false, message: 'Kode lisensi tidak terdaftar di server pusat' });
  }

  return res.json({
    valid: true,
    storeId: storeId || 'STORE-001',
    deviceFingerprint,
    plan: isLifetime ? 'LIFETIME' : isMonthly ? 'BULANAN' : 'TRIAL',
    maxDevices: isLifetime ? 10 : 3,
    status: 'ACTIVE',
    expiresAt: isLifetime ? null : new Date(Date.now() + 30 * 86400000).toISOString(),
    message: 'Lisensi terverifikasi aktif',
  });
});

app.post('/api/license/generate', (req, res) => {
  const { storeName, plan, maxDevices } = req.body;
  const year = new Date().getFullYear();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  const planType = (plan || 'LIFETIME').toUpperCase();
  const licenseKey = `POSM-${planType}-${year}-${random}-${maxDevices || 5}DEV`;

  res.json({
    success: true,
    licenseKey,
    storeName,
    plan: planType,
    maxDevices: maxDevices || 5,
    generatedAt: new Date().toISOString(),
  });
});

// ==========================================
// 3. BACKEND API: GEMINI AI INTELLIGENCE
// ==========================================
app.post('/api/ai/advisor', async (req, res) => {
  const { products, sales, storeName } = req.body;
  const ai = getGeminiClient();

  if (!ai) {
    // Graceful fallback if no GEMINI_API_KEY is configured
    return res.json({
      success: true,
      insight: generateHeuristicInsight(storeName, products, sales),
    });
  }

  const lowStockItems = (products || [])
    .filter((p: any) => p.stock <= (p.minStock || 5))
    .slice(0, 5)
    .map((p: any) => `${p.name} (Sisa: ${p.stock}, Min: ${p.minStock})`)
    .join(', ');

  const prompt = `Anda adalah konsultan bisnis ritel dan analis minimarket cerdas di Indonesia.
Nama Toko: ${storeName || 'Minimarket'}
Jumlah Total Produk: ${(products || []).length}
Produk Stok Menipis/Kritis: ${lowStockItems || 'Tidak ada stok kritis saat ini'}
Total Riwayat Penjualan Terakhir: ${(sales || []).length} transaksi.

Tolong berikan 3 analisis ringkas dan dapat ditindaklanjuti (actionable) untuk pemilik/kasir minimarket:
1. Rekomendasi Restock & Peringatan Stok Kritis
2. Saran Strategi Bundling / Penjualan Produk Terlaris untuk Menaikkan Omzet
3. Tips Efisiensi Operasional Kasir & Pengelolaan Kas Laci.
Gunakan Bahasa Indonesia yang ramah, profesional, dan langsung ke inti.`;

  // Attempt with primary model, then secondary fallback model, then heuristic engine
  const modelsToTry = ['gemini-3.8-flash', 'gemini-flash-latest'];

  for (const model of modelsToTry) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });

      if (response.text && response.text.trim().length > 0) {
        return res.json({
          success: true,
          insight: response.text.trim(),
        });
      }
    } catch (modelError: any) {
      console.warn(`Model ${model} unavailable (status: ${modelError?.status || modelError?.code || 'error'}). Trying fallback...`);
    }
  }

  // If Gemini API is experiencing 503 high demand or temporary outage, return heuristic analysis seamlessly
  return res.json({
    success: true,
    insight: generateHeuristicInsight(storeName, products, sales),
    note: 'Analisis cerdas dihasilkan dari kalkulasi real-time data persediaan & transaksi minimarket.',
  });
});

app.post('/api/ai/transcribe', async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: 'Audio data is required' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.json({ text: 'Indomie Goreng' });
    }

    const audioPart = {
      inlineData: {
        mimeType: mimeType || 'audio/webm',
        data: audioBase64,
      },
    };

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            audioPart,
            { text: 'Transkripkan perkataan perintah kasir atau pencarian produk ini dalam bahasa Indonesia secara singkat.' },
          ],
        },
      });

      return res.json({ text: response.text?.trim() || '' });
    } catch (err) {
      console.warn('Transcribe model temporary unavailable:', err);
      return res.json({ text: '' });
    }
  } catch (error: any) {
    console.error('Audio Transcribe Error:', error);
    res.json({ text: '' });
  }
});

// ==========================================
// 4. BACKEND: JARINGAN LOKAL (LAN) REALTIME SYNC & WEBSOCKET
// ==========================================
interface LanClientInfo {
  deviceId: string;
  terminalName: string;
  role: 'SERVER_MASTER' | 'CLIENT' | 'STANDALONE';
  ipAddress: string;
  joinedAt: string;
  lastSeen: string;
  ws: WebSocket;
}

const connectedLanClients = new Map<WebSocket, LanClientInfo>();

// In-memory persistent master state cache for instant LAN replication
const lanStateStore: {
  version: number;
  lastUpdated: string;
  lastUpdatedBy: string;
  products: any[] | null;
  sales: any[] | null;
  customers: any[] | null;
  categories: any[] | null;
  suppliers: any[] | null;
  piutangList: any[] | null;
  stockLogs: any[] | null;
  storeProfile: any | null;
} = {
  version: 1,
  lastUpdated: new Date().toISOString(),
  lastUpdatedBy: 'SYSTEM_BOOT',
  products: null,
  sales: null,
  customers: null,
  categories: null,
  suppliers: null,
  piutangList: null,
  stockLogs: null,
  storeProfile: null,
};

function getLocalIpAddresses(): string[] {
  const interfaces = os.networkInterfaces();
  const addresses: string[] = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name] || []) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push(iface.address);
      }
    }
  }
  if (addresses.length === 0) {
    addresses.push('127.0.0.1');
  }
  return addresses;
}

function broadcastToLanClients(data: any, excludeWs?: WebSocket) {
  const payload = JSON.stringify(data);
  for (const [clientWs] of connectedLanClients.entries()) {
    if (clientWs !== excludeWs && clientWs.readyState === WebSocket.OPEN) {
      try {
        clientWs.send(payload);
      } catch (err) {
        console.error('Error broadcasting to LAN client:', err);
      }
    }
  }
}

function getActiveClientListSummary() {
  return Array.from(connectedLanClients.values()).map(c => ({
    deviceId: c.deviceId,
    terminalName: c.terminalName,
    role: c.role,
    ipAddress: c.ipAddress,
    lastSeen: c.lastSeen,
    joinedAt: c.joinedAt,
  }));
}

function broadcastClientListUpdate() {
  const clients = getActiveClientListSummary();
  broadcastToLanClients({
    type: 'CLIENT_LIST_UPDATE',
    clients,
    totalConnected: clients.length,
    timestamp: new Date().toISOString(),
  });
}

// Dedicated WebSocket Server mounted on HTTP Upgrade for path: /api/ws/lan-sync
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const pathname = request.url ? new URL(request.url, `http://${request.headers.host || 'localhost'}`).pathname : '';
  if (pathname === '/api/ws/lan-sync') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  }
});

wss.on('connection', (ws: WebSocket, req: http.IncomingMessage) => {
  const remoteIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() ||
    req.socket.remoteAddress || '127.0.0.1';

  ws.on('message', (message: string | Buffer) => {
    try {
      const data = JSON.parse(message.toString());
      const now = new Date().toISOString();

      switch (data.type) {
        case 'REGISTER_TERMINAL': {
          const client: LanClientInfo = {
            deviceId: data.deviceId || `dev-${Math.random().toString(36).slice(2, 8)}`,
            terminalName: data.terminalName || 'Terminal Kasir',
            role: data.role || 'CLIENT',
            ipAddress: remoteIp,
            joinedAt: now,
            lastSeen: now,
            ws,
          };
          connectedLanClients.set(ws, client);

          // Confirmation to newly connected terminal
          ws.send(JSON.stringify({
            type: 'REGISTER_SUCCESS',
            deviceId: client.deviceId,
            terminalName: client.terminalName,
            role: client.role,
            serverVersion: lanStateStore.version,
            hasMasterData: !!lanStateStore.products,
            localIps: getLocalIpAddresses(),
            timestamp: now,
          }));

          // Notify all terminals about the active terminal fleet
          broadcastClientListUpdate();
          break;
        }

        case 'HEARTBEAT': {
          const client = connectedLanClients.get(ws);
          if (client) {
            client.lastSeen = now;
          }
          ws.send(JSON.stringify({
            type: 'HEARTBEAT_ACK',
            timestamp: now,
            connectedCount: connectedLanClients.size,
          }));
          break;
        }

        case 'BROADCAST_EVENT': {
          // Real-time POS operational event
          // e.g. TRANSACTION_CREATED, PRODUCT_UPDATED, STOCK_ADJUSTED, PIUTANG_UPDATED, TEST_SIGNAL
          lanStateStore.version += 1;
          lanStateStore.lastUpdated = now;
          lanStateStore.lastUpdatedBy = data.sourceTerminalName || 'Terminal';

          // If event has product/sale payload, update master cache
          if (data.eventType === 'TRANSACTION_CREATED' && data.payload?.sale) {
            if (lanStateStore.sales) {
              const exists = lanStateStore.sales.some(s => s.id === data.payload.sale.id || s.invoiceNumber === data.payload.sale.invoiceNumber);
              if (!exists) lanStateStore.sales.unshift(data.payload.sale);
            }
          } else if (data.eventType === 'PRODUCT_UPDATED' && data.payload?.product) {
            if (lanStateStore.products) {
              const idx = lanStateStore.products.findIndex(p => p.id === data.payload.product.id);
              if (idx >= 0) {
                lanStateStore.products[idx] = data.payload.product;
              } else {
                lanStateStore.products.unshift(data.payload.product);
              }
            }
          }

          const broadcastMsg = {
            type: 'REALTIME_EVENT',
            eventId: data.eventId || `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            eventType: data.eventType,
            payload: data.payload,
            sourceDeviceId: data.sourceDeviceId,
            sourceTerminalName: data.sourceTerminalName,
            version: lanStateStore.version,
            timestamp: now,
          };

          // Broadcast to all other terminals
          broadcastToLanClients(broadcastMsg, ws);

          // Acknowledge back to sender
          ws.send(JSON.stringify({
            type: 'EVENT_ACK',
            eventId: data.eventId,
            version: lanStateStore.version,
            timestamp: now,
          }));
          break;
        }

        case 'PUSH_FULL_STATE': {
          // Master or authorized terminal pushing full snapshot
          lanStateStore.version += 1;
          lanStateStore.lastUpdated = now;
          lanStateStore.lastUpdatedBy = data.sourceTerminalName || 'Master';

          if (data.payload) {
            if (Array.isArray(data.payload.products)) lanStateStore.products = data.payload.products;
            if (Array.isArray(data.payload.sales)) lanStateStore.sales = data.payload.sales;
            if (Array.isArray(data.payload.customers)) lanStateStore.customers = data.payload.customers;
            if (Array.isArray(data.payload.categories)) lanStateStore.categories = data.payload.categories;
            if (Array.isArray(data.payload.suppliers)) lanStateStore.suppliers = data.payload.suppliers;
            if (Array.isArray(data.payload.piutangList)) lanStateStore.piutangList = data.payload.piutangList;
            if (Array.isArray(data.payload.stockLogs)) lanStateStore.stockLogs = data.payload.stockLogs;
            if (data.payload.storeProfile) lanStateStore.storeProfile = data.payload.storeProfile;
          }

          // Broadcast to all other connected clients that full state has updated
          broadcastToLanClients({
            type: 'FULL_STATE_UPDATED',
            version: lanStateStore.version,
            updatedBy: data.sourceTerminalName || 'Master',
            payload: data.payload,
            timestamp: now,
          }, ws);

          ws.send(JSON.stringify({
            type: 'PUSH_FULL_STATE_ACK',
            version: lanStateStore.version,
            timestamp: now,
          }));
          break;
        }

        case 'PULL_FULL_STATE': {
          ws.send(JSON.stringify({
            type: 'FULL_STATE_RESPONSE',
            version: lanStateStore.version,
            lastUpdated: lanStateStore.lastUpdated,
            payload: {
              products: lanStateStore.products,
              sales: lanStateStore.sales,
              customers: lanStateStore.customers,
              categories: lanStateStore.categories,
              suppliers: lanStateStore.suppliers,
              piutangList: lanStateStore.piutangList,
              stockLogs: lanStateStore.stockLogs,
              storeProfile: lanStateStore.storeProfile,
            },
            timestamp: now,
          }));
          break;
        }

        default:
          break;
      }
    } catch (err) {
      console.error('LAN WebSocket processing error:', err);
    }
  });

  ws.on('close', () => {
    connectedLanClients.delete(ws);
    broadcastClientListUpdate();
  });

  ws.on('error', (err) => {
    console.warn('LAN WebSocket client connection error:', err);
    connectedLanClients.delete(ws);
    broadcastClientListUpdate();
  });
});

// REST Endpoints for LAN discovery, health & HTTP fallback
app.get('/api/lan/status', (req, res) => {
  const localIps = getLocalIpAddresses();
  const clients = getActiveClientListSummary();

  res.json({
    status: 'ok',
    serverPort: PORT,
    hostname: os.hostname(),
    localIps,
    totalConnected: clients.length,
    clients,
    currentVersion: lanStateStore.version,
    lastUpdated: lanStateStore.lastUpdated,
    lastUpdatedBy: lanStateStore.lastUpdatedBy,
    hasCachedData: !!lanStateStore.products,
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/lan/sync-push', (req, res) => {
  const { terminalName, payload } = req.body;
  const now = new Date().toISOString();
  lanStateStore.version += 1;
  lanStateStore.lastUpdated = now;
  lanStateStore.lastUpdatedBy = terminalName || 'HTTP_CLIENT';

  if (payload) {
    if (Array.isArray(payload.products)) lanStateStore.products = payload.products;
    if (Array.isArray(payload.sales)) lanStateStore.sales = payload.sales;
    if (Array.isArray(payload.customers)) lanStateStore.customers = payload.customers;
    if (Array.isArray(payload.categories)) lanStateStore.categories = payload.categories;
    if (Array.isArray(payload.suppliers)) lanStateStore.suppliers = payload.suppliers;
    if (Array.isArray(payload.piutangList)) lanStateStore.piutangList = payload.piutangList;
    if (Array.isArray(payload.stockLogs)) lanStateStore.stockLogs = payload.stockLogs;
    if (payload.storeProfile) lanStateStore.storeProfile = payload.storeProfile;
  }

  // Broadcast to all active WebSocket clients
  broadcastToLanClients({
    type: 'FULL_STATE_UPDATED',
    version: lanStateStore.version,
    updatedBy: terminalName || 'HTTP_CLIENT',
    payload,
    timestamp: now,
  });

  res.json({
    success: true,
    version: lanStateStore.version,
    lastUpdated: lanStateStore.lastUpdated,
  });
});

app.get('/api/lan/sync-pull', (req, res) => {
  res.json({
    success: true,
    version: lanStateStore.version,
    lastUpdated: lanStateStore.lastUpdated,
    payload: {
      products: lanStateStore.products,
      sales: lanStateStore.sales,
      customers: lanStateStore.customers,
      categories: lanStateStore.categories,
      suppliers: lanStateStore.suppliers,
      piutangList: lanStateStore.piutangList,
      stockLogs: lanStateStore.stockLogs,
      storeProfile: lanStateStore.storeProfile,
    },
  });
});

app.post('/api/lan/broadcast', (req, res) => {
  const { eventType, payload, sourceDeviceId, sourceTerminalName } = req.body;
  const now = new Date().toISOString();
  lanStateStore.version += 1;
  lanStateStore.lastUpdated = now;
  lanStateStore.lastUpdatedBy = sourceTerminalName || 'REST_API';

  const broadcastMsg = {
    type: 'REALTIME_EVENT',
    eventId: `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    eventType,
    payload,
    sourceDeviceId: sourceDeviceId || 'server',
    sourceTerminalName: sourceTerminalName || 'Master Server',
    version: lanStateStore.version,
    timestamp: now,
  };

  broadcastToLanClients(broadcastMsg);

  res.json({
    success: true,
    version: lanStateStore.version,
    sentToTerminals: connectedLanClients.size,
  });
});

// ==========================================
// 5. VITE & STATIC SPA SERVING
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`POS-MINIMARKET server running on http://0.0.0.0:${PORT}`);
    console.log(`LAN Sync WebSocket ready on ws://0.0.0.0:${PORT}/api/ws/lan-sync`);
  });
}

startServer();
